package org.adoxx.all.api.primitive;

public class Identifier {

    private String identifier = null;
    
    public Identifier(String identifier){
        if(identifier == null)
            this.identifier = "";
        this.identifier = identifier.replace("\n", "");
    }
    
    public String getRaw(){
        return new String(identifier);
    }
    
    @Override
    public int hashCode(){
        return identifier.hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof Identifier))
            return o==this;
        return ((Identifier)o).toString().equals(this.toString());
    }
    
    @Override
    public String toString(){
        return "<"+identifier+">";
    }
}
