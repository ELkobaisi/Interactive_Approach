package org.adoxx.all.api.library;

import org.adoxx.all.api.primitive.AttrVal;
import org.adoxx.all.api.primitive.Identifier;

public class InstanceAttributeSetting {

    private Identifier identifier = null;
    private AttrVal value = null;
    
    public InstanceAttributeSetting(Identifier identifier, AttrVal value) throws Exception {
        if(identifier == null || value == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.value = value;
    }

    public Identifier getId(){
        return this.identifier;
    }
    
    public AttrVal getValue(){
        return this.value;
    }
    
    @Override
    public int hashCode(){
        return identifier.hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof InstanceAttributeSetting))
            return o==this;
        return ((InstanceAttributeSetting)o).getId().equals(this.getId());
    }
    
    @Override
    public String toString(){
        return "ATTRIBUTE " + identifier.toString() + "\nVALUE " + value.toString() + "\n\n";
    }
}
