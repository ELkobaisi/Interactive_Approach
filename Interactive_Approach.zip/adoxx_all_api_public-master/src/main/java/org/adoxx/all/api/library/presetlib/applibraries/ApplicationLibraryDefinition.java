package org.adoxx.all.api.library.presetlib.applibraries;

import org.adoxx.all.api.primitive.Identifier;

public class ApplicationLibraryDefinition {

    private Identifier libraryId = null;
    private Identifier superLibraryId = null;
    
    public ApplicationLibraryDefinition(Identifier libraryId, Identifier superLibraryId) throws Exception {
        if(libraryId == null || superLibraryId == null)
            throw new Exception("Not Allowed");
        
        this.libraryId = libraryId;
        this.superLibraryId = superLibraryId;
    }

    public Identifier getId(){
        return this.libraryId;
    }
    
    public Identifier getSuperLibId(){
        return this.superLibraryId;
    }
    
    @Override
    public String toString(){
        return "APPLICATION LIBRARY " + libraryId.toString() + " : " + superLibraryId.toString() + "\n\n";
    }
}
