package org.adoxx.all.parser;

public interface IStatusMonitor {

    public void getStatus(double percentageStatus);
}
