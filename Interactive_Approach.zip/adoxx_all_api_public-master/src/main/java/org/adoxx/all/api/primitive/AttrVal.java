package org.adoxx.all.api.primitive;

public class AttrVal {
    
    private Integer valInt = null;
    private Double valDouble = null;
    private String valS = null;
    private RecordVal[] valRecList = null;
    
    public AttrVal(int val){
        
        this.valInt = Integer.valueOf(val);;
    }
    
    public AttrVal(double val) throws Exception{
        this.valDouble = Double.valueOf(val);
    }
    
    public AttrVal(String val) throws Exception{
        if(val == null)
            throw new Exception("Not Allowed");
        this.valS = val;
    }
    
    public AttrVal(RecordVal[] val) throws Exception{
        if(val == null)
            throw new Exception("Not Allowed");
        this.valRecList = val;
    }
    
    public AttrVal(AttrVal val) throws Exception{
        this.valRecList = val.valRecList;
        this.valS = val.valS;
        this.valDouble = val.valDouble;
        this.valInt = val.valInt;
    }
    
    public void set(int val) throws Exception{
        if(this.valInt == null)
            throw new Exception("The provided value do not match with the original one");
        this.valInt =  Integer.valueOf(val);
    }
    
    public void set(double val) throws Exception{
        if(this.valDouble == null)
            throw new Exception("The provided value do not match with the original one");
        this.valDouble = Double.valueOf(val);
    }
    
    public void set(String val) throws Exception{
        if(this.valS == null)
            throw new Exception("The provided value do not match with the original one");
        this.valS = val;
    }
    
    public void set(RecordVal[] val) throws Exception{
        if(this.valRecList == null)
            throw new Exception("The provided value do not match with the original one");
        this.valRecList = val;
    }
    
    public void set(AttrVal val) throws Exception{
        this.valRecList = val.valRecList;
        this.valS = val.valS;
        this.valDouble = val.valDouble;
        this.valInt = val.valInt;
    }
    
    @Override
    public int hashCode(){
        return this.toString().hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof AttrVal))
            return o==this;
        return ((AttrVal) o).toString().equals(this.toString());
    }
    
    @Override
    public String toString(){
        if(valInt != null)
            return valInt.toString();
        if(valDouble != null)
            return valDouble.toString();
        if(valS != null)
            return fixLongString("\""+valS.replace("\\", "\\\\").replace("\"", "\\\"")+"\""); //first escape the \ then the "
        if(valRecList != null) {
            String ret = "";
            for(RecordVal valRec:valRecList)
                ret += valRec.toString();
            return ret;
        }

        return "";
    }
    
    public static String fixLongString(String toFix){
        //max line length have to be 8192
        StringBuilder str = new StringBuilder(toFix);
        int index = 4000;
        while(index<toFix.length()){
            str.insert(index, "\"\r\n\"");
            index+=4000;
        }
            
        return str.toString();
    }
}
