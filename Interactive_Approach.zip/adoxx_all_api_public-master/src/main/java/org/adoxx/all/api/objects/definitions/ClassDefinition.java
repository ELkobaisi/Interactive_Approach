package org.adoxx.all.api.objects.definitions;

import org.adoxx.all.api.primitive.Identifier;

public class ClassDefinition {

    private Identifier identifier = null;
    private Identifier superCalssIdentifier = null;
    
    public ClassDefinition(Identifier identifier, Identifier superCalssIdentifier) throws Exception {
        if(identifier == null || superCalssIdentifier == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.superCalssIdentifier = superCalssIdentifier;
    }

    public Identifier getId(){
        return this.identifier;
    }
    
    public Identifier getSuperClassId(){
        return this.superCalssIdentifier;
    }
    
    @Override
    public String toString(){
        return "CLASS " + identifier.toString() + " : " + superCalssIdentifier.toString() + "\n\n";
    }
}
