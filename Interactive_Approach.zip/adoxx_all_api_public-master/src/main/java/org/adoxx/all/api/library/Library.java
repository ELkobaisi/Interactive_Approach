package org.adoxx.all.api.library;

import java.util.ArrayList;

import org.adoxx.all.api.objects.Class;
import org.adoxx.all.api.objects.RelationClass;
import org.adoxx.all.api.primitive.Identifier;

public class Library {

    private ArrayList<Class> classList = new ArrayList<Class>();
    private ArrayList<RelationClass> relationClassList = new ArrayList<RelationClass>();
    
    private boolean isDynamic;
    
    public Library(boolean isDynamic){
        this.isDynamic = isDynamic;
    }
    
    public void addClass(Class classToAdd) throws Exception{
        if(classToAdd == null)
            throw new Exception("Not Allowed");
        
        if(classList.contains(classToAdd))
            throw new Exception("A Class with id " + classToAdd.getId().toString() + " has been already defined");

        if(classToAdd.hasSuperClassId()){
            if(!this.hasClassDefinition(classToAdd.getSuperClassId()))
                throw new Exception("Impossible to add the class " + classToAdd.getId().getRaw() + " because its superclass " + classToAdd.getSuperClassId().getRaw() + " is not present");
        } else {
            if(!this.hasClassDefinition(classToAdd.getId()) && !((classToAdd.getId().getRaw().equals("__D-construct__") && this.isDynamic) || (classToAdd.getId().getRaw().equals("__S-construct__") && !this.isDynamic)))
                throw new Exception("A Class with id " + classToAdd.getId().toString() + " has never been defined");
        }
        
        classList.add(classToAdd);
        classToAdd.setLibrary(this);
        classToAdd.chackAllAddedAttributes();
    }
    
    public void addRelationClass(RelationClass relationClassToAdd) throws Exception{
        if(relationClassToAdd == null)
            throw new Exception("Not Allowed");
        
        if(relationClassList.contains(relationClassToAdd))
            throw new Exception("A Relation Class with id " + relationClassToAdd.getId().toString() + " has been already defined");
        
        if(relationClassToAdd.hasFromTo()){
            if(!this.hasClassDefinition(relationClassToAdd.getIdFrom()))
                throw new Exception("Impossible to add the relation " + relationClassToAdd.getId().getRaw() + " because its FROM class " + relationClassToAdd.getIdFrom().getRaw() + " is not present");
            if(!this.hasClassDefinition(relationClassToAdd.getIdTo()))
                throw new Exception("Impossible to add the relation " + relationClassToAdd.getId().getRaw() + " because its TO class " + relationClassToAdd.getIdTo().getRaw() + " is not present");
        } else {
            if(!this.hasRelationDefinition(relationClassToAdd.getId()))
                throw new Exception("A RelationClass with id " + relationClassToAdd.getId().toString() + " has never been defined");
        }
        
        relationClassList.add(relationClassToAdd);
        relationClassToAdd.setLibrary(this);
        relationClassToAdd.chackAllAddedAttributes();
    }

    public boolean hasClass(String classId) {
        return hasClass(new Identifier(classId));
    }
    
    public boolean hasClass(Identifier classId) {
        for(Class clazz:classList)
            if(clazz.getId().equals(classId))
                return true;
        return false;
    }
    
    public boolean hasClassDefinition(String classId) {
        return hasClassDefinition(new Identifier(classId));
    }
    
    public boolean hasClassDefinition(Identifier classId) {
        for(Class clazz:classList)
            if(clazz.getId().equals(classId))
                if(clazz.hasSuperClassId() || (classId.getRaw().equals("__D-construct__") && this.isDynamic) || (classId.getRaw().equals("__S-construct__") && !this.isDynamic))
                    return true;
        return false;
    }
    
    public Class[] getClasses(){
        Class[] ret = new Class[classList.size()];
        classList.toArray(ret);
        return ret;
    }
    
    public Class[] getClasses(String classId){
        return getClasses(new Identifier(classId));
    }
    
    public Class[] getClasses(Identifier classId){
        ArrayList<Class> ret = new ArrayList<Class>();
        for(Class clazz:classList)
            if(clazz.getId().equals(classId))
                ret.add(clazz);
        Class[] retA = new Class[ret.size()];
        ret.toArray(retA);
        return retA;
    }
    
    public Class getClassDefinition(String classId) throws Exception{
        return getClassDefinition(new Identifier(classId));
    }
    
    public Class getClassDefinition(Identifier classId) throws Exception {
        for(Class clazz:classList)
            if(clazz.getId().equals(classId))
                if(clazz.hasSuperClassId() || (classId.getRaw().equals("__D-construct__") && this.isDynamic) || (classId.getRaw().equals("__S-construct__") && !this.isDynamic))
                    return clazz;
        
        throw new Exception("Impossible to find a Class definition with id " + classId);
    }

    public boolean hasRelation(String relationId) {
        return hasRelation(new Identifier(relationId));
    }
    
    public boolean hasRelation(Identifier relationId){
        for(RelationClass relationClass:relationClassList)
            if(relationClass.getId().equals(relationId))
                return true;
        return false;
    }
    
    public boolean hasRelationDefinition(String relationId) {
        return hasRelationDefinition(new Identifier(relationId));
    }
    
    public boolean hasRelationDefinition(Identifier relationId){
        for(RelationClass relationClass:relationClassList)
            if(relationClass.getId().equals(relationId) && relationClass.hasFromTo())
                return true;
        return false;
    }
    
    public RelationClass[] getRelations(){
        RelationClass[] ret = new RelationClass[relationClassList.size()];
        relationClassList.toArray(ret);
        return ret;
    }
    
    public RelationClass[] getRelations(String relationId){
        return getRelations(new Identifier(relationId));
    }
    
    public RelationClass[] getRelations(Identifier relationId){
        ArrayList<RelationClass> ret = new ArrayList<RelationClass>();
        for(RelationClass relationClass:relationClassList)
            if(relationClass.getId().equals(relationId))
                ret.add(relationClass);
        RelationClass[] retA = new RelationClass[ret.size()];
        ret.toArray(retA);
        return retA;
    }
    
    public RelationClass getRelationDefinition(String relationId) throws Exception{
        return getRelationDefinition(new Identifier(relationId));
    }
    
    public RelationClass getRelationDefinition(Identifier relationId) throws Exception{
        for(RelationClass relationClass:relationClassList)
            if(relationClass.getId().equals(relationId) && relationClass.hasFromTo())
                return relationClass;

        throw new Exception("Impossible to find a Relation Class definition with id " + relationId);
    }
    
    @Override
    public String toString(){
        String ret = "";
        for(Class clazz:classList)
            if(!clazz.isInternal())
                ret += clazz.toString();
        for(RelationClass clazz:relationClassList)
            if(!clazz.isInternal())
                ret += clazz.toString();
        
        return ret;
    }
}
