package org.adoxx.all.api.objects.redef.definitions;

import org.adoxx.all.api.primitive.Identifier;

public class RedefRelationClassDefinition {

    private Identifier identifier = null;
    
    public RedefRelationClassDefinition(Identifier identifier) throws Exception {
        if(identifier == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
    }
    
    public Identifier getId(){
        return identifier;
    }

    @Override
    public String toString(){
        return "RELATIONCLASS " + identifier.toString() + "\n\n";
    }
}
