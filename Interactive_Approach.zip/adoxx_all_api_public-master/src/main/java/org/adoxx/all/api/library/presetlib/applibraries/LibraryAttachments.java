package org.adoxx.all.api.library.presetlib.applibraries;

import org.adoxx.all.api.primitive.Identifier;

public class LibraryAttachments {

    private Identifier bplIdentifier = null;
    private Identifier welIdentifier = null;
    private boolean initializedWithBPL = false;
    
    public LibraryAttachments(Identifier identifier, boolean isBusinessProcessLibrary) throws Exception{
        if(identifier == null)
            throw new Exception("Not Allowed");
        
        initializedWithBPL = isBusinessProcessLibrary;
        if(isBusinessProcessLibrary)
            bplIdentifier = identifier;
        else
            welIdentifier = identifier;
    }
    
    public Identifier getAttachedLibraryId(){
        if(initializedWithBPL)
            return bplIdentifier;
        else
            return welIdentifier;
    }
    
    public boolean isFirstLibraryAttachedDynamic(){
        return initializedWithBPL;
    }
    
    public Identifier getSecondAttachedLibraryId(){
        if(initializedWithBPL)
            return welIdentifier;
        else
            return bplIdentifier;
    }
    
    public LibraryAttachments(Identifier identifier, boolean isBusinessProcessLibrary, Identifier secondLibraryIdentifier) throws Exception{
        if(identifier == null)
            throw new Exception("Not Allowed");
        
        initializedWithBPL = isBusinessProcessLibrary;
        if(isBusinessProcessLibrary){
            bplIdentifier = identifier;
            welIdentifier = secondLibraryIdentifier;
        }else{
            welIdentifier = identifier;
            bplIdentifier = secondLibraryIdentifier;
        }
    }
    
    public void setBusinessProcessLibrary(Identifier identifier) throws Exception{
        if(bplIdentifier!=null || identifier == null)
            throw new Exception("Not Allowed");
        bplIdentifier = identifier;
    }
    
    public void setWorkingEnvironmentLibrary(Identifier identifier) throws Exception{
        if(welIdentifier!=null || identifier == null)
            throw new Exception("Not Allowed");
        welIdentifier = identifier;
    }
    
    @Override
    public String toString(){
        String ret = "";
        if(initializedWithBPL){
            ret += "BUSINESS PROCESS LIBRARY " + bplIdentifier.toString() + "\n\n";
            if(welIdentifier!=null)
                ret += "WORKING ENVIRONMENT LIBRARY " + welIdentifier.toString() + "\n\n";
        } else {
            ret += "WORKING ENVIRONMENT LIBRARY " + welIdentifier.toString() + "\n\n";
            if(bplIdentifier!=null)
                ret += "BUSINESS PROCESS LIBRARY " + bplIdentifier.toString() + "\n\n";
        }
        
        return ret;
    }
}
