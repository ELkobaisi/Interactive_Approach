package org.adoxx.all.abstracted;

import java.util.ArrayList;

import org.adoxx.all.api.library.presetlib.ApplicationLibraries;
import org.adoxx.all.api.library.presetlib.Libraries;
import org.adoxx.all.api.library.presetlib.applibraries.ApplicationLibraryDefinition;
import org.adoxx.all.api.library.presetlib.applibraries.LibraryAttachments;
import org.adoxx.all.api.library.presetlib.libraries.BpLibrary;
import org.adoxx.all.api.library.presetlib.libraries.WeLibrary;
import org.adoxx.all.api.primitive.Identifier;

/**
 * <h1>ADOApplicationLibraryExtend</h1>
 * Represent the ALL file structure relative to the library extension (libraries  applicationlibraries) and contain methods related to it. 
 * 
 * @author Damiano Falcioni
 */
public class ADOApplicationLibraryExtend {
    
    public ADOAllFile parentAllFile = null;
    
    public ApplicationLibraries applicationLibraries = null;
    public Libraries libraries = null;
    
    /**
     * Generate an instance of this class
     */
    public ADOApplicationLibraryExtend(){
        libraries = new Libraries();
        applicationLibraries = new ApplicationLibraries();
    }
    
    /**
     * Add an extension library. An exception is generated if the library does not extend a previous library (the library must have a super library id)
     * @param adoLibrary The ADOLibrary that extend a previous library (it must have the idSuperLibrary defined)
     * @return ADOApplicationLibraryExtend This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryExtend addLibrary(ADOLibrary adoLibrary) throws Exception{
        if(adoLibrary.bpLibrary == null && adoLibrary.weLibrary == null)
            throw new Exception("The library must have the idSuperLibrary setted");
        
        if(adoLibrary.bpLibrary != null)
            libraries.addLibrary(adoLibrary.bpLibrary);
        if(adoLibrary.weLibrary != null)
            libraries.addLibrary(adoLibrary.weLibrary);
        return this;
    }
    
    /**
     * Get an array of all the previously added libraries
     * @return ArrayList&lt;ADOLibrary&gt; An Array containing all the added libraries
     */
    public ArrayList<ADOLibrary> getLibraries(){
        ArrayList<ADOLibrary> ret = new ArrayList<ADOLibrary>();
        for(BpLibrary bpLibrary: libraries.bpLibraryList)
            ret.add(new ADOLibrary(bpLibrary));
        for(WeLibrary weLibrary: libraries.weLibraryList)
            ret.add(new ADOLibrary(weLibrary));
        return ret;
    }
    
    /**
     * Get an array of all the dynamic libraries previously added 
     * @return ArrayList&lt;ADOLibrary&gt; An Array containing all the dynamic libraries added 
     */
    public ArrayList<ADOLibrary> getDynamicLibraries(){
        ArrayList<ADOLibrary> ret = new ArrayList<ADOLibrary>();
        for(BpLibrary bpLibrary: libraries.bpLibraryList)
            ret.add(new ADOLibrary(bpLibrary));
        return ret;
    }
    
    /**
     * Get an array of all the static libraries previously added 
     * @return ArrayList&lt;ADOLibrary&gt; An Array containing all the static libraries added 
     */
    public ArrayList<ADOLibrary> getStaticLibraries(){
        ArrayList<ADOLibrary> ret = new ArrayList<ADOLibrary>();
        for(WeLibrary weLibrary: libraries.weLibraryList)
            ret.add(new ADOLibrary(weLibrary));
        return ret;
    }
    
    /**
     * Finds the added dynamic library with the provided Id or throw an exception if nothing is found
     * @param libraryId The Id of the dynamic library to return 
     * @return ADOLibrary The library with the provided Id
     * @throws Exception in case of error
     */
    public ADOLibrary findDynamicLibrary(String libraryId) throws Exception{
        return new ADOLibrary(libraries.findDynamicLibrary(libraryId));
    }
    
    /**
     * Finds the added static library with the provided Id or throw an exception if nothing is found
     * @param libraryId The Id of the static library to return 
     * @return ADOLibrary The library with the provided Id
     * @throws Exception in case of error
     */
    public ADOLibrary findStaticLibrary(String libraryId) throws Exception{
        return new ADOLibrary(libraries.findStaticLibrary(libraryId));
    }
    
    /**
     * Add an application library
     * @param id The application library id
     * @param superId The application library super Id
     * @param libraryIdToAttach The id of the library to attach
     * @param isDynamicLibraryAttached Indicate if the attached library is dynamic or not
     * @param otherLibraryIdToAttach The Id of another library to attach
     * @return ADOApplicationLibraryExtend This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryExtend addApplicationLibrary(String id, String superId, String libraryIdToAttach, boolean isDynamicLibraryAttached, String otherLibraryIdToAttach) throws Exception {
        applicationLibraries.addApplicationLibrary(applicationLibraries.new ApplicationLibraryDefinition_LibraryAttachments(new ApplicationLibraryDefinition(new Identifier(id), new Identifier(superId)), new LibraryAttachments(new Identifier(libraryIdToAttach), isDynamicLibraryAttached, new Identifier(otherLibraryIdToAttach))));
        return this;
    }
    
    /**
     * Add an application library
     * @param id The application library id
     * @param superId The application library super Id
     * @param libraryIdToAttach The id of the library to attach
     * @param isDynamicLibraryAttached Indicate if the attached library is dynamic or not
     * @return ADOApplicationLibraryExtend This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryExtend addApplicationLibrary(String id, String superId, String libraryIdToAttach, boolean isDynamicLibraryAttached) throws Exception {
        applicationLibraries.addApplicationLibrary(applicationLibraries.new ApplicationLibraryDefinition_LibraryAttachments(new ApplicationLibraryDefinition(new Identifier(id), new Identifier(superId)), new LibraryAttachments(new Identifier(libraryIdToAttach), isDynamicLibraryAttached)));
        return this;
    }
    
    /**
     * Import all the classes and relations from another ADOApplicationLibraryExtend object
     * @param otherApplicationLibraryExtend The application library extended object from where import the classes and relations
     * @return ADOApplicationLibraryExtend This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryExtend importClassesAndRelations(ADOApplicationLibraryExtend otherApplicationLibraryExtend) throws Exception{
        if(otherApplicationLibraryExtend == null)
            throw new Exception("Incompatible libraries: The provided ADOApplicationLibraryExtend is null");
        
        String log = "";
        for(ADOLibrary otherLib : otherApplicationLibraryExtend.getDynamicLibraries()){
            ADOLibrary lib = this.findDynamicLibrary(otherLib.getId().getRaw());
            
            for(ADOClass adoClass : otherLib.getClasses())
                if(!lib.hasClass(adoClass.getId()))
                    lib.addClass(adoClass);
                else
                    log += "Skipped ADOClass "+adoClass.getId()+"\n";
                
            for(ADORelation adoRelation : otherLib.getRelations())
                if(!lib.hasRelation(adoRelation.getId()))
                    lib.addRelation(adoRelation);
                else
                    log += "Skipped ADORelation "+adoRelation.getId()+"\n";
        }
        for(ADOLibrary otherLib : otherApplicationLibraryExtend.getStaticLibraries()){
            ADOLibrary lib = this.findStaticLibrary(otherLib.getId().getRaw());
            
            for(ADOClass adoClass : otherLib.getClasses())
                if(!lib.hasClass(adoClass.getId()))
                    lib.addClass(adoClass);
                else
                    log += "Skipped ADOClass "+adoClass.getId()+"\n";
            
            for(ADORelation adoRelation : otherLib.getRelations())
                if(!lib.hasRelation(adoRelation.getId()))
                    lib.addRelation(adoRelation);
                else
                    log += "Skipped ADORelation "+adoRelation.getId()+"\n";
        }
        
        System.err.println(log);
        return this;
    }
}
