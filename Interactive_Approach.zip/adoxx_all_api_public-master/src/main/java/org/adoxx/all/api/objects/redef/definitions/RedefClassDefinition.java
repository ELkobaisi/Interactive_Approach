package org.adoxx.all.api.objects.redef.definitions;

import org.adoxx.all.api.primitive.Identifier;

public class RedefClassDefinition {

    private Identifier identifier = null;
    
    public RedefClassDefinition(Identifier identifier) throws Exception {
        if(identifier == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
    }

    public Identifier getId(){
        return identifier;
    }

    @Override
    public String toString(){
        return "CLASS " + identifier.toString() + "\n\n";
    }
}
