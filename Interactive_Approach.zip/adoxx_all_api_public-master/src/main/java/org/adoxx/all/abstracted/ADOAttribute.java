package org.adoxx.all.abstracted;

import java.util.ArrayList;

import org.adoxx.all.api.objects.Attribute;
import org.adoxx.all.api.objects.InstanceAttribute;
import org.adoxx.all.api.objects.definitions.AttributeDefinition;
import org.adoxx.all.api.objects.definitions.ClassAttributeDefinition;
import org.adoxx.all.api.objects.definitions.FacetDefinition;
import org.adoxx.all.api.objects.definitions.InstanceAttributeDefinition;
import org.adoxx.all.api.objects.redef.RedefAttribute;
import org.adoxx.all.api.objects.redef.RedefInstanceAttribute;
import org.adoxx.all.api.objects.redef.definitions.RedefAttributeDefinition;
import org.adoxx.all.api.objects.redef.definitions.RedefClassAttributeDefinition;
import org.adoxx.all.api.objects.redef.definitions.RedefInstanceAttributeDefinition;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;

/**
 * <h1>ADOAttribute</h1>
 * Represent the ALL file structure relative to an Attribute in ADOxx and contain methods related to it. 
 * 
 * @author Damiano Falcioni
 */
public class ADOAttribute {

    private Attribute attribute = null;
    private RedefAttribute redefAttribute = null;
    private InstanceAttribute instanceAttribute = null;
    private RedefInstanceAttribute redefInstanceAttribute = null;
    
    private boolean isClassAttribute = false;
    private boolean isRecordAttribute = false;
    private Identifier id = null;
    private Val value = null;
    private TypeIdentifier type = null;
    
    /**
     * Generate an instance of this class automatically identifying the best constructor for the provided parameters
     * @param id The id of the attribute
     * @param value A value for the attribute. It can be null if needed
     * @param type The type of the attribute. It can be null if the attribute is already defined and this is a redefinition
     * @param isClassAttribute Specify if the attribute is a Class Attribute or an Instance Attribute
     * @param isRecordAttribute Specify if the attribute is a Record Attribute (TYPE RECORD)
     * @return ADOAttribute An instance of this class
     * @throws Exception in case of error
     */
    public static ADOAttribute factory(Identifier id, Val value, TypeIdentifier type, boolean isClassAttribute, boolean isRecordAttribute) throws Exception{
        ADOAttribute ret = null;
        if(value == null && type == null)
            ret = new ADOAttribute(isClassAttribute, id, isRecordAttribute);
        else if(value != null && type == null)
            ret = new ADOAttribute(isClassAttribute, id, value);
        else if(value == null && type != null)
            ret = new ADOAttribute(isClassAttribute, id, type);
        else
            ret = new ADOAttribute(isClassAttribute, id, type, value);
        
        return ret;
    }
    
    protected ADOAttribute(Attribute attribute) throws Exception{
        this.isClassAttribute = attribute.attributeDefinition.classAttributeDefinition != null;
        this.isRecordAttribute = (this.isClassAttribute)?(attribute.attributeDefinition.classAttributeDefinition.getType() == null && attribute.attributeDefinition.classAttributeDefinition.getValue() == null):(attribute.attributeDefinition.instanceAttributeDefinition.getType() == null && attribute.attributeDefinition.instanceAttributeDefinition.getValue() == null);
        this.id = (this.isClassAttribute)?attribute.attributeDefinition.classAttributeDefinition.getId():attribute.attributeDefinition.instanceAttributeDefinition.getId();
        this.value = (this.isClassAttribute)?attribute.attributeDefinition.classAttributeDefinition.getValue():attribute.attributeDefinition.instanceAttributeDefinition.getValue();
        this.type = (this.isClassAttribute)?attribute.attributeDefinition.classAttributeDefinition.getType():attribute.attributeDefinition.instanceAttributeDefinition.getType();
        
        ADOAttribute thisA = ADOAttribute.factory(id, value, type, isClassAttribute, isRecordAttribute);
        thisA.addFacet(attribute.getFacets());
        this.attribute = thisA.attribute;
        this.redefAttribute = thisA.redefAttribute;
        this.instanceAttribute = thisA.instanceAttribute;
        this.redefInstanceAttribute = thisA.redefInstanceAttribute;
    }
    
    protected ADOAttribute(RedefAttribute redefAttribute) throws Exception{
        this.isClassAttribute = redefAttribute.redefAttributeDefinition.redefClassAttributeDefinition != null;
        this.isRecordAttribute = this.isClassAttribute?redefAttribute.redefAttributeDefinition.redefClassAttributeDefinition.isRecord():redefAttribute.redefAttributeDefinition.redefInstanceAttributeDefinition.isRecord();
        this.id = (this.isClassAttribute)?redefAttribute.redefAttributeDefinition.redefClassAttributeDefinition.getId():redefAttribute.redefAttributeDefinition.redefInstanceAttributeDefinition.getId();
        this.value = (this.isClassAttribute)?redefAttribute.redefAttributeDefinition.redefClassAttributeDefinition.getValue():redefAttribute.redefAttributeDefinition.redefInstanceAttributeDefinition.getValue();
        this.type = (this.isClassAttribute)?redefAttribute.redefAttributeDefinition.redefClassAttributeDefinition.getType():redefAttribute.redefAttributeDefinition.redefInstanceAttributeDefinition.getType();
        
        ADOAttribute thisA = ADOAttribute.factory(id, value, type, isClassAttribute, isRecordAttribute);
        thisA.addFacet(redefAttribute.getFacets());
        this.attribute = thisA.attribute;
        this.redefAttribute = thisA.redefAttribute;
        this.instanceAttribute = thisA.instanceAttribute;
        this.redefInstanceAttribute = thisA.redefInstanceAttribute;
    }
    
    protected ADOAttribute(InstanceAttribute instanceAttribute) throws Exception{
        this.isClassAttribute = false;
        this.isRecordAttribute = instanceAttribute.instanceAttributeDefinition.getType() == null && instanceAttribute.instanceAttributeDefinition.getValue() == null;
        this.id = instanceAttribute.instanceAttributeDefinition.getId();
        this.value = instanceAttribute.instanceAttributeDefinition.getValue();
        this.type = instanceAttribute.instanceAttributeDefinition.getType();
        
        ADOAttribute thisA = ADOAttribute.factory(id, value, type, isClassAttribute, isRecordAttribute);
        thisA.addFacet(instanceAttribute.getFacets());
        this.attribute = thisA.attribute;
        this.redefAttribute = thisA.redefAttribute;
        this.instanceAttribute = thisA.instanceAttribute;
        this.redefInstanceAttribute = thisA.redefInstanceAttribute;
    }
    
    protected ADOAttribute(RedefInstanceAttribute redefInstanceAttribute) throws Exception{
        this.isClassAttribute = false;
        this.isRecordAttribute = redefInstanceAttribute.redefInstanceAttributeDefinition.isRecord();
        this.id = redefInstanceAttribute.redefInstanceAttributeDefinition.getId();
        this.value = redefInstanceAttribute.redefInstanceAttributeDefinition.getValue();
        this.type = redefInstanceAttribute.redefInstanceAttributeDefinition.getType();
        
        ADOAttribute thisA = ADOAttribute.factory(id, value, type, isClassAttribute, isRecordAttribute);
        thisA.addFacet(redefInstanceAttribute.getFacets());
        this.attribute = thisA.attribute;
        this.redefAttribute = thisA.redefAttribute;
        this.instanceAttribute = thisA.instanceAttribute;
        this.redefInstanceAttribute = thisA.redefInstanceAttribute;
    }
    
    /**
     * Create a new ADOxx Attribute
     * @param isClassAttribute Specify if the attribute is a Class Attribute or an Instance Attribute
     * @param id The id of the attribute
     * @param isRecordAttribute Specify if the attribute is a Record Attribute (TYPE RECORD)
     * @throws Exception in case of error
     */
    public ADOAttribute(boolean isClassAttribute, String id, boolean isRecordAttribute) throws Exception {
        this(isClassAttribute, new Identifier(id), isRecordAttribute);
    }
    
    /**
     * Create a new ADOxx Attribute
     * @param isClassAttribute Specify if the attribute is a Class Attribute or an Instance Attribute
     * @param id The id of the attribute
     * @param isRecordAttribute Specify if the attribute is a Record Attribute (TYPE RECORD)
     * @throws Exception in case of error
     */
    public ADOAttribute(boolean isClassAttribute, Identifier id, boolean isRecordAttribute) throws Exception {
        this.isClassAttribute = isClassAttribute;
        this.isRecordAttribute = isRecordAttribute;
        this.id = id;

        if(isClassAttribute){
            if(isRecordAttribute){
                attribute = new Attribute(new AttributeDefinition(new ClassAttributeDefinition(this.id)));
            }
            redefAttribute = new RedefAttribute(new RedefAttributeDefinition(new RedefClassAttributeDefinition(this.id, isRecordAttribute)));
        }else{
            if(isRecordAttribute){
                attribute = new Attribute(new AttributeDefinition(new InstanceAttributeDefinition(this.id)));
                instanceAttribute = new InstanceAttribute(new InstanceAttributeDefinition(this.id));
            }
            redefAttribute = new RedefAttribute(new RedefAttributeDefinition(new RedefInstanceAttributeDefinition(this.id, isRecordAttribute)));
            redefInstanceAttribute = new RedefInstanceAttribute(new RedefInstanceAttributeDefinition(this.id, isRecordAttribute));
        }        
    }
    
    /**
     * Create a new ADOxx Attribute
     * @param isClassAttribute Specify if the attribute is a Class Attribute or an Instance Attribute
     * @param id The id of the attribute
     * @param type The type of the attribute
     * @throws Exception in case of error
     */
    public ADOAttribute(boolean isClassAttribute, String id, TypeIdentifier type) throws Exception {
        this(isClassAttribute, new Identifier(id), type);
    }
    
    /**
     * Create a new ADOxx Attribute
     * @param isClassAttribute Specify if the attribute is a Class Attribute or an Instance Attribute
     * @param id The id of the attribute
     * @param type The type of the attribute
     * @throws Exception in case of error
     */
    public ADOAttribute(boolean isClassAttribute, Identifier id, TypeIdentifier type) throws Exception {
        this.isClassAttribute = isClassAttribute;
        this.id = id;
        this.type = type;
        
        if(isClassAttribute){
            attribute = new Attribute(new AttributeDefinition(new ClassAttributeDefinition(this.id, type)));
            redefAttribute = new RedefAttribute(new RedefAttributeDefinition(new RedefClassAttributeDefinition(this.id, type)));
        }else{
            attribute = new Attribute(new AttributeDefinition(new InstanceAttributeDefinition(this.id, type)));
            instanceAttribute = new InstanceAttribute(new InstanceAttributeDefinition(this.id, type));
            redefAttribute = new RedefAttribute(new RedefAttributeDefinition(new RedefInstanceAttributeDefinition(this.id, type)));
            redefInstanceAttribute = new RedefInstanceAttribute(new RedefInstanceAttributeDefinition(this.id, type));
        }
    }
    
    /**
     * Create a new ADOxx Attribute
     * @param isClassAttribute Specify if the attribute is a Class Attribute or an Instance Attribute
     * @param id The id of the attribute
     * @param type The type of the attribute
     * @param value A value for the attribute
     * @throws Exception in case of error
     */
    public ADOAttribute(boolean isClassAttribute, String id, TypeIdentifier type, Val value) throws Exception {
        this(isClassAttribute, new Identifier(id), type, value);
    }
    
    /**
     * Create a new ADOxx Attribute
     * @param isClassAttribute Specify if the attribute is a Class Attribute or an Instance Attribute
     * @param id The id of the attribute
     * @param type The type of the attribute
     * @param value A value for the attribute
     * @throws Exception in case of error
     */
    public ADOAttribute(boolean isClassAttribute, Identifier id, TypeIdentifier type, Val value) throws Exception {
        this.isClassAttribute = isClassAttribute;
        this.id = id;
        this.type = type;
        this.value = value;
        
        if(isClassAttribute){
            attribute = new Attribute(new AttributeDefinition(new ClassAttributeDefinition(this.id, type, value)));
            redefAttribute = new RedefAttribute(new RedefAttributeDefinition(new RedefClassAttributeDefinition(this.id, type, value)));
        }else{
            attribute = new Attribute(new AttributeDefinition(new InstanceAttributeDefinition(this.id, type, value)));
            instanceAttribute = new InstanceAttribute(new InstanceAttributeDefinition(this.id, type, value));
            redefAttribute = new RedefAttribute(new RedefAttributeDefinition(new RedefInstanceAttributeDefinition(this.id, type, value)));
            redefInstanceAttribute = new RedefInstanceAttribute(new RedefInstanceAttributeDefinition(this.id, type, value));
        }
    }
    
    /**
     * Create a new ADOxx Attribute
     * @param isClassAttribute Specify if the attribute is a Class Attribute or an Instance Attribute
     * @param id The id of the attribute
     * @param value A value for the attribute
     * @throws Exception in case of error
     */
    public ADOAttribute(boolean isClassAttribute, String id, Val value) throws Exception {
        this(isClassAttribute, new Identifier(id), value);
    }
    
    /**
     * Create a new ADOxx Attribute
     * @param isClassAttribute Specify if the attribute is a Class Attribute or an Instance Attribute
     * @param id The id of the attribute
     * @param value A value for the attribute
     * @throws Exception in case of error
     */
    public ADOAttribute(boolean isClassAttribute, Identifier id, Val value) throws Exception {
        this.isClassAttribute = isClassAttribute;
        this.id = id;
        this.value = value;
        
        if(isClassAttribute){
            attribute = new Attribute(new AttributeDefinition(new ClassAttributeDefinition(this.id, value)));
            redefAttribute = new RedefAttribute(new RedefAttributeDefinition(new RedefClassAttributeDefinition(this.id, value)));
        }else{
            attribute = new Attribute(new AttributeDefinition(new InstanceAttributeDefinition(this.id, value)));
            instanceAttribute = new InstanceAttribute(new InstanceAttributeDefinition(this.id, value));
            redefAttribute = new RedefAttribute(new RedefAttributeDefinition(new RedefInstanceAttributeDefinition(this.id, value)));
            redefInstanceAttribute = new RedefInstanceAttribute(new RedefInstanceAttributeDefinition(this.id, value));
        }
    }
    
    /**
     * Check if the attribute is a Class Attribute or an Instance Attribute
     * @return boolean True if the attribute is a Class Attribute, false if is an Instance Attribute
     */
    public boolean isClassAttribute(){
        return isClassAttribute;
    }
    
    /**
     * Check if the attribute is a Record Attribute
     * @return boolean True if the attribute is a Record Attribute, false if not
     */
    public boolean isRecordAttribute(){
        return isRecordAttribute;
    }
    
    /**
     * Get the attribute id
     * @return Identifier The Id of this attribute
     */
    public Identifier getId(){
        return id;
    }
    
    /**
     * Get the attribute value
     * @return Val The value of this attribute
     */
    public Val getValue(){
        return this.value;
    }
    
    /**
     * Get the attribute type
     * @return TypeIdentifier The type of this attribute
     */
    public TypeIdentifier getType(){
        return this.type;
    }
    
    protected Attribute getAttribute() throws Exception{
        if(attribute == null)
            throw new Exception("(id:"+id+") Attribute not defined: If no value and type are specified, the isRecordAttribute must be true");
        return attribute;
    }
    
    protected InstanceAttribute getInstanceAttribute() throws Exception{
        if(instanceAttribute == null)
            throw new Exception("InstanceAttribute not defined: If no value and type are specified, the isRecordAttribute must be true, and the isClassAttribute must be false");
        return instanceAttribute;
    }
    
    protected RedefAttribute getRedefAttribute() throws Exception{
        return redefAttribute;
    }
    
    protected RedefInstanceAttribute getRedefInstanceAttribute() throws Exception{
        if(redefInstanceAttribute == null)
            throw new Exception("RedefInstanceAttribute not defined: the isClassAttribute must be false");
        return redefInstanceAttribute;
    }
    
    /**
     * Add a facet to the attribute. If a facet definition with the same id is already present, an exception raise
     * @param facet The facet definition to add
     * @return ADOAttribute This object
     * @throws Exception in case of error
     */
    public ADOAttribute addFacet(FacetDefinition facet) throws Exception{
        if(attribute != null)
            attribute.addFacet(facet);
        if(instanceAttribute != null)
            instanceAttribute.addFacet(facet);
        if(redefAttribute != null)
            redefAttribute.addFacet(facet);
        if(redefInstanceAttribute != null)
            redefInstanceAttribute.addFacet(facet);
        return this;
    }
    
    /**
     * Add a list of facets to the attribute. If a facet definition with the same id is already present, an exception raise
     * @param facetList The list of facet definition to add
     * @return ADOAttribute This object
     * @throws Exception in case of error
     */
    public ADOAttribute addFacet(FacetDefinition[] facetList) throws Exception{
        for(FacetDefinition facet:facetList)
            addFacet(facet);
        return this;
    }
    
    /**
     * Add a list of facets to the attribute. If a facet definition with the same id is already present, an exception raise
     * @param facetList The list of facet definition to add
     * @return ADOAttribute This object
     * @throws Exception in case of error
     */
    public ADOAttribute addFacet(ArrayList<FacetDefinition> facetList) throws Exception{
        for(FacetDefinition facet:facetList)
            addFacet(facet);
        return this;
    }
    
    /**
     * Find a specific facet. If the facet definition is not present, an exception raise
     * @param facetId The id of the facet to find
     * @return Val The value of the facet
     * @throws Exception in case of error
     */
    public Val findFacetValue(String facetId) throws Exception{
        
        if(attribute != null)
            return attribute.findFacetValue(facetId);
        if(instanceAttribute != null)
            return instanceAttribute.findFacetValue(facetId);
        if(redefAttribute != null)
            return redefAttribute.findFacetValue(facetId);
        if(redefInstanceAttribute != null)
            return redefInstanceAttribute.findFacetValue(facetId);
        
        throw new Exception("No attribute defined");
    }
    
    /**
     * Set the value of a facet into the attribute. If the facet is not present it is created
     * @param facetId The id of the facet to set
     * @param value The value to assign to the facet
     * @return ADOAttribute This object
     * @throws Exception in case of error
     */
    public ADOAttribute setFacetValue(String facetId, Val value) throws Exception{
        if(attribute != null) {
            if(attribute.hasFacet(facetId))
                attribute.findFacetValue(facetId).set(value);
            else
                attribute.addFacet(FacetDefinition.factory(new Identifier(facetId), null, value));
        }
        if(instanceAttribute != null) {
            if(instanceAttribute.hasFacet(facetId))
                instanceAttribute.findFacetValue(facetId).set(value);
            else
                instanceAttribute.addFacet(FacetDefinition.factory(new Identifier(facetId), null, value));
        }
        if(redefAttribute != null) {
            if(redefAttribute.hasFacet(facetId))
                redefAttribute.findFacetValue(facetId).set(value);
            else
                redefAttribute.addFacet(FacetDefinition.factory(new Identifier(facetId), null, value));
        }
        if(redefInstanceAttribute != null) {
            if(redefInstanceAttribute.hasFacet(facetId))
                redefInstanceAttribute.findFacetValue(facetId).set(value);
            else
                redefInstanceAttribute.addFacet(FacetDefinition.factory(new Identifier(facetId), null, value));
        }
        return this;
    }
    
    /**
     * Set the value of a facet into the attribute. If the facet is not present it is created
     * @param facetDefinition The definition of the facet to set. It must contain a value definition or an exception raise
     * @return ADOAttribute This object
     * @throws Exception in case of error
     */
    public ADOAttribute setFacetValue(FacetDefinition facetDefinition) throws Exception{
        String facetId = facetDefinition.getId().getRaw();
        Val value = facetDefinition.getValue();
        TypeIdentifier type = facetDefinition.getType();
        
        if(attribute != null) {
            if(attribute.hasFacet(facetId))
                attribute.findFacetValue(facetId).set(value);
            else
                attribute.addFacet(FacetDefinition.factory(new Identifier(facetId), type, value));
        }
        if(instanceAttribute != null) {
            if(instanceAttribute.hasFacet(facetId))
                instanceAttribute.findFacetValue(facetId).set(value);
            else
                instanceAttribute.addFacet(FacetDefinition.factory(new Identifier(facetId), type, value));
        }
        if(redefAttribute != null) {
            if(redefAttribute.hasFacet(facetId))
                redefAttribute.findFacetValue(facetId).set(value);
            else
                redefAttribute.addFacet(FacetDefinition.factory(new Identifier(facetId), type, value));
        }
        if(redefInstanceAttribute != null) {
            if(redefInstanceAttribute.hasFacet(facetId))
                redefInstanceAttribute.findFacetValue(facetId).set(value);
            else
                redefInstanceAttribute.addFacet(FacetDefinition.factory(new Identifier(facetId), type, value));
        }
        return this;
    }
    
    /**
     * Set the value of a list of facets into the attribute. If a facet is not present it is created
     * @param facetDefinitionList The list of facet's definition to set. Eachone must contain a value definition or an exception raise
     * @return ADOAttribute This object
     * @throws Exception in case of error
     */
    public ADOAttribute setFacetValue(FacetDefinition[] facetDefinitionList) throws Exception{
        for(FacetDefinition facetDefinition:facetDefinitionList)
            this.setFacetValue(facetDefinition);
        return this;
    }
    
    /**
     * Set the value of a list of facets into the attribute. If a facet is not present it is created
     * @param facetDefinitionList The list of facet's definition to set. Each one must contain a value definition or an exception raise
     * @return ADOAttribute This object
     * @throws Exception in case of error
     */
    public ADOAttribute setFacetValue(ArrayList<FacetDefinition> facetDefinitionList) throws Exception{
        for(FacetDefinition facetDefinition:facetDefinitionList)
            this.setFacetValue(facetDefinition);
        return this;
    }

    /**
     * Get the list of all the defined facets for this object
     * @return ArrayList&lt;FacetDefinition&gt; The list of all the added facets
     */
    public ArrayList<FacetDefinition> getFacets(){
        ArrayList<FacetDefinition> ret = new ArrayList<FacetDefinition>();
        for(FacetDefinition facet : redefAttribute.getFacets())
            ret.add(facet);
        return ret;
    }
    
    /**
     * Add the ADOxx default facets to this object depending on the type of attribute
     * @return ADOAttribute This object
     * @throws Exception in case of error
     */
    public ADOAttribute addADOxxDefaultFacets() throws Exception{
        if(type == null)
            return this;
        
        switch(type){
            case STRING:
            case LONGSTRING:
            case DATE:
            case DATETIME:
            case EXPRESSION:
            case TIME:
                this.addFacet(new FacetDefinition(new Identifier("MultiLineString"), new Val(0)));
                this.addFacet(new FacetDefinition(new Identifier("AttributeHelpText"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("AttributeRegularExpression"), new Val("")));
                break;
            case INTEGER:
            case DOUBLE:
                this.addFacet(new FacetDefinition(new Identifier("MultiLineString"), new Val(0)));
                this.addFacet(new FacetDefinition(new Identifier("AttributeHelpText"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("AttributeRegularExpression"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("AttributeNumericDomain"), new Val("")));
                break;
            case ENUMERATION:
            case ENUMERATIONLIST:
            case PROGRAMCALL:
                this.addFacet(new FacetDefinition(new Identifier("MultiLineString"), new Val(0)));
                this.addFacet(new FacetDefinition(new Identifier("AttributeHelpText"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("AttributeRegularExpression"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("EnumerationDomain"), new Val("")));
                break;
            case INTERREF:
                this.addFacet(new FacetDefinition(new Identifier("MultiLineString"), new Val(0)));
                this.addFacet(new FacetDefinition(new Identifier("AttributeHelpText"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("AttributeRegularExpression"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("AttributeInterRefDomain"), new Val("REFDOMAIN")));
                break;
            case ATTRPROFREF:
                this.addFacet(new FacetDefinition(new Identifier("MultiLineString"), new Val(0)));
                this.addFacet(new FacetDefinition(new Identifier("AttributeHelpText"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("AttributeRegularExpression"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("AttributeProfileRefDomain"), new Val("APREF c:\"\"")));
                break;
            case RECORD:
                this.addFacet(new FacetDefinition(new Identifier("MultiLineString"), new Val(0)));
                this.addFacet(new FacetDefinition(new Identifier("AttributeHelpText"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("AttributeRegularExpression"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("RecordClassName"), new Val("")));
                this.addFacet(new FacetDefinition(new Identifier("RecordClassMultiplicity"), new Val(0)));
                break;
            default:
                throw new Exception("Type " + type + " not recognized");
        }

        return this;
    }
}
