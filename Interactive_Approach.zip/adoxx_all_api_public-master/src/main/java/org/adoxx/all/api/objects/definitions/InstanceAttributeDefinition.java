package org.adoxx.all.api.objects.definitions;

import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;

public class InstanceAttributeDefinition {

    private Identifier identifier = null;
    private TypeIdentifier type = null;
    private Val value = null;
    
    public InstanceAttributeDefinition(Identifier identifier) throws Exception {
        if(identifier == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
    }
    
    public InstanceAttributeDefinition(Identifier identifier, TypeIdentifier type) throws Exception {
        if(identifier == null || type == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.type = type;
    }
    
    public InstanceAttributeDefinition(Identifier identifier, TypeIdentifier type, Val value) throws Exception {
        if(identifier == null || type == null || value == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.type = type;
        this.value = value;
    }

    public InstanceAttributeDefinition(Identifier identifier, Val value) throws Exception {
        if(identifier == null || value == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.value = value;
    }
    
    public Identifier getId(){
        return this.identifier;
    }
    
    public TypeIdentifier getType(){
        return this.type;
    }
    
    public Val getValue(){
        return this.value;
    }
    
    public boolean isRecord(){
        return this.type == null && this.value == null;
    }
    
    @Override
    public String toString(){
        String ret = "ATTRIBUTE " + identifier.toString() + "\n";
        if(type!=null)
            ret += " TYPE " + type.toString() + "\n";
        if(value!=null)
            ret += " VALUE " + value.toString() + "\n";
        if(type==null && value==null)
            ret += " TYPE RECORD\n";
        ret += "\n";
        
        return ret;
    }
}
