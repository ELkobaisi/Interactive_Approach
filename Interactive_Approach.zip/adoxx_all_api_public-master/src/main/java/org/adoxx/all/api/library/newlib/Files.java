package org.adoxx.all.api.library.newlib;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.Val;

public class Files {

    private HashMap<Identifier, Val> fileList = new HashMap<Identifier, Val>();
    
    public Files addFile(Identifier identifier, Val valBase64) throws Exception{
        if(identifier == null || valBase64 == null)
            throw new Exception("Not Allowed");
        
        if(fileList.containsKey(identifier)){
            if(fileList.get(identifier).getRaw().equals(valBase64.getRaw()))
                return this;
            else
                throw new Exception("A File with id " + identifier.toString() + " has been already defined");
        }
        
        fileList.put(identifier, valBase64);
        return this;
    }
    
    public Set<Identifier> getFileList(){
        return fileList.keySet();
    }
    
    public boolean hasFile(String fileId) {
        if(fileList.containsKey(new Identifier(fileId)))
            return true;
        else
            return false;
    }
    
    public Val findFileValue(String fileId) throws Exception{
        return findFileValue(new Identifier(fileId));
    }
    
    public Val findFileValue(Identifier fileId) throws Exception{
        Val ret = fileList.get(fileId);
        if(ret == null)
            throw new Exception("Impossible to find an file with id " + fileId);
        
        return ret;
    }
    
    @Override
    public String toString(){
        String ret = "";
        for(Entry<Identifier, Val> entry:fileList.entrySet())
            ret += "FILE " + entry.getKey().toString() + "\nCONTENT " + entry.getValue().toFixedString() + "\n\n";
        return ret;
    }
}
