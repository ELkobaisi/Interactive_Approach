package org.adoxx.all.api.library.presetlib;

import java.util.ArrayList;

import org.adoxx.all.api.library.presetlib.libraries.BpLibrary;
import org.adoxx.all.api.library.presetlib.libraries.WeLibrary;
import org.adoxx.all.api.primitive.Identifier;

public class Libraries {

    public ArrayList<BpLibrary> bpLibraryList = new ArrayList<BpLibrary>();
    public ArrayList<WeLibrary> weLibraryList = new ArrayList<WeLibrary>();
    
    public void addLibrary(BpLibrary library) throws Exception{
        if(library == null)
            throw new Exception("Not Allowed");
        
        bpLibraryList.add(library);
    }
    
    public void addLibrary(WeLibrary library) throws Exception{
        if(library == null)
            throw new Exception("Not Allowed");
        
        weLibraryList.add(library);
    }

    public BpLibrary findDynamicLibrary(String libraryId) throws Exception{
        for(BpLibrary bpLibrary:bpLibraryList)
            if(bpLibrary.getId().equals(new Identifier(libraryId)))
                return bpLibrary;

        throw new Exception("Impossible to find a Dynamic Library with id " + libraryId);
    }
    
    public WeLibrary findStaticLibrary(String libraryId) throws Exception{
        for(WeLibrary weLibrary:weLibraryList)
            if(weLibrary.getId().equals(new Identifier(libraryId)))
                return weLibrary;

        throw new Exception("Impossible to find a Static Library with id " + libraryId);
    }
    
    @Override
    public String toString(){
        String ret = "";
        for(BpLibrary bpLibrary:bpLibraryList)
            ret += bpLibrary.toString();
        for(WeLibrary weLibrary:weLibraryList)
            ret += weLibrary.toString();
        
        return ret;
    }
}
