package org.adoxx.all.api.library.presetlib;

import java.util.ArrayList;

import org.adoxx.all.api.library.presetlib.applibraries.ApplicationLibraryDefinition;
import org.adoxx.all.api.library.presetlib.applibraries.LibraryAttachments;
import org.adoxx.all.api.primitive.Identifier;

public class ApplicationLibraries {

    public class ApplicationLibraryDefinition_LibraryAttachments{
        private ApplicationLibraryDefinition applicationLibraryDefinition = null;
        private LibraryAttachments libraryArrachments = null;
        
        public ApplicationLibraryDefinition_LibraryAttachments(ApplicationLibraryDefinition applicationLibraryDefinition, LibraryAttachments libraryArrachments) throws Exception{
            if(applicationLibraryDefinition == null || libraryArrachments == null)
                throw new Exception("Not Allowed");
            
            this.applicationLibraryDefinition = applicationLibraryDefinition;
            this.libraryArrachments = libraryArrachments;
        }
        
        public Identifier getId(){
            return this.applicationLibraryDefinition.getId();
        }
        
        public Identifier getSuperLibId(){
            return this.applicationLibraryDefinition.getSuperLibId();
        }
        
        public Identifier getAttachedLibraryId(){
            return this.libraryArrachments.getAttachedLibraryId();
        }
        
        public boolean isFirstLibraryAttachedDynamic(){
            return this.libraryArrachments.isFirstLibraryAttachedDynamic();
        }
        
        public Identifier getSecondAttachedLibraryId(){
            return this.libraryArrachments.getSecondAttachedLibraryId();
        }
        
        @Override
        public String toString(){
            return applicationLibraryDefinition.toString() + libraryArrachments.toString();
        }
    }
    
    private ArrayList<ApplicationLibraryDefinition_LibraryAttachments> libraryList = new ArrayList<ApplicationLibraryDefinition_LibraryAttachments>();

    public void addApplicationLibrary(ApplicationLibraryDefinition_LibraryAttachments library){
        libraryList.add(library);
    }
    
    public ApplicationLibraryDefinition_LibraryAttachments findApplicationLibrary(String libraryId) throws Exception{
        for(ApplicationLibraryDefinition_LibraryAttachments library:libraryList)
            if(library.getId().equals(new Identifier(libraryId)))
                return library;

        throw new Exception("Impossible to find a library with id " + libraryId);
    }
    
    @Override
    public String toString(){
        String ret = "";
        for(ApplicationLibraryDefinition_LibraryAttachments library: libraryList)
            ret += library.toString();
        return ret;
    }
}
