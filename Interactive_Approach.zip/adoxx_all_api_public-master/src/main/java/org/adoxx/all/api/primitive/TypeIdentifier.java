package org.adoxx.all.api.primitive;

public enum TypeIdentifier {
    DATE,
    DATETIME,
    DOUBLE,
    ENUMERATION,
    ENUMERATIONLIST,
    EXPRESSION,
    INTEGER,
    INTERREF,
    LONGSTRING,
    ATTRPROFREF,
    PROGRAMCALL,
    RECORD,
    STRING,
    TIME    
}
