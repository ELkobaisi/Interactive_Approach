package org.adoxx.all.api.library.newlib;

import java.util.ArrayList;

import org.adoxx.all.api.objects.Attribute;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.Val;

public class RecordClass {

    private Identifier identifier = null;
    private Identifier superClassIdentifier = null;
    private ArrayList<Attribute> attributeList = new ArrayList<Attribute>();
    
    public static RecordClass factory(Identifier identifier, Identifier superClassIdentifier) throws Exception {
        if(superClassIdentifier != null)
            return new RecordClass(identifier, superClassIdentifier);
        else
            return new RecordClass(identifier);
    }
    
    public RecordClass(Identifier identifier, Identifier superClassIdentifier) throws Exception {
        if(identifier == null || superClassIdentifier == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.superClassIdentifier = superClassIdentifier;
    }
    
    public RecordClass(Identifier identifier) throws Exception {
        if(identifier == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.superClassIdentifier = new Identifier("RecordClass");
    }

    public void addAttribute(Attribute attribute) throws Exception{
        if(attribute == null)
            throw new Exception("Not Allowed");
        
        if(attributeList.contains(attribute))
            throw new Exception("An Attribute with id " + attribute.getId().toString() + " has been already defined for the Record Class " + this.getId().toString());
        
        attributeList.add(attribute);
    }
    
    public Identifier getId(){
        return identifier;
    }
    
    public Identifier getSuperClassId(){
        return superClassIdentifier;
    }
    
    public Val findAttributeValue(String attributeId) throws Exception{
        for(Attribute attribute:attributeList)
            if(attribute.getId().equals(new Identifier(attributeId)))
                return attribute.getValue();

        throw new Exception("Impossible to find an attribute with id " + attributeId);
    }
    
    @Override
    public int hashCode(){
        return getId().hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof RecordClass))
            return o==this;
        return ((RecordClass)o).getId().equals(this.getId());
    }
    
    @Override
    public String toString(){
        String ret = "RECORDCLASS " + identifier.toString() + " : " + superClassIdentifier.toString() + "\n\n";
        for(Attribute attribute:attributeList)
            ret += attribute.toString();
        return ret;
    }
}
