package org.adoxx.all.api.objects;

import java.util.ArrayList;

import org.adoxx.all.api.objects.definitions.AttributeDefinition;
import org.adoxx.all.api.objects.definitions.FacetDefinition;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;

public class Attribute implements AttributeI {

    public AttributeDefinition attributeDefinition = null;
    private ArrayList<FacetDefinition> facetList = new ArrayList<FacetDefinition>();
    
    public Attribute(AttributeDefinition attributeDefinition) throws Exception {
        if(attributeDefinition == null)
            throw new Exception("Not Allowed");
        
        this.attributeDefinition = attributeDefinition;
    }

    public void addFacet(FacetDefinition facet) throws Exception{
        if(facet == null)
            throw new Exception("Not Allowed");
        
        if(facetList.contains(facet))
            throw new Exception("A facet with id " + facet.getId().toString() + " has been already defined for the attribute " + this.getId().toString());
        
        facetList.add(facet);
    }
    
    public boolean hasFacet(String facetId) {
        for(FacetDefinition facet: facetList)
            if(facet.getId().equals(new Identifier(facetId)))
                return true;
        return false;
    }
    
    public Val findFacetValue(String facetId) throws Exception{
        for(FacetDefinition facet: facetList)
            if(facet.getId().equals(new Identifier(facetId)))
                return facet.getValue();
        
        throw new Exception("Impossible to find an facet with id " + facetId);
    }
    
    public Identifier getId(){
        return this.attributeDefinition.getId();
    }
    
    public TypeIdentifier getType(){
        return this.attributeDefinition.getType();
    }
    
    public Val getValue(){
        return this.attributeDefinition.getValue();
    }
    
    public boolean isRecord(){
        return this.attributeDefinition.isRecord();
    }
    
    public FacetDefinition[] getFacets(){
        FacetDefinition[] ret = new FacetDefinition[this.facetList.size()];
        this.facetList.toArray(ret);
        return ret;
    }
    
    public boolean isClassAttribute(){
        return this.attributeDefinition.classAttributeDefinition != null;
    }
    
    @Override
    public int hashCode(){
        /*
        if(this.getType() == null)
            if(this.isRecord())
                return 1013 *getId().hashCode() ^ 1009 * 2;
            else
                return getId().hashCode();
        else
            return 1013 *getId().hashCode() ^ 1009 *this.getType().toString().hashCode();
        */
        
        if(this.getType() != null || this.isRecord())
            return 1013 *getId().hashCode() ^ 1009 * 2;
        else
            return getId().hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof Attribute))
            return o==this;
        
        Attribute other = (Attribute)o;
        //return ((Attribute)o).getId().equals(this.getId()) && (((Attribute)o).getType() == this.getType()) && this.getType() != null;
        //return ((Attribute)o).getId().equals(this.getId()) && (((((Attribute)o).getType() == this.getType()) && this.getType() != null) || (((Attribute)o).isRecord() && this.isRecord()));
        return (other.getId().equals(this.getId())) && (this.getType() != null || this.isRecord()) && (other.getType() != null || other.isRecord());
    }
    
    @Override
    public String toString(){
        String ret = attributeDefinition.toString();
        for(FacetDefinition facet:facetList)
            ret += facet.toString();
        
        return ret;
    }
}
