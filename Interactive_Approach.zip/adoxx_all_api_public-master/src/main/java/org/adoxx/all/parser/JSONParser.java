package org.adoxx.all.parser;

import java.io.StringReader;
import java.util.ArrayList;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonValue.ValueType;

import org.adoxx.all.abstracted.ADOAllFile;
import org.adoxx.all.abstracted.ADOAttribute;
import org.adoxx.all.abstracted.ADOClass;
import org.adoxx.all.abstracted.ADORelation;
import org.adoxx.all.abstracted.factory.ADOLibFactory;
import org.adoxx.all.api.objects.definitions.FacetDefinition;
import org.adoxx.all.api.primitive.AttrVal;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;
import org.adoxx.utils.Utils;

public class JSONParser {
    
    private ADOAllFile adoAllFile = null;
    private JsonObject jsonModel = null;
    
    public JSONParser(String jsonString) throws Exception {
        this.jsonModel = Json.createReader(new StringReader(jsonString)).readObject();
    }
    
    public ADOAllFile getADOAllFile() throws Exception{
        if(this.adoAllFile == null)
            throw new Exception("xmlModel not parsed");
        return this.adoAllFile;
    }
    
    public JSONParser parse() throws Exception{
        /*
        JSON structure:
        
         {
             "libraryNew" : {
                 "id" : "",
                 "recordClassList" : [{
                     "id" : "",
                     "superId" : ".../null",
                     "attributeList" : [{
                         "id" : "",
                         "classAttribute" : true/false,
                         "type" : "STRING/.../RECORD/null",
                         "value" : "complex string.../null",
                         "facetList" : [{
                             "id" : "",
                             "type" : "STRING/.../null",
                             "value" : "complex string.../null"
                         }]
                     }]
                 }],
                 "attributeProfileList" : [...uguale recordClassList...],
                 "dynamicLib" : {
                     "libraryAttributeList" : [{
                         "id" : "",
                         "value" : "complex string..."
                     }],
                     "classList" : [{
                         "id" : "",
                         "superId" : ".../null",
                         "attributeList" : [{
                             "id" : "",
                             "classAttribute" : true/false,
                             "type" : "STRING/.../RECORD/null",
                             "value" : "complex string.../null",
                             "facetList" : [{
                                 "id" : "",
                                 "type" : "STRING/.../null",
                                 "value" : "complex string.../null"
                             }]
                         }]
                     }],
                     "relationList" : [{
                         "id" : "",
                         "fromId" : ".../null",
                         "toId" : ".../null",
                         "attributeList" : [{
                             "id" : "",
                             "type" : "STRING/.../RECORD/null",
                             "value" : "complex string.../null",
                             "facetList" : [{
                                 "id" : "",
                                 "type" : "STRING/.../null",
                                 "value" : "complex string.../null"
                             }]
                         }]
                     }]
                 },
                 "staticLib" : {...uguale a dynamicLib...},
                 "fileList" : [{
                     "id" : "",
                     "value" : "",
                     "path" : ""
                 }]
             }
         }
        */
        try {
            if(this.jsonModel.getJsonObject("libraryNew") != null) {
                JsonObject libraryNewJson = this.jsonModel.getJsonObject("libraryNew");
                String libraryId = libraryNewJson.getString("id");
                this.adoAllFile = ADOLibFactory.generateADOxxEmptyLibrary(libraryId);
                
                for(JsonObject recordClassJson : libraryNewJson.getJsonArray("recordClassList").getValuesAs(JsonObject.class)) {
                    String recordClassId = recordClassJson.getString("id");
                    String recordClassSuperId = recordClassJson.getString("superId", null);
                    ArrayList<ADOAttribute> recordClassAttributeList = parseAttributeList(recordClassJson.getJsonArray("attributeList"));
                    this.adoAllFile.getApplicationLibraryNew().addRecordClass(recordClassId, recordClassSuperId, recordClassAttributeList);
                }
                
                for(JsonObject attProfClassJson : libraryNewJson.getJsonArray("attributeProfileList").getValuesAs(JsonObject.class)) {
                    String attProfClassId = attProfClassJson.getString("id");
                    String attProfClassSuperId = attProfClassJson.getString("superId", null);
                    ArrayList<ADOAttribute> attProfClassAttributeList = parseAttributeList(attProfClassJson.getJsonArray("attributeList"));
                    this.adoAllFile.getApplicationLibraryNew().addAttrProf(attProfClassId, attProfClassSuperId, attProfClassAttributeList);
                }
                                
                for(JsonObject libraryAttributeJson : libraryNewJson.getJsonObject("dynamicLib").getJsonArray("libraryAttributeList").getValuesAs(JsonObject.class)) {
                    String libraryAttributeId = libraryAttributeJson.getString("id");
                    AttrVal libraryAttributeValue = null;
                    if(libraryAttributeJson.get("value").getValueType().compareTo(ValueType.STRING) == 0)
                        libraryAttributeValue = new AttrVal(libraryAttributeJson.getString("value"));
                    if(libraryAttributeJson.get("value").getValueType().compareTo(ValueType.NUMBER) == 0) {
                        if(libraryAttributeJson.getJsonNumber("value").isIntegral())
                            libraryAttributeValue = new AttrVal(libraryAttributeJson.getJsonNumber("value").intValue());
                        else
                            libraryAttributeValue = new AttrVal(libraryAttributeJson.getJsonNumber("value").doubleValue());
                    }
                    if(this.adoAllFile.getApplicationLibraryNew().getDynamicLibrary().hasAttribute(libraryAttributeId))
                        this.adoAllFile.getApplicationLibraryNew().getDynamicLibrary().findAttributeValue(libraryAttributeId).set(libraryAttributeValue);
                    else
                        this.adoAllFile.getApplicationLibraryNew().getDynamicLibrary().addLibraryAttribute(libraryAttributeId, libraryAttributeValue);
                }
                                
                for(JsonObject classJson : libraryNewJson.getJsonObject("dynamicLib").getJsonArray("classList").getValuesAs(JsonObject.class)) {
                    String classId = classJson.getString("id");
                    String classSuperId = classJson.getString("superId", null);
                    ADOClass adoClass = ADOClass.factory(classId, classSuperId);
                    ArrayList<ADOAttribute> classAttributeList = parseAttributeList(classJson.getJsonArray("attributeList"));
                    adoClass.setAttributeValue(classAttributeList);
                    this.adoAllFile.getApplicationLibraryNew().getDynamicLibrary().addClass(true, adoClass, true);
                }
                
                for(JsonObject relationJson : libraryNewJson.getJsonObject("dynamicLib").getJsonArray("relationList").getValuesAs(JsonObject.class)) {
                    String relationId = relationJson.getString("id");
                    String relationFromId = relationJson.getString("fromId", null);
                    String relationToId = relationJson.getString("toId", null);
                    ADORelation adoRelation = ADORelation.factory(relationId, relationFromId, relationToId);
                    ArrayList<ADOAttribute> relationAttributeList = parseAttributeList(relationJson.getJsonArray("attributeList"));
                    adoRelation.setAttributeValue(relationAttributeList);
                    this.adoAllFile.getApplicationLibraryNew().getDynamicLibrary().addRelation(true, adoRelation, true);
                }
                
                this.adoAllFile.getApplicationLibraryNew().getDynamicLibrary().finalizePostponedAdd();
                                
                for(JsonObject libraryAttributeJson : libraryNewJson.getJsonObject("staticLib").getJsonArray("libraryAttributeList").getValuesAs(JsonObject.class)) {
                    String libraryAttributeId = libraryAttributeJson.getString("id");
                    AttrVal libraryAttributeValue = null;
                    if(libraryAttributeJson.get("value").getValueType().compareTo(ValueType.STRING) == 0)
                        libraryAttributeValue = new AttrVal(libraryAttributeJson.getString("value"));
                    if(libraryAttributeJson.get("value").getValueType().compareTo(ValueType.NUMBER) == 0) {
                        if(libraryAttributeJson.getJsonNumber("value").isIntegral())
                            libraryAttributeValue = new AttrVal(libraryAttributeJson.getJsonNumber("value").intValue());
                        else
                            libraryAttributeValue = new AttrVal(libraryAttributeJson.getJsonNumber("value").doubleValue());
                    }
                    
                    if(this.adoAllFile.getApplicationLibraryNew().getStaticLibrary().hasAttribute(libraryAttributeId))
                        this.adoAllFile.getApplicationLibraryNew().getStaticLibrary().findAttributeValue(libraryAttributeId).set(libraryAttributeValue);
                    else
                        this.adoAllFile.getApplicationLibraryNew().getStaticLibrary().addLibraryAttribute(libraryAttributeId, libraryAttributeValue);
                }
                                
                for(JsonObject classJson : libraryNewJson.getJsonObject("staticLib").getJsonArray("classList").getValuesAs(JsonObject.class)) {
                    String classId = classJson.getString("id");
                    String classSuperId = classJson.getString("superId", null);
                    ADOClass adoClass = ADOClass.factory(classId, classSuperId);
                    ArrayList<ADOAttribute> classAttributeList = parseAttributeList(classJson.getJsonArray("attributeList"));
                    adoClass.setAttributeValue(classAttributeList);
                    this.adoAllFile.getApplicationLibraryNew().getStaticLibrary().addClass(true, adoClass, true);
                }
                
                for(JsonObject relationJson : libraryNewJson.getJsonObject("staticLib").getJsonArray("relationList").getValuesAs(JsonObject.class)) {
                    String relationId = relationJson.getString("id");
                    String relationFromId = relationJson.getString("fromId", null);
                    String relationToId = relationJson.getString("toId", null);
                    ADORelation adoRelation = ADORelation.factory(relationId, relationFromId, relationToId);
                    ArrayList<ADOAttribute> relationAttributeList = parseAttributeList(relationJson.getJsonArray("attributeList"));
                    adoRelation.setAttributeValue(relationAttributeList);
                    this.adoAllFile.getApplicationLibraryNew().getStaticLibrary().addRelation(true, adoRelation, true);
                }
                
                this.adoAllFile.getApplicationLibraryNew().getStaticLibrary().finalizePostponedAdd();
                
                for(JsonObject libraryAttributeJson : libraryNewJson.getJsonArray("fileList").getValuesAs(JsonObject.class)) {
                    String fileId = libraryAttributeJson.getString("id");
                    String fileValue = libraryAttributeJson.getString("value", null);
                    String filePath = libraryAttributeJson.getString("path", null);
                    if(fileValue == null || fileValue.isEmpty()) {
                        if(filePath == null || filePath.isEmpty())
                            throw new Exception("File value or path not defined for the file " + fileId);
                        fileValue = Utils.base64Encode(Utils.readFile(filePath));
                    }
                    if(this.adoAllFile.getApplicationLibraryNew().hasFile(fileId))
                        this.adoAllFile.getApplicationLibraryNew().findFileValue(fileId).set(fileValue);
                    else
                        this.adoAllFile.getApplicationLibraryNew().addFile(fileId, fileValue);
                }
            }
        } catch(Exception ex){
            Exception newEx = new Exception("Error processing the JSON file: " + ex.getMessage());
            newEx.setStackTrace(ex.getStackTrace());
            throw newEx;
        }
        
        return this;
    }
    
    private ArrayList<ADOAttribute> parseAttributeList(JsonArray attributeList) throws Exception{
        ArrayList<ADOAttribute> ret = new ArrayList<ADOAttribute>();
        
        for(JsonObject attributeJson : attributeList.getValuesAs(JsonObject.class)) {
            String id = attributeJson.getString("id");
            boolean classAttribute = attributeJson.getBoolean("classAttribute", false);
            TypeIdentifier type = attributeJson.getString("type", null)==null?null:(attributeJson.getString("type", null).equals("RECORD")?null:TypeIdentifier.valueOf(attributeJson.getString("type", null)));
            boolean isRecordAttribute = attributeJson.getString("type", null)!=null && attributeJson.getString("type", null).equals("RECORD")?true:false;
            Val val = null;
            if(attributeJson.get("value").getValueType().compareTo(ValueType.STRING) == 0)
                val = new Val(attributeJson.getString("value"));
            if(attributeJson.get("value").getValueType().compareTo(ValueType.NUMBER) == 0) {
                if(attributeJson.getJsonNumber("value").isIntegral())
                    val = new Val(attributeJson.getJsonNumber("value").intValue());
                else
                    val = new Val(attributeJson.getJsonNumber("value").doubleValue());                
            }
            
            ADOAttribute adoAttribute = ADOAttribute.factory(new Identifier(id), val, type, classAttribute, isRecordAttribute);
            adoAttribute.addADOxxDefaultFacets();
            
            for(JsonObject facetJson : attributeJson.getJsonArray("facetList").getValuesAs(JsonObject.class)) {
                String facetId = facetJson.getString("id");
                TypeIdentifier facetType = facetJson.getString("type", null)==null?null:TypeIdentifier.valueOf(facetJson.getString("type", null));
                Val facetVal = null;
                if(facetJson.get("value").getValueType().compareTo(ValueType.STRING) == 0)
                    facetVal = new Val(facetJson.getString("value"));
                if(facetJson.get("value").getValueType().compareTo(ValueType.NUMBER) == 0) {
                    if(facetJson.getJsonNumber("value").isIntegral())
                        facetVal = new Val(facetJson.getJsonNumber("value").intValue());
                    else
                        facetVal = new Val(facetJson.getJsonNumber("value").doubleValue());
                }
                adoAttribute.setFacetValue(FacetDefinition.factory(new Identifier(facetId), facetType, facetVal));
            }
            
            ret.add(adoAttribute);
        }
        
        return ret;
    }
}
