package org.adoxx.all.abstracted;

import org.adoxx.all.api.objects.definitions.ClassDefinition;
import org.adoxx.all.api.objects.redef.RedefAttribute;
import org.adoxx.all.api.objects.redef.definitions.RedefClassDefinition;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.Val;

import java.util.ArrayList;

import org.adoxx.ado.ADOUtils;
import org.adoxx.all.api.objects.Attribute;
import org.adoxx.all.api.objects.AttributeI;
import org.adoxx.all.api.objects.Class;

/**
 * <h1>ADOClass</h1>
 * Represent the ALL file structure relative to a Class in ADOxx and contain methods related to it. 
 * 
 * @author Damiano Falcioni
 */
public class ADOClass {

    public static final String defaultSuperIdDynamic = "__D-construct__";
    public static final String defaultSuperIdStatic = "__S-construct__";
    
    public static final String[] specialDynamicClasses = new String[]{
            "__ModelTypeMetaData__",
            "__LibraryMetaData__"
    };
    
    protected Class adoClass = null;
    
    private ClassDefinition classDefinition = null;
    private RedefClassDefinition redefClassDefinition = null;
    
    protected ADOClass(Class adoClass) throws Exception{
        this.adoClass = adoClass;
        this.classDefinition = adoClass.classDefinition;
        this.redefClassDefinition = adoClass.redefClassDefinition;
    }
    
    /**
     * Generate an instance of this class automatically identifying the best constructor for the provided parameters
     * @param classId The id of the class
     * @param superClassId The id of the superclass. It can be null if the class has been already defined
     * @return ADOClass An instance of this class
     * @throws Exception in case of error
     */
    public static ADOClass factory(String classId, String superClassId) throws Exception {
        if(superClassId == null)
            return new ADOClass(classId);
        else
            return new ADOClass(classId, superClassId);
    }
    
    /**
     * Create a new ADOxx Class
     * @param classId The id of the class
     * @throws Exception in case of error
     */
    public ADOClass(String classId) throws Exception {
        redefClassDefinition = new RedefClassDefinition(new Identifier(classId));
        adoClass = new Class(redefClassDefinition);
    }

    /**
     * Create a new ADOxx Class
     * @param classId The id of the class
     * @param superClassId The id of the superclass
     * @throws Exception in case of error
     */
    public ADOClass(String classId, String superClassId) throws Exception {
        classDefinition = new ClassDefinition(new Identifier(classId), new Identifier(superClassId));
        adoClass = new Class(classDefinition);
    }
    
    /**
     * Get the list of attributes defined for this class
     * @return ArrayList&lt;ADOAttribute&gt; The list of attributes defined
     * @throws Exception in case of error
     */
    public ArrayList<ADOAttribute> getAttributes() throws Exception{
        ArrayList<ADOAttribute> ret = new ArrayList<ADOAttribute>();
        
        for(Attribute attribute:adoClass.attributeList)
            ret.add(new ADOAttribute(attribute));
        for(RedefAttribute attribute:adoClass.redefAttributeList)
            ret.add(new ADOAttribute(attribute));
        
        return ret;
    }
    
    /**
     * Add an attribute to the class. If an attribute definition with the same id is already present, an exception raise
     * @param adoAttribute The attribute to add
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass addAttribute(ADOAttribute adoAttribute) throws Exception{
        if(classDefinition != null){
            this.adoClass.addAttribute(adoAttribute.getAttribute());
        } else {
            this.adoClass.addAttribute(adoAttribute.getRedefAttribute());
        }
        return this;
    }
    
    /**
     * Add a list of attributes to the class. If an attribute definition with the same id is already present, an exception raise
     * @param adoAttributeList The list of attributes to add
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass addAttribute(ADOAttribute[] adoAttributeList) throws Exception{
        for(ADOAttribute adoAttribute:adoAttributeList)
            addAttribute(adoAttribute);
        return this;
    }
    
    /**
     * Add a list of attributes to the class. If an attribute definition with the same id is already present, an exception raise
     * @param adoAttributeList The list of attributes to add
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass addAttribute(ArrayList<ADOAttribute> adoAttributeList) throws Exception{
        for(ADOAttribute adoAttribute:adoAttributeList)
            addAttribute(adoAttribute);
        return this;
    }
    
    /**
     * Remove a specific attributes from the class maintaining the library consistency
     * @param attributeId The id of the attribute to remove
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass removeAttribute(Identifier attributeId) throws Exception{
        adoClass.removeAttribute(attributeId);
        return this;
    }
    
    /**
     * Remove a specific attributes from the class maintaining the library consistency
     * @param attributeId The id of the attribute to remove
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass removeAttribute(String attributeId) throws Exception{
        adoClass.removeAttribute(attributeId);
        return this;
    }
    
    /**
     * Check if a specific attribute is present in the class
     * @param attributeId The id of the attribute to check
     * @return boolean True or false in case the attribute is present of not
     * @throws Exception in case of error
     */
    public boolean hasAttribute(Identifier attributeId) throws Exception{
        return adoClass.hasAttribute(attributeId);
    }
    
    /**
     * Check if a specific attribute is present in the class
     * @param attributeId The id of the attribute to check
     * @return boolean True or false in case the attribute is present of not
     * @throws Exception in case of error
     */
    public boolean hasAttribute(String attributeId) throws Exception{
        return adoClass.hasAttribute(attributeId);
    }
    
    /**
     * Check if a specific attribute definition (attribute with type) is present in the class
     * @param attributeId The id of the attribute to check
     * @return boolean True or false in case the attribute definition is present of not
     * @throws Exception in case of error
     */
    public boolean hasAttributeDefinition(Identifier attributeId) throws Exception{
        return adoClass.hasAttributeDefinition(attributeId);
    }
    
    /**
     * Check if a specific attribute definition (attribute with type) is present in the class
     * @param attributeId The id of the attribute to check
     * @return boolean True or false in case the attribute definition is present of not
     * @throws Exception in case of error
     */
    public boolean hasAttributeDefinition(String attributeId) throws Exception{
        return adoClass.hasAttributeDefinition(attributeId);
    }
    
    /**
     * Check the presence of a specific attribute definition (attribute with type) in the class and in all its super classes
     * @param attributeId The id of the attribute to check
     * @return boolean True or false in case the attribute definition is present of not in the class or in one of its super classes
     * @throws Exception in case of error
     */
    public boolean checkAttributeDefinitionPresence(String attributeId) throws Exception{
        return adoClass.checkAttributeDefinitionPresence(attributeId);
    }
    
    /**
     * Get a specific attribute definition (attribute with type) searching it in the class and in all its super classes. An exception raise if the attribute definition is not present
     * @param attributeId The id of the attribute to get
     * @return ADOAttribute The attribute definition
     * @throws Exception in case of error
     */
    public ADOAttribute getGeneralAttributeDefinition(String attributeId) throws Exception{
        AttributeI attribDef = adoClass.getGeneralAttributeDefinition(attributeId);
        if(attribDef instanceof Attribute)
            return new ADOAttribute((Attribute)attribDef);
        else
            return new ADOAttribute((RedefAttribute)attribDef);
    }
    
    /**
     * Get the class id
     * @return Identifier The Id of this class
     */
    public Identifier getId(){
        return this.adoClass.getId();
    }
    
    /**
     * Get the super class id. An Exception raise if the superclass has not been defined
     * @return Identifier The Id of this superclass
     * @throws Exception in case of error
     */
    public Identifier getSuperClassId() throws Exception{
        return this.adoClass.getSuperClassId();
    }
    
    /**
     * Check if the class has a super class id.
     * @return boolean True if the class has a super class id, false otherwise
     */
    public boolean hasSuperClassId() {
        return this.adoClass.hasSuperClassId();
    }
    
    /**
     * Find a specific attribute in this class. An exception raise if the attribute is not present
     * @param attributeId The id of the attribute to search
     * @return Val The value of the attribute
     * @throws Exception in case of error
     */
    public Val findAttributeValue(String attributeId) throws Exception{
        return this.adoClass.findAttributeValue(attributeId);
    }
    
    /**
     * Set the value of an attribute into the class. If the attribute is not present it is created
     * @param isClassAttribute Indicate if the attribute is a Class Attribute or an Instance Attribute
     * @param attributeId The id of the attribute to set
     * @param value The value to assign to the attribute
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass setAttributeValue(boolean isClassAttribute, String attributeId, Val value) throws Exception{
        if(this.hasAttribute(attributeId))
            this.findAttributeValue(attributeId).set(value);
        else
            this.addAttribute(new ADOAttribute(isClassAttribute, attributeId, value));
        return this;
    }
    
    /**
     * Set the value of an attribute into the class. If the attribute is not present it is created
     * @param adoAttribute The definition of the attribute to set. It must contain a value definition or an exception raise
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass setAttributeValue(ADOAttribute adoAttribute) throws Exception{
        
        if(adoAttribute.isRecordAttribute() || adoAttribute.getType()!=null) {
            this.addAttribute(adoAttribute);
        } else {
            if(this.hasAttribute(adoAttribute.getId().getRaw()))
                this.findAttributeValue(adoAttribute.getId().getRaw()).set(adoAttribute.getValue());
            else
                this.addAttribute(new ADOAttribute(adoAttribute.isClassAttribute(), adoAttribute.getId().getRaw(), adoAttribute.getValue()));
        }
        return this;
    }
    
    /**
     * Set the value of a list of attributes into the class. If an attribute is not present it is created
     * @param adoAttributeList The list of definitions of the attributes to set. It must contain a value definition or an exception raise
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass setAttributeValue(ADOAttribute[] adoAttributeList) throws Exception{
        for(ADOAttribute adoAttribute:adoAttributeList)
            setAttributeValue(adoAttribute);
        return this;
    }
    
    /**
     * Set the value of a list of attributes into the class. If an attribute is not present it is created
     * @param adoAttributeList The list of definitions of the attributes to set. It must contain a value definition or an exception raise
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass setAttributeValue(ArrayList<ADOAttribute> adoAttributeList) throws Exception{
        for(ADOAttribute adoAttribute:adoAttributeList)
            setAttributeValue(adoAttribute);
        return this;
    }
    
    /**
     * Set the value of the ClassAbstract attribute into the class. If the attribute is not present it is created
     * @param isAbstract The value of the ClassAbstract attribute. It can be 0 if the class is not abstract or 1 if it is
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass setClassAbrstractAttribute(int isAbstract) throws Exception{
        this.setAttributeValue(true, "ClassAbstract", new Val(isAbstract));
        return this;
    }
    
    /**
     * Set the value of the GraphRep attribute into the class. If the attribute is not present it is created
     * @param graphRep The value of the GraphRep attribute
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass setGraphRepAttribute(String graphRep) throws Exception{
        this.setAttributeValue(true, "GraphRep", new Val(graphRep));
        return this;
    }
    
    /**
     * Allow to specify an SVG image to be used as GraphRep. If the attribute is not present it is created
     * @param svgFilePath The path of the SVG image to be used inside the GraphRep
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass setGraphRepAttributeFromSVGFile(String svgFilePath) throws Exception{
        return setGraphRepAttribute(ADOUtils.callSVG2GRAPHREPTransformation(svgFilePath));
    }
    
    /**
     * Set the value of the AttrRep attribute into the class. If the attribute is not present it is created
     * @param attrRep The value of the AttrRep attribute
     * @return ADOClass This object
     * @throws Exception in case of error
     */
    public ADOClass setAttrRepAttribute(String attrRep) throws Exception{
        this.setAttributeValue(true, "AttrRep", new Val(attrRep));
        return this;
    }
    
    protected ADOClass setAsInternal(boolean isInternal){
        this.adoClass.setAsInternal(isInternal);
        return this;
    }
    
    /**
     * Check if the class is part of the internal ADOxx MetaModel or not. If is internal it will not be exported as ALL
     * @return boolean True if the class is internal, false otherwise
     */
    public boolean isInternal(){
        return this.adoClass.isInternal();
    }
}
