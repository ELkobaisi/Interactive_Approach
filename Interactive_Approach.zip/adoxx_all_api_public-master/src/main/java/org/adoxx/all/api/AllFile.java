package org.adoxx.all.api;

import org.adoxx.all.api.library.newlib.NewLib;
import org.adoxx.all.api.library.presetlib.ApplicationLibraries;
import org.adoxx.all.api.library.presetlib.Libraries;
import org.adoxx.all.api.library.presetlib.ApplicationLibraries.ApplicationLibraryDefinition_LibraryAttachments;
import org.adoxx.all.api.library.presetlib.libraries.BpLibrary;
import org.adoxx.all.api.library.presetlib.libraries.WeLibrary;

public class AllFile {
    
    private Version version = null;
    private Libraries libraries = null;
    public ApplicationLibraries applicationLibraries = null;
    private NewLib newLib = null;
    
    public AllFile(Version version, Libraries libraries, ApplicationLibraries applicationLibraries) throws Exception {
        if(version == null || libraries == null || applicationLibraries == null)
            throw new Exception("Not Allowed");
        
        this.version = version;
        this.libraries = libraries;
        this.applicationLibraries = applicationLibraries;
    }
    public AllFile(Version version, NewLib newLib) throws Exception {
        if(version == null || newLib == null)
            throw new Exception("Not Allowed");
        
        this.version = version;
        this.newLib = newLib;
    }
    
    public void setApplicationLibraries(ApplicationLibraries applicationLibraries){
        this.applicationLibraries = applicationLibraries;
    }
    
    public Version getVersion(){
        return version;
    }
    
    public BpLibrary findDynamicLibrary(String libraryId) throws Exception{
        if(this.libraries != null)
            return this.libraries.findDynamicLibrary(libraryId);
        else
            throw new Exception("This method can be used only if the ALL does not describe a new library");
    }
    
    public WeLibrary findStaticLibrary(String libraryId) throws Exception{
        if(this.libraries != null)
            return this.libraries.findStaticLibrary(libraryId);
        else
            throw new Exception("This method can be used only if the ALL does not describe a new library");
    }
    
    public ApplicationLibraryDefinition_LibraryAttachments findApplicationLibrary(String libraryId) throws Exception{
        if(this.applicationLibraries != null)
            return this.applicationLibraries.findApplicationLibrary(libraryId);
        else
            throw new Exception("This method can be used only if the ALL does not describe a new library");
    }
    
    public NewLib getNewLib(){
        return newLib;
    }
    
    
    @Override
    public String toString(){
        if(newLib != null)
            return version.toString() + newLib.toString();
        else
            return version.toString() + libraries.toString() + applicationLibraries.toString();
    }
    
    public String generateAll(){
        return toString();
    }
}
