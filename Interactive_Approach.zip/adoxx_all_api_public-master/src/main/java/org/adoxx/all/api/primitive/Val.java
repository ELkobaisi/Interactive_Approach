package org.adoxx.all.api.primitive;


public class Val {

    private Integer valInt = null;
    private Double valDouble = null;
    private String valS = null;
    
    public Val(int val) throws Exception{
        this.valInt = Integer.valueOf(val);
    }
    
    public Val(double val) throws Exception{
        this.valDouble = Double.valueOf(val);
    }
    
    public Val(String val) throws Exception{
        if(val == null)
            throw new Exception("Not Allowed");
        this.valS = val;
    }
    
    public Val(Val val) throws Exception{
        this.valS = val.valS;
        this.valDouble = val.valDouble;
        this.valInt = val.valInt;
    }
    
    public void set(int val) throws Exception{
        if(this.valInt == null)
            throw new Exception("The provided value do not match with the original one");
        this.valInt = Integer.valueOf(val);
    }
    
    public void set(double val) throws Exception{
        if(this.valDouble == null)
            throw new Exception("The provided value do not match with the original one");
        this.valDouble = Double.valueOf(val);
    }
    
    public void set(String val) throws Exception{
        if(this.valS == null)
            throw new Exception("The provided value do not match with the original one");
        this.valS = val;
    }
    
    public void set(Val val) throws Exception{
        this.valS = val.valS;
        this.valDouble = val.valDouble;
        this.valInt = val.valInt;
    }
    
    public String getRaw() {
        return getRaw(true);
    }
    
    public String getRaw(boolean escapeString){
        if(valInt != null)
            return valInt.toString();
        if(valDouble != null)
            return valDouble.toString();
        if(valS != null) {
            if(escapeString)
                return "\""+valS.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r\n", "\\n").replace("\n", "\\n")+"\"";
            else
                return "" + valS;
        }
        
        return "";
    }
    
    @Override
    public int hashCode(){
        return this.toString().hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof Val))
            return o==this;
        return ((Val) o).toString().equals(this.toString());
    }
    
    @Override
    public String toString(){
        if(valInt != null)
            return valInt.toString();
        if(valDouble != null)
            return valDouble.toString();
        if(valS != null)
            return "\""+valS.replace("\\", "\\\\").replace("\"", "\\\"")+"\"";
        
        return "";
    }
    
    public String toFixedString(){
        return fixLongString(toString());
    }
    
    private static String fixLongString(String toFix){
        //max line length have to be 8192
        StringBuilder str = new StringBuilder(toFix);
        int index = 4000;
        while(index<toFix.length()){
            str.insert(index, "\"\n\"");
            index+=4000;
        }
            
        return str.toString();
    }
}
