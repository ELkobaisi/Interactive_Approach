package org.adoxx.all.api.objects.redef.definitions;

import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;

public class RedefAttributeDefinition {

    public RedefClassAttributeDefinition redefClassAttributeDefinition = null;
    public RedefInstanceAttributeDefinition redefInstanceAttributeDefinition = null;
    
    public RedefAttributeDefinition(RedefClassAttributeDefinition redefClassAttributeDefinition) throws Exception{
        if(redefClassAttributeDefinition == null)
            throw new Exception("Not allowed");
        
        this.redefClassAttributeDefinition = redefClassAttributeDefinition;
    }
    
    public RedefAttributeDefinition(RedefInstanceAttributeDefinition redefInstanceAttributeDefinition) throws Exception{
        if(redefInstanceAttributeDefinition == null)
            throw new Exception("Not allowed");
        
        this.redefInstanceAttributeDefinition = redefInstanceAttributeDefinition;
    }
    
    public Identifier getId(){
        if(this.redefClassAttributeDefinition != null)
            return this.redefClassAttributeDefinition.getId();
        else
            return this.redefInstanceAttributeDefinition.getId();
    }
    
    public TypeIdentifier getType(){
        if(this.redefClassAttributeDefinition != null)
            return this.redefClassAttributeDefinition.getType();
        else
            return this.redefInstanceAttributeDefinition.getType();
    }
    
    public Val getValue(){
        if(this.redefClassAttributeDefinition != null)
            return this.redefClassAttributeDefinition.getValue();
        else
            return this.redefInstanceAttributeDefinition.getValue();
    }
    
    public boolean isRecord(){
        if(this.redefClassAttributeDefinition != null)
            return this.redefClassAttributeDefinition.isRecord();
        else
            return this.redefInstanceAttributeDefinition.isRecord();
    }
    
    @Override
    public String toString(){
        if(redefClassAttributeDefinition!=null)
            return redefClassAttributeDefinition.toString();
        else
            return redefInstanceAttributeDefinition.toString();
    }
}
