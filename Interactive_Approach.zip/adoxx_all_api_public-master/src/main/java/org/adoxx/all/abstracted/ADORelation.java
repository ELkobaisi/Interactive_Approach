package org.adoxx.all.abstracted;

import java.util.ArrayList;

import org.adoxx.all.api.objects.AttributeI;
import org.adoxx.all.api.objects.InstanceAttribute;
import org.adoxx.all.api.objects.RelationClass;
import org.adoxx.all.api.objects.definitions.RelationClassDefinition;
import org.adoxx.all.api.objects.redef.RedefInstanceAttribute;
import org.adoxx.all.api.objects.redef.definitions.RedefRelationClassDefinition;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;

/**
 * <h1>ADORelation</h1>
 * Represent the ALL file structure relative to a Relation in ADOxx and contain methods related to it. 
 * 
 * @author Damiano Falcioni
 */
public class ADORelation {

    protected RelationClass adoRelation = null;
    
    private RelationClassDefinition relationClassDefinition = null;
    private RedefRelationClassDefinition redefRelationClassDefinition = null;
    
    protected ADORelation(RelationClass adoRelation) throws Exception{
        this.adoRelation = adoRelation;
        this.relationClassDefinition = adoRelation.relationClassDefinition;
        this.redefRelationClassDefinition = adoRelation.redefRelationClassDefinition;       
    }
    
    /**
     * Generate an instance of this class automatically identifying the best constructor for the provided parameters
     * @param id The id of the relation
     * @param idFrom The id of the "form" class. It can be null if the relation has been already defined
     * @param idTo The id of the "to" class. It can be null if the relation has been already defined
     * @return ADORelation An instance of this class
     * @throws Exception in case of error
     */
    public static ADORelation factory(String id, String idFrom, String idTo) throws Exception {
        if(idFrom != null && idTo != null)
            return new ADORelation(id, idFrom, idTo);
        else
            return new ADORelation(id);
    }
    
    /**
     * Create a new ADOxx Relation
     * @param id The id of the relation
     * @throws Exception in case of error
     */
    public ADORelation(String id) throws Exception {
        redefRelationClassDefinition = new RedefRelationClassDefinition(new Identifier(id));
        adoRelation = new RelationClass(redefRelationClassDefinition);
        this.addADOxxDefaultAttributes();
    }
    
    /**
     * Create a new ADOxx Relation
     * @param id The id of the relation
     * @param idFrom The id of the "form" class
     * @param idTo The id of the "to" class
     * @throws Exception in case of error
     */
    public ADORelation(String id, Identifier idFrom, Identifier idTo) throws Exception {
        relationClassDefinition = new RelationClassDefinition(new Identifier(id), idFrom, idTo);
        adoRelation = new RelationClass(relationClassDefinition);
        if(!id.equals("Is inside"))
            this.addADOxxDefaultAttributes();
    }
    
    /**
     * Create a new ADOxx Relation
     * @param id The id of the relation
     * @param idFrom The id of the "form" class
     * @param idTo The id of the "to" class
     * @throws Exception in case of error
     */
    public ADORelation(String id, String idFrom, String idTo) throws Exception {
        this(id, new Identifier(idFrom), new Identifier(idTo));
    }
    
    /**
     * Create a new ADOxx Relation
     * @param id The id of the relation
     * @param classFrom The "form" class
     * @param classTo The "to" class
     * @throws Exception in case of error
     */
    public ADORelation(String id, ADOClass classFrom, ADOClass classTo) throws Exception {
        this(id, classFrom.getId(), classTo.getId());
    }
    
    /**
     * Get the list of attributes defined for this relation
     * @return ArrayList&lt;ADOAttribute&gt; The list of attributes defined
     * @throws Exception in case of error
     */
    public ArrayList<ADOAttribute> getAttributes() throws Exception{
        ArrayList<ADOAttribute> ret = new ArrayList<ADOAttribute>();
        
        for(InstanceAttribute attribute:adoRelation.attributeList)
            ret.add(new ADOAttribute(attribute));
        for(RedefInstanceAttribute attribute:adoRelation.redefAttributeList)
            ret.add(new ADOAttribute(attribute));
        
        return ret;
    }
    
    /**
     * Add an attribute to the relation. If an attribute definition with the same id is already present, an exception raise
     * @param adoAttribute The attribute to add
     * @return ADORelation This object
     * @throws Exception in case of error
     */
    public ADORelation addAttribute(ADOAttribute adoAttribute) throws Exception{
        if(adoAttribute.isClassAttribute())
            throw new Exception("Impossible to add a Class attribute (" + adoAttribute.getId().getRaw() + ") to a relation (" + this.getId().getRaw() + ")");
        if(relationClassDefinition != null){
            adoRelation.addInstanceAttribute(adoAttribute.getInstanceAttribute());
        } else {
            adoRelation.addInstanceAttribute(adoAttribute.getRedefInstanceAttribute());
        }
        return this;
    }
    
    /**
     * Add a list of attributes to the relation. If an attribute definition with the same id is already present, an exception raise
     * @param adoAttributeList The list of attributes to add
     * @return ADORelation This object
     * @throws Exception in case of error
     */
    public ADORelation addAttribute(ADOAttribute[] adoAttributeList) throws Exception{
        for(ADOAttribute adoAttribute:adoAttributeList)
            addAttribute(adoAttribute);
        return this;
    }
    
    /**
     * Add a list of attributes to the relation. If an attribute definition with the same id is already present, an exception raise
     * @param adoAttributeList The list of attributes to add
     * @return ADORelation This object
     * @throws Exception in case of error
     */
    public ADORelation addAttribute(ArrayList<ADOAttribute> adoAttributeList) throws Exception{
        for(ADOAttribute adoAttribute:adoAttributeList)
            addAttribute(adoAttribute);
        return this;
    }
    
    /**
     * Remove a specific attributes from the relation maintaining the library consistency
     * @param attributeId The id of the attribute to remove
     * @return ADORelation This object
     */
    public ADORelation removeAttribute(Identifier attributeId){
        adoRelation.removeInstanceAttribute(attributeId);
        return this;
    }
    
    /**
     * Remove a specific attributes from the relation maintaining the library consistency
     * @param attributeId The id of the attribute to remove
     * @return ADORelation This object
     * @throws Exception in case of error
     */
    public ADORelation removeAttribute(String attributeId) throws Exception{
        adoRelation.removeInstanceAttribute(attributeId);
        return this;
    }
    
    /**
     * Get the relation id
     * @return Identifier The Id of this relation
     */
    public Identifier getId(){
        return this.adoRelation.getId();
    }
    
    /**
     * Get the "from" class id
     * @return Identifier The Id of the "from" class
     * @throws Exception in case of error
     */
    public Identifier getIdFrom() throws Exception{
        return this.adoRelation.getIdFrom();
    }
    
    /**
     * Get the "to" class id
     * @return Identifier The Id of the "to" class
     * @throws Exception in case of error
     */
    public Identifier getIdTo() throws Exception{
        return this.adoRelation.getIdTo();
    }
    
    /**
     * Check if the relation has a definition ("from/to" classes defined).
     * @return boolean True if the class has "from/to" classes ids, false otherwise
     */
    public boolean hasFromTo(){
        return this.adoRelation.hasFromTo(); 
    }
    
    /**
     * Find a specific attribute in this relation. An exception raise if the attribute is not present
     * @param attributeId The id of the attribute to search
     * @return Val The value of the attribute
     * @throws Exception in case of error
     */
    public Val findAttributeValue(String attributeId) throws Exception{
        return this.adoRelation.findAttributeValue(attributeId);
    }
    
    /**
     * Find a specific attribute in this relation. An exception raise if the attribute is not present
     * @param attributeId The id of the attribute to search
     * @return Val The value of the attribute
     * @throws Exception in case of error
     */
    public Val findAttributeValue(Identifier attributeId) throws Exception{
        return this.adoRelation.findAttributeValue(attributeId);
    }
    
    /**
     * Check if a specific attribute is present in the relation
     * @param attributeId The id of the attribute to check
     * @return boolean True or false in case the attribute is present of not
     * @throws Exception in case of error
     */
    public boolean hasAttribute(String attributeId) throws Exception{
        return this.adoRelation.hasAttribute(attributeId);
    }
    
    /**
     * Check if a specific attribute is present in the relation
     * @param attributeId The id of the attribute to check
     * @return boolean True or false in case the attribute is present of not
     * @throws Exception in case of error
     */
    public boolean hasAttribute(Identifier attributeId) throws Exception{
        return this.adoRelation.hasAttribute(attributeId);
    }
    
    /**
     * Check if a specific attribute definition (attribute with type) is present in the relation
     * @param attributeId The id of the attribute to check
     * @return boolean True or false in case the attribute definition is present of not
     * @throws Exception in case of error
     */
    public boolean hasAttributeDefinition(Identifier attributeId) throws Exception{
        return this.adoRelation.hasAttributeDefinition(attributeId);
    }
    
    /**
     * Check if a specific attribute definition (attribute with type) is present in the relation
     * @param attributeId The id of the attribute to check
     * @return boolean True or false in case the attribute definition is present of not
     * @throws Exception in case of error
     */
    public boolean hasAttributeDefinition(String attributeId) throws Exception{
        return this.adoRelation.hasAttributeDefinition(attributeId);
    }
    
    /**
     * Check the presence of a specific attribute definition (attribute with type) in the relation and in all its previous definition
     * @param attributeId The id of the attribute to check
     * @return boolean True or false in case the attribute definition is present of not
     * @throws Exception in case of error
     */
    public boolean checkAttributeDefinitionPresence(String attributeId) throws Exception{
        return this.adoRelation.checkAttributeDefinitionPresence(attributeId);
    }
    
    /**
     * Get a specific attribute definition (attribute with type) searching it in the relation and in all its definition. An exception raise if the attribute definition is not present
     * @param attributeId The id of the attribute to get
     * @return ADOAttribute The attribute definition
     * @throws Exception in case of error
     */
    public ADOAttribute getGeneralAttributeDefinition(String attributeId) throws Exception{
        AttributeI attribDef = adoRelation.getGeneralAttributeDefinition(attributeId);
        if(attribDef instanceof InstanceAttribute)
            return new ADOAttribute((InstanceAttribute)attribDef);
        else
            return new ADOAttribute((RedefInstanceAttribute)attribDef);
    }
    
    /**
     * Set the value of an instance attribute into the relation. If the attribute is not present it is created
     * @param attributeId The id of the attribute to set
     * @param value The value to assign to the attribute
     * @return ADORelation This object
     * @throws Exception in case of error
     */
    public ADORelation setAttributeValue(String attributeId, Val value) throws Exception{
        if(this.hasAttribute(attributeId))
            this.findAttributeValue(attributeId).set(value);
        else
            this.addAttribute(new ADOAttribute(false, attributeId, value));        
        return this;
    }

    /**
     * Set the value of an attribute into the relation. If the attribute is not present it is created
     * @param adoAttribute The definition of the attribute to set. It must contain a value definition or an exception raise
     * @return ADORelation This object
     * @throws Exception in case of error
     */
    public ADORelation setAttributeValue(ADOAttribute adoAttribute) throws Exception{
        if(adoAttribute.isRecordAttribute() || adoAttribute.getType()!=null) {
            this.addAttribute(adoAttribute);
        } else {
            if(this.hasAttribute(adoAttribute.getId().getRaw()))
                this.findAttributeValue(adoAttribute.getId().getRaw()).set(adoAttribute.getValue());
            else
                this.addAttribute(new ADOAttribute(adoAttribute.isClassAttribute(), adoAttribute.getId().getRaw(), adoAttribute.getValue()));
        }
        return this;
    }
    
    /**
     * Set the value of a list of attributes into the relation. If an attribute is not present it is created
     * @param adoAttributeList The list of definitions of the attributes to set. It must contain a value definition or an exception raise
     * @return ADORelation This object
     * @throws Exception in case of error
     */
    public ADORelation setAttributeValue(ADOAttribute[] adoAttributeList) throws Exception{
        for(ADOAttribute adoAttribute:adoAttributeList)
            setAttributeValue(adoAttribute);
        return this;
    }
    
    /**
     * Set the value of a list of attributes into the relation. If an attribute is not present it is created
     * @param adoAttributeList The list of definitions of the attributes to set. It must contain a value definition or an exception raise
     * @return ADORelation This object
     * @throws Exception in case of error
     */
    public ADORelation setAttributeValue(ArrayList<ADOAttribute> adoAttributeList) throws Exception{
        for(ADOAttribute adoAttribute:adoAttributeList)
            setAttributeValue(adoAttribute);
        return this;
    }
    
    /**
     * Set the value of the GraphRep attribute into the relation. If the attribute is not present it is created
     * @param graphRep The value of the GraphRep attribute
     * @return ADORelation This object
     * @throws Exception in case of error
     */
    public ADORelation setGraphRepAttribute(String graphRep) throws Exception{
        this.setAttributeValue("GraphRep", new Val(graphRep));
        return this;
    }
    
    /**
     * Set the value of the AttrRep attribute into the relation. If the attribute is not present it is created
     * @param attrRep The value of the AttrRep attribute
     * @return ADORelation This object
     * @throws Exception in case of error
     */
    public ADORelation setAttrRepAttribute(String attrRep) throws Exception{
        this.setAttributeValue("AttrRep", new Val(attrRep));
        return this;
    }
    
    protected ADORelation setAsInternal(boolean isInternal){
        this.adoRelation.setAsInternal(isInternal);
        return this;
    }
    
    /**
     * Check if the relation is part of the internal ADOxx MetaModel or not. If is internal it will not be exported as ALL
     * @return boolean True if the relation is internal, false otherwise
     */
    public boolean isInternal(){
        return this.adoRelation.isInternal();
    }
    
    private ADORelation addADOxxDefaultAttributes() throws Exception{
        this.addAttribute(new ADOAttribute(false, "Positions", TypeIdentifier.STRING, new Val("")).addADOxxDefaultFacets());
        this.addAttribute(new ADOAttribute(false, "GraphRep", TypeIdentifier.STRING, new Val("")).addADOxxDefaultFacets());
        this.addAttribute(new ADOAttribute(false, "AttrRep", TypeIdentifier.STRING, new Val("")).addADOxxDefaultFacets());
        
        return this;
    }
}
