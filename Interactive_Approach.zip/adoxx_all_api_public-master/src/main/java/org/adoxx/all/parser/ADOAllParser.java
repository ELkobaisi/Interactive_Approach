package org.adoxx.all.parser;

import java.util.ArrayList;
import java.util.Date;

import org.adoxx.all.abstracted.ADOAllFile;
import org.adoxx.all.abstracted.ADOApplicationLibraryExtend;
import org.adoxx.all.abstracted.ADOApplicationLibraryNew;
import org.adoxx.all.abstracted.ADOAttribute;
import org.adoxx.all.abstracted.ADOClass;
import org.adoxx.all.abstracted.ADOLibrary;
import org.adoxx.all.abstracted.ADOLibrary.IdAttrVal;
import org.adoxx.all.abstracted.ADORelation;
import org.adoxx.all.api.Version;
import org.adoxx.all.api.library.newlib.Files;
import org.adoxx.all.api.objects.definitions.FacetDefinition;
import org.adoxx.all.api.primitive.AttrVal;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.RecordVal;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;
import org.adoxx.utils.Utils;

public class ADOAllParser {
    
    private ADOAllFile adoAllFile = null;
    private String adoAllJavaCode = null;
    
    private int index = 0;
    private String allModel = "";
    
    private IStatusMonitor monitor = null;
    private int monitoringIntervallSeconds = 1;
    
    public ADOAllParser(String allModel){
        this.allModel = allModel;
    }
    
    public ADOAllParser setMonitor(IStatusMonitor monitor, int monitoringIntervallSeconds){
        this.monitor = monitor;
        this.monitoringIntervallSeconds = monitoringIntervallSeconds;
        return this;
    }
    
    public ADOAllParser setDefaultMonitor(int monitoringIntervallSeconds){
        final long startTime = new Date().getTime();
        this.monitor = new IStatusMonitor() {
            @Override
            public void getStatus(double percentageStatus) { 
                System.err.println("Progress: " + String.format(java.util.Locale.ENGLISH, "%.2f",percentageStatus) + "%   Enlapsed time: " + Utils.convertoMillisecondsToStringDateTime(new Date().getTime() - startTime));
            }
        };
        this.monitoringIntervallSeconds = monitoringIntervallSeconds;
        return this;
    }
    
    public ADOAllFile getADOAllFile() throws Exception{
        if(adoAllFile == null)
            throw new Exception("allModel not parsed");
        return adoAllFile;
    }
    
    public String getADOAllJavaCode(String javaClassName) throws Exception{
        if(adoAllJavaCode == null)
            throw new Exception("allModel not parsed");
        
        String ret = "import org.adoxx.all.abstracted.*;\nimport org.adoxx.all.api.library.newlib.Files;\nimport org.adoxx.all.api.objects.definitions.FacetDefinition;\nimport org.adoxx.all.api.primitive.*;\n\npublic class "+javaClassName+" {\n\tpublic static void main(String[] args) {\n\t\ttry {\n";
        ret += adoAllJavaCode;
        ret += "\n\n\t\t} catch (Exception e) {e.printStackTrace();}\n\t}\n}";
        
        return ret;
    }
    
    public ADOAllParser parse() throws Exception{
        if(monitor!= null && monitoringIntervallSeconds>0)
            new Thread() {
                public void run() {
                    try {
                        while(true){
                            int lastIndex = index;
                            monitor.getStatus((double)(100.0/allModel.length())*index);
                            if(index >= allModel.length()-1){
                                monitor.getStatus(100);
                                break;
                            }
                            Thread.sleep(1000*monitoringIntervallSeconds);
                            if(lastIndex == index){ //I'm in stuck
                                monitor.getStatus((double)(100.0/allModel.length())*index);
                                break;
                            }
                        }
                    } catch (InterruptedException e) {}
                };
            }.start();
        
        try{
            
            boolean isNewLib = isNewLib(allModel);
            
            String version = Version.defaultVersion;
            Files files = new Files();
            
            gotoNextInterestingIndex();
            if(ADOAllParser.startWithFromIndex(allModel, "VERSION ", index))
                version = moveGetNextId();
            gotoNextInterestingIndex();
            if(isNewLib){
                if(!ADOAllParser.startWithFromIndex(allModel, "APPLICATION LIBRARY ", index))
                    throw new Exception("APPLICATION LIBRARY is expected at index " + index);
                
                String appLibId = moveGetNextId();
                String idDynLib = ADOAllParser.getNewLibId(allModel, true);
                String idStaLib = ADOAllParser.getNewLibId(allModel, false);
                adoAllFile = new ADOAllFile(version, new ADOApplicationLibraryNew(appLibId, new ADOLibrary(true, idDynLib), new ADOLibrary(false, idStaLib), files));
                adoAllJavaCode = "\n\nADOAllFile adoAllFile = new ADOAllFile(\""+version+"\", new ADOApplicationLibraryNew(\""+appLibId+"\", new ADOLibrary(true, \""+idDynLib+"\"), new ADOLibrary(false, \""+idStaLib+"\"), new Files()));";
                
                processAllRecordClass();
                processAllAttrProf();
                
                gotoNextInterestingIndex();
                if(!ADOAllParser.startWithFromIndex(allModel, "BUSINESS PROCESS LIBRARY ", index))
                    throw new Exception("BUSINESS PROCESS LIBRARY is expected at index " + index);
                String bpLibId = moveGetNextId();
                if(!bpLibId.equals(idDynLib))
                    throw new Exception("BUSINESS PROCESS LIBRARY id mismatch:\nreaded: " + bpLibId + "\nexpected: " + idDynLib);
                
                adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryNew().getDynamicLibrary().addLibraryAttribute(new ADOLibrary.IdAttrVal[]{";
                adoAllFile.getApplicationLibraryNew().getDynamicLibrary().addLibraryAttribute(processAllInstanceAttributeSetting());
                adoAllJavaCode += "});";
                
                adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryNew().getDynamicLibrary().addClass(new ADOClass[]{";
                adoAllFile.getApplicationLibraryNew().getDynamicLibrary().addClass(processAllClass());
                adoAllJavaCode += "});";
                
                adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryNew().getDynamicLibrary().addRelation(new ADORelation[]{";
                adoAllFile.getApplicationLibraryNew().getDynamicLibrary().addRelation(processAllRelationClass());
                adoAllJavaCode += "});";
                
                gotoNextInterestingIndex();
                if(!ADOAllParser.startWithFromIndex(allModel, "WORKING ENVIRONMENT LIBRARY ", index))
                    throw new Exception("WORKING ENVIRONMENT LIBRARY is expected at index " + index);
                String weLibId = moveGetNextId();
                if(!weLibId.equals(idStaLib))
                    throw new Exception("WORKING ENVIRONMENT LIBRARY id mismatch:\nreaded: " + weLibId + "\nexpected: " + idStaLib);
                
                adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryNew().getStaticLibrary().addLibraryAttribute(new ADOLibrary.IdAttrVal[]{";
                adoAllFile.getApplicationLibraryNew().getStaticLibrary().addLibraryAttribute(processAllInstanceAttributeSetting());
                adoAllJavaCode += "});";
                
                adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryNew().getStaticLibrary().addClass(new ADOClass[]{";
                adoAllFile.getApplicationLibraryNew().getStaticLibrary().addClass(processAllClass());
                adoAllJavaCode += "});";
                
                adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryNew().getStaticLibrary().addRelation(new ADORelation[]{";
                adoAllFile.getApplicationLibraryNew().getStaticLibrary().addRelation(processAllRelationClass());
                adoAllJavaCode += "});";
                
                processAllFiles();
                
            } else {
    
                adoAllFile = new ADOAllFile(version, new ADOApplicationLibraryExtend());
                adoAllJavaCode = "\n\nADOAllFile adoAllFile = new ADOAllFile(\""+version+"\", new ADOApplicationLibraryExtend());";
                        
                while(ADOAllParser.startWithFromIndex(allModel, "BUSINESS PROCESS LIBRARY ", index) || ADOAllParser.startWithFromIndex(allModel, "WORKING ENVIRONMENT LIBRARY ", index)){
                    boolean isBPLib = ADOAllParser.startWithFromIndex(allModel, "BUSINESS PROCESS LIBRARY ", index);
                    String id = moveGetNextId();
                    gotoNextInterestingIndex();
                    if(allModel.charAt(index) != ':')
                        throw new Exception(": is expected at index " + index);
                    String superId = moveGetNextId();
                    
                    
                    adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryExtend().addLibrary(\nnew ADOLibrary(isBPLib, id, superId)\n.addLibraryAttribute(new ADOLibrary.IdAttrVal[]{";    
                    ArrayList<IdAttrVal> attrSettingList = processAllInstanceAttributeSetting();
                    adoAllJavaCode += "})\n.addClass(new ADOClass[]{";
                    ArrayList<ADOClass> adoClassList = processAllClass();
                    adoAllJavaCode += "})\n.addRelation(new ADORelation[]{";
                    ArrayList<ADORelation> adoRelationList = processAllRelationClass();
                    adoAllJavaCode += "})\n);";
                    
                    adoAllFile.getApplicationLibraryExtend().addLibrary(
                            new ADOLibrary(isBPLib, id, superId)
                                    .addLibraryAttribute(attrSettingList)
                                    .addClass(adoClassList)
                                    .addRelation(adoRelationList)
                    );
    
                    gotoNextInterestingIndex();
                }
                
                while(ADOAllParser.startWithFromIndex(allModel, "APPLICATION LIBRARY ", index)){
                    String id = moveGetNextId();
                    gotoNextInterestingIndex();
                    if(allModel.charAt(index) != ':')
                        throw new Exception(": is expected at index " + index);
                    String superId = moveGetNextId();
                    gotoNextInterestingIndex();
                    boolean isBPLib = ADOAllParser.startWithFromIndex(allModel, "BUSINESS PROCESS LIBRARY ", index);
                    String libId = moveGetNextId();
                    String otherLibId = null;
                    gotoNextInterestingIndex();
                    if(ADOAllParser.startWithFromIndex(allModel, "BUSINESS PROCESS LIBRARY ", index) || ADOAllParser.startWithFromIndex(allModel, "WORKING ENVIRONMENT LIBRARY ", index))
                        otherLibId = moveGetNextId();
                    
                    if(otherLibId == null){
                        adoAllFile.getApplicationLibraryExtend().addApplicationLibrary(id, superId, libId, isBPLib);
                        adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryExtend().addApplicationLibrary(\""+id+"\", \""+superId+"\", \""+libId+"\", "+isBPLib+");";
                    } else {
                        adoAllFile.getApplicationLibraryExtend().addApplicationLibrary(id, superId, libId, isBPLib, otherLibId);
                        adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryExtend().addApplicationLibrary(\""+id+"\", \""+superId+"\", \""+libId+"\", "+isBPLib+", \""+otherLibId+"\");";
                    }
                    gotoNextInterestingIndex();
                }
            }
        }catch(Exception ex){
            Exception newEx = new Exception("ERROR INDEX IN FILE: " + index + "\n" + ex.getMessage());
            newEx.setStackTrace(ex.getStackTrace());
            throw newEx;
        }
        
        return this;
    }
    
    private void processAllFiles() throws Exception{
        gotoNextInterestingIndex();
        while(ADOAllParser.startWithFromIndex(allModel, "FILE ", index)){
            String id = moveGetNextId();
            gotoNextInterestingIndex();
            if(!ADOAllParser.startWithFromIndex(allModel, "CONTENT ", index))
                throw new Exception("CONTENT is expected at index " + index);
            index += "CONTENT".length();
            gotoNextInterestingIndex();
            //Val value = getCurrentValue();
            String value = readFileValue();
            
            adoAllFile.getApplicationLibraryNew().addFile(id, value);
            adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryNew().addFile(new Identifier(\""+id+"\"), new Val("+new Val(value).getRaw()+"));";
            
            gotoNextInterestingIndex();
        }
    }
    
    private ArrayList<ADORelation> processAllRelationClass() throws Exception{
        ArrayList<ADORelation> ret = new ArrayList<ADORelation>();
        gotoNextInterestingIndex();
        while(ADOAllParser.startWithFromIndex(allModel, "RELATIONCLASS ", index)){
            boolean isRedef = true;
            String id = moveGetNextId();
            String fromId = null;
            String toId = null;
            
            gotoNextInterestingIndex();
            if(ADOAllParser.startWithFromIndex(allModel, "FROM ", index))
                isRedef = false;
            
            if(!isRedef){
                fromId = moveGetNextId();
                toId = moveGetNextId();
            }
            
            adoAllJavaCode += (fromId == null) ? "\n\tnew ADORelation(\""+id+"\")" : "\n\tnew ADORelation(\""+id+"\", \""+fromId+"\", \""+toId+"\")";
            ADORelation adoRelation = (fromId == null) ? new ADORelation(id) : new ADORelation(id, fromId, toId);
            
            adoAllJavaCode += "\n\t\t.addAttribute(new ADOAttribute[]{";
            ArrayList<ADOAttribute> attributeList = processAllAttribute();
            adoAllJavaCode += "}),";
            adoRelation.addAttribute(attributeList);
            ret.add(adoRelation);
            
            gotoNextInterestingIndex();
        }
        return ret;
    }
    
    private ArrayList<ADOClass> processAllClass() throws Exception{
        ArrayList<ADOClass> ret = new ArrayList<ADOClass>();
        gotoNextInterestingIndex();
        while(ADOAllParser.startWithFromIndex(allModel, "CLASS ", index)){
            boolean isRedef = true;
            String id = moveGetNextId();
            String superId = null;
            
            gotoNextInterestingIndex();
            if(allModel.charAt(index) == ':')
                isRedef = false;
            
            if(!isRedef)
                superId = moveGetNextId();
            
            adoAllJavaCode += (superId == null) ? "\n\tnew ADOClass(\""+id+"\")" : "\n\tnew ADOClass(\""+id+"\", \""+superId+"\")";
            ADOClass adoClass = (superId == null) ? new ADOClass(id) : new ADOClass(id, superId);
            
            adoAllJavaCode += "\n\t\t.addAttribute(new ADOAttribute[]{";
            ArrayList<ADOAttribute> attributeList = processAllAttribute();
            adoAllJavaCode += "}),";
            adoClass.addAttribute(attributeList);
            ret.add(adoClass);
            
            gotoNextInterestingIndex();
        }
        return ret;
    }

    private ArrayList<IdAttrVal> processAllInstanceAttributeSetting() throws Exception{
        ArrayList<IdAttrVal> ret = new ArrayList<IdAttrVal>();
        gotoNextInterestingIndex();
        while(ADOAllParser.startWithFromIndex(allModel, "ATTRIBUTE ", index)){
            String id = moveGetNextId();
            gotoNextInterestingIndex();
            if(!ADOAllParser.startWithFromIndex(allModel, "VALUE ", index))
                throw new Exception("VALUE expected at index " + index);
            index += "VALUE".length();
            gotoNextInterestingIndex();
            
            adoAllJavaCode += "\n\tnew ADOLibrary.IdAttrVal(\""+id+"\", ";
            AttrVal value = getCurrentAttrVal();    
            adoAllJavaCode += "),";
            ret.add(new IdAttrVal(id, value));
            gotoNextInterestingIndex();
        }
        return ret;
    }
    
    private void processAllRecordClass() throws Exception{
        gotoNextInterestingIndex();
        while(ADOAllParser.startWithFromIndex(allModel, "RECORDCLASS ", index)){
            String id = moveGetNextId();      
            String superId = moveGetNextId();
            adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryNew().addRecordClass(\""+id+"\", \""+superId+"\", new ADOAttribute[]{";
            ArrayList<ADOAttribute> attributeList = processAllAttribute();
            adoAllJavaCode += "});";
            adoAllFile.getApplicationLibraryNew().addRecordClass(id, superId, attributeList);
            gotoNextInterestingIndex();
        }
    }
    
    private void processAllAttrProf() throws Exception{
        gotoNextInterestingIndex();
        while(ADOAllParser.startWithFromIndex(allModel, "ATTRIBUTEPROFILECLASS ", index)){
            String id = moveGetNextId();
            String superId = moveGetNextId();
            adoAllJavaCode += "\n\nadoAllFile.getApplicationLibraryNew().addAttrProf(\""+id+"\", \""+superId+"\", new ADOAttribute[]{";
            ArrayList<ADOAttribute> attributeList = processAllAttribute();
            adoAllJavaCode += "});";
            adoAllFile.getApplicationLibraryNew().addAttrProf(id, superId, attributeList);
            gotoNextInterestingIndex();
        }
    }
    
    private ArrayList<ADOAttribute> processAllAttribute() throws Exception{
        
        ArrayList<ADOAttribute> ret = new ArrayList<ADOAttribute>();
        gotoNextInterestingIndex();

        while(ADOAllParser.startWithFromIndex(allModel, "CLASSATTRIBUTE ", index) || ADOAllParser.startWithFromIndex(allModel, "ATTRIBUTE ", index)){
            boolean isClassAttribute = ADOAllParser.startWithFromIndex(allModel, "CLASSATTRIBUTE ", index);
            String id = moveGetNextId();

            TypeIdentifier type = null;
            Val value = null;
            boolean isRecord = false;
            gotoNextInterestingIndex();
            if(ADOAllParser.startWithFromIndex(allModel, "TYPE ", index)){
                index += "TYPE".length();
                gotoNextInterestingIndex();
                String typeS = getCurrentKeyword();
                if(typeS.equals("RECORD"))
                    isRecord = true;
                else
                    type = TypeIdentifier.valueOf(typeS);
                gotoNextInterestingIndex();
            }
            if(ADOAllParser.startWithFromIndex(allModel, "VALUE ", index)){
                index += "VALUE".length();
                gotoNextInterestingIndex();
                value = getCurrentValue();
            }
            
            ADOAttribute attr = null;
            if(value == null && type == null){
                attr = new ADOAttribute(isClassAttribute, id, isRecord);
                adoAllJavaCode += "\n\t\t\tnew ADOAttribute("+isClassAttribute+", \""+id+"\", "+isRecord+")";
            }else if(value != null && type != null){
                attr = new ADOAttribute(isClassAttribute, id, type, value);
                adoAllJavaCode += "\n\t\t\tnew ADOAttribute("+isClassAttribute+", \""+id+"\", TypeIdentifier."+type+", new Val("+value.getRaw()+"))";
            }else if(value != null && type == null){
                attr = new ADOAttribute(isClassAttribute, id, value);
                adoAllJavaCode += "\n\t\t\tnew ADOAttribute("+isClassAttribute+", \""+id+"\", new Val("+value.getRaw()+"))";
            }else{
                attr = new ADOAttribute(isClassAttribute, id, type);
                adoAllJavaCode += "\n\t\t\tnew ADOAttribute("+isClassAttribute+", \""+id+"\", TypeIdentifier."+type+")";
            }
            
            adoAllJavaCode += "\n\t\t\t\t.addFacet(new FacetDefinition[]{";
            ArrayList<FacetDefinition> facetList = processAllFacet();
            adoAllJavaCode += "}),";
            attr.addFacet(facetList);
            ret.add(attr);
            gotoNextInterestingIndex();
        }
        
        return ret;
    }
    
    private ArrayList<FacetDefinition> processAllFacet() throws Exception{
        ArrayList<FacetDefinition> ret = new ArrayList<FacetDefinition>();
        gotoNextInterestingIndex();
        while(ADOAllParser.startWithFromIndex(allModel, "FACET ", index)){
            String id = moveGetNextId();
            TypeIdentifier type = null;
            Val value = null;
            gotoNextInterestingIndex();
            if(ADOAllParser.startWithFromIndex(allModel, "TYPE ", index)){
                index += "TYPE".length();
                gotoNextInterestingIndex();
                String typeS = getCurrentKeyword();
                type = TypeIdentifier.valueOf(typeS);
            }
            if(ADOAllParser.startWithFromIndex(allModel, "VALUE ", index)){
                index += "VALUE".length();
                gotoNextInterestingIndex();
                value = getCurrentValue();
            }
            
            FacetDefinition facet = null;
            if(value == null && type == null)
                throw new Exception("Malformed Facet: type and value not specified; index " + index);
            else if(value != null && type != null){
                facet = new FacetDefinition(new Identifier(id), type, value);
                adoAllJavaCode += "\n\t\t\t\t\tnew FacetDefinition(new Identifier(\""+id+"\"), TypeIdentifier."+type+", new Val("+value.getRaw()+")),";
            }else if(value != null && type == null){
                facet = new FacetDefinition(new Identifier(id), value);
                adoAllJavaCode += "\n\t\t\t\t\tnew FacetDefinition(new Identifier(\""+id+"\"), new Val("+value.getRaw()+")),";
            }else{
                facet = new FacetDefinition(new Identifier(id), type);
                adoAllJavaCode += "\n\t\t\t\t\tnew FacetDefinition(new Identifier(\""+id+"\"), TypeIdentifier."+type+"),";
            }
            ret.add(facet);
            gotoNextInterestingIndex();
        }
        
        return ret;
    }
    
    private static boolean startWithFromIndex(String data, String pattern, int index){
        /*for(int i=0;i<pattern.length();i++){
            if(data.length() <= index+i || data.charAt(index+i) != pattern.charAt(i))
                return false;
        }
        return true;
        */
        return data.startsWith(pattern, index);
    }
   
    private static int[] getNextIdentifierIndexesStartEnd(String data, int index) throws Exception{
        int start = -1;
        int end = -1;
        
        start = data.indexOf('<', index)+1;
        end = data.indexOf('>', start)-1;

        if(start == -1 || end == -1)
            throw new Exception("Impossible to find an identifier from position " + index);
        return new int[]{start, end};
    }
    
    private static boolean haveSuperId(String data, int index){
        int next = getNextInterestingIndex(data, index);
        if(data.charAt(next) == ':')
            return true;
        else
            return false;
    }
    
    private static boolean isNewLib(String data){
        try{
            int startIndex = data.indexOf("APPLICATION LIBRARY ");
            if(startIndex == -1)
                return false;
            int[] startEnd = getNextIdentifierIndexesStartEnd(data, startIndex);
            if(haveSuperId(data, startEnd[1]))
                return false;
            else
                return true;
        }catch(Exception ex){}
        return false;
    }
    
    private static String getNewLibId(String data, boolean dynamic) throws Exception{
        int startIndex = data.indexOf(dynamic?"BUSINESS PROCESS LIBRARY ":"WORKING ENVIRONMENT LIBRARY ");
        int[] startEnd = getNextIdentifierIndexesStartEnd(data, startIndex);
        return data.substring(startEnd[0], startEnd[1] + 1);
    }
    
    private void gotoNextInterestingIndex(){
        index = ADOAllParser.getNextInterestingIndex(allModel, index);
    }

    private static int getNextInterestingIndex(String allModel, int index){
        for(int i=index;i<allModel.length();i++){
            char currentChar = allModel.charAt(i);
            if(currentChar==' ' || currentChar=='\t' || currentChar=='\n' || currentChar==0x0B || currentChar=='\r' || currentChar=='\f')
                continue;
            else if(allModel.startsWith("//", i)){
                int end = allModel.indexOf('\n', i);
                if(end == -1)
                    return allModel.length() - 1;
                return getNextInterestingIndex(allModel, end);
            } else {
                return i;
            }
        }
        return allModel.length() - 1;
    }

    private String moveGetNextId() throws Exception{
        int[] startEnd = ADOAllParser.getNextIdentifierIndexesStartEnd(allModel, index);
        String id = allModel.substring(startEnd[0], startEnd[1] + 1);
        index = startEnd[1] + 2;
        return id;
    }
    
    private String getCurrentKeyword(){
        String ret = "";
        for(int i=index;i<allModel.length();i++){
            if(allModel.charAt(i)==' ' || allModel.charAt(i)=='\t' || allModel.charAt(i)=='\n' || allModel.charAt(i)==0x0B || allModel.charAt(i)=='\r' || allModel.charAt(i)=='\f'){
                index = i;
                break;
            } else
                ret += allModel.charAt(i);
        }
        return ret;
    }
    
    private Val getCurrentValue() throws Exception{
        if(allModel.charAt(index) == '"'){
            String val = readStringValue();
            return new Val(val);
        } else {
            String num = getCurrentKeyword();
            if(num.contains("."))
                return new Val(Double.parseDouble(num));
            else
                return new Val(Integer.parseInt(num));
        }
    }
    
    private AttrVal getCurrentAttrVal() throws Exception{
        if(allModel.charAt(index) == '"'){
            String val = readStringValue();
            adoAllJavaCode += "new AttrVal(\""+val.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r\n", "\\n").replace("\n", "\\n")+"\")";
            return new AttrVal(val);
        } else if(ADOAllParser.startWithFromIndex(allModel, "RECORD ", index)) {
            
            ArrayList<RecordVal> recordValList = new ArrayList<RecordVal>();
            adoAllJavaCode += "new AttrVal(new RecordVal[]{";
            while(ADOAllParser.startWithFromIndex(allModel, "RECORD ", index)){
                RecordVal recordVal = new RecordVal();
                adoAllJavaCode += "\n\t\tnew RecordVal()";
                index += "RECORD".length();
                gotoNextInterestingIndex();
                
                while(ADOAllParser.startWithFromIndex(allModel, "ATTRIBUTE ", index)){
                    String id = moveGetNextId();
                    gotoNextInterestingIndex();
                    
                    if(!ADOAllParser.startWithFromIndex(allModel, "VALUE ", index))
                        throw new Exception("VALUE expected at index " + index);
                    index += "VALUE".length();
                    gotoNextInterestingIndex();
                    Val value = getCurrentValue();
                    
                    recordVal.addAttribute(new Identifier(id), value);
                    adoAllJavaCode += "\n\t\t\t.addAttribute(new Identifier(\""+id+"\"), new Val("+value.getRaw()+"))";
                    gotoNextInterestingIndex();
                }
                
                adoAllJavaCode += ",";
                if(!ADOAllParser.startWithFromIndex(allModel, "END", index))
                    throw new Exception("END expected at index " + index);
                index += "END".length();
                    
                recordValList.add(recordVal);
                
                gotoNextInterestingIndex();
            }
            
            adoAllJavaCode += "})";
            
            RecordVal[] recordValA = new RecordVal[recordValList.size()];
            return new AttrVal(recordValA);
        } else {
            String num = getCurrentKeyword();
            adoAllJavaCode += "new AttrVal("+num+")";
            if(num.contains("."))
                return new AttrVal(Double.parseDouble(num));
            else
                return new AttrVal(Integer.parseInt(num));
        }
    }

    private static boolean isCharEscaped(String data, int index){
        int i = index;
        int escapeCounter = 0;
        while(true){
            i--;
            if(i<0) 
                break;
            if(data.charAt(i) == '\\')
                escapeCounter++;
            else
                break;
        }
        boolean isEscaped = escapeCounter % 2 != 0; //if odd means is escaped
        return isEscaped;
    }
    
    private String readStringValue() {
        String valS = "";
        //index now is at the char "
        while(true){
            int start = index+1;
            do{
                index = allModel.indexOf('"', index+1);
            }while(isCharEscaped(allModel, index));
            
            valS += allModel.substring(start, index);
            index++;
            int next = getNextInterestingIndex(allModel, index);
            if(allModel.charAt(next) == '"')
                index = next;
            else
                break;
        }
        
        return valS.replace("\\\"", "\"").replace("\\\\", "\\");
    }
    
    private String readFileValue() throws Exception {
        String valS = "";
        //index now is at the char "
        while(true){
            int start = index+1;
            index = allModel.indexOf('"', index+1);
            valS += allModel.substring(start, index);
            index++;
            int next = getNextInterestingIndex(allModel, index);
            if(allModel.charAt(next) == '"')
                index = next;
            else
                break;
        }
        
        return valS;
    }
}