package org.adoxx.all.api.library.presetlib.libraries.definitions;

import org.adoxx.all.api.primitive.Identifier;

public class WeLibraryDefinition {

    private Identifier identifier = null;
    private Identifier superLibIdentifier = null;
    
    public WeLibraryDefinition(Identifier identifier, Identifier superLibIdentifier) throws Exception {
        if(identifier == null || superLibIdentifier == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.superLibIdentifier = superLibIdentifier;
    }
    
    public Identifier getId(){
        return this.identifier;
    }
    
    public Identifier getSuperLibId(){
        return this.superLibIdentifier;
    }

    @Override
    public String toString(){
        return "WORKING ENVIRONMENT LIBRARY " + identifier.toString() + " : " + superLibIdentifier.toString() + "\n\n";
    }
}
