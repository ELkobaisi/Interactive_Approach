package org.adoxx.all.api.objects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.UUID;

import org.adoxx.all.api.library.Library;
import org.adoxx.all.api.objects.definitions.ClassDefinition;
import org.adoxx.all.api.objects.redef.RedefAttribute;
import org.adoxx.all.api.objects.redef.definitions.RedefClassDefinition;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.Val;

public class Class {
    private String uuid = UUID.randomUUID().toString();
    
    public ClassDefinition classDefinition = null;
    public RedefClassDefinition redefClassDefinition = null;
    
    public ArrayList<Attribute> attributeList = new ArrayList<Attribute>();
    public ArrayList<RedefAttribute> redefAttributeList = new ArrayList<RedefAttribute>();
    
    private Library library = null;
    private boolean isInternal = false;
    
    public Class(ClassDefinition classDefinition) throws Exception {
        if(classDefinition == null)
            throw new Exception("Not Allowed");
        
        this.classDefinition = classDefinition;
    }
    
    public Class(RedefClassDefinition redefClassDefinition) throws Exception {
        if(redefClassDefinition == null)
            throw new Exception("Not Allowed");
        
        this.redefClassDefinition = redefClassDefinition;
    }
    
    public void addAttribute(Attribute attribute) throws Exception{
        if(classDefinition == null || attribute == null)
            throw new Exception("Not Allowed");
        
        if(attributeList.contains(attribute))
            throw new Exception("An Attribute with id " + attribute.getId().getRaw() + " has been already defined for the Class " + this.getId().toString());
        
        attributeList.add(attribute);
        
        if(this.library != null)
            checkAttribute(attribute);
    }
    
    public void addAttribute(RedefAttribute attribute) throws Exception{
        if(redefClassDefinition == null || attribute == null)
            throw new Exception("Not Allowed");
        
        if(redefAttributeList.contains(attribute))
            throw new Exception("An Attribute with id " + attribute.getId().toString() + " has been already defined for the Class " + this.getId().toString());
        
        redefAttributeList.add(attribute);
        
        if(this.library != null)
            checkAttribute(attribute);
    }
    
    public void chackAllAddedAttributes() throws Exception{
        for(AttributeI attribute: attributeList)
            checkAttribute(attribute);
        for(AttributeI attribute: redefAttributeList)
            checkAttribute(attribute);
    }
    
    private void checkAttribute(AttributeI attribute) throws Exception{
        if(this.library == null)
            throw new Exception("set the library before checking attributes");
        

        if(attribute.getType() != null || attribute.isRecord()){
            Class su = this;
            do{
                Class[] allSu = this.library.getClasses(su.getId());
                for(Class clazz : allSu)
                    if((su == this && clazz.hasMultipleAttributeDefinition(attribute.getId())) || (su != this && clazz.hasAttributeDefinition(attribute.getId())))
                        throw new Exception("Impossible to add the attribute " + attribute.getId().getRaw() + " to the class " + this.getId().getRaw() + " because it is already defined in the class " + clazz.getId().getRaw());
                su = su.getSuperClassDefinition();
            }while(su != null);
        } else {
            Class su = this;
            boolean definitionOk = false;
            while(su != null && !definitionOk){
                Class[] allSu = this.library.getClasses(su.getId());
                for(Class clazz : allSu)
                    if(clazz.hasAttributeDefinition(attribute.getId())){
                        definitionOk = true;
                        break;
                    }
                su = su.getSuperClassDefinition();
            }
            if(!definitionOk)
                throw new Exception("Impossible to add the attribute " + attribute.getId().getRaw() + " to the class " + this.getId().getRaw() + " because it has never been defined");
        }
    }
    
    public boolean checkAttributeDefinitionPresence(String attributeId) throws Exception{
        if(this.library == null)
            throw new Exception("set the library before checking attributes");
        
        Class su = this;
        boolean definitionOk = false;
        while(su != null && !definitionOk){
            Class[] allSu = this.library.getClasses(su.getId());
            for(Class clazz : allSu)
                if(clazz.hasAttributeDefinition(attributeId)){
                    definitionOk = true;
                    break;
                }
            su = su.getSuperClassDefinition();
        }
        
        return definitionOk;
    }
    
    public AttributeI getGeneralAttributeDefinition(String attributeId) throws Exception{
        if(this.library == null)
            throw new Exception("set the library before checking attributes");
        
        Class su = this;

        while(su != null){
            Class[] allSu = this.library.getClasses(su.getId());
            for(Class clazz : allSu){
                AttributeI attributeDef = clazz.getAttributeDefinition(attributeId);
                if(attributeDef != null)
                    return attributeDef;
            }
            su = su.getSuperClassDefinition();
        }
        
        throw new Exception("Definition for the attrbute " + attributeId + " not found");
    }
    
    public void removeAttribute(String attributeId) throws Exception{
        removeAttribute(new Identifier(attributeId));
    }
    public void removeAttribute(Identifier attributeId) throws Exception{
        boolean definitionRemoved = false;
        
        Iterator<Attribute> attributeIterator = attributeList.iterator();
        while(attributeIterator.hasNext()){
            Attribute attribute = attributeIterator.next();
            if(attribute.getId().equals(attributeId)){
                attributeIterator.remove();
                if(attribute.getType()!=null || attribute.isRecord())
                    definitionRemoved = true;
            }
        }
        
        Iterator<RedefAttribute> redefAttributeIterator = redefAttributeList.iterator();
        while(redefAttributeIterator.hasNext()){
            RedefAttribute attribute = redefAttributeIterator.next();
            if(attribute.getId().equals(attributeId)){
                redefAttributeIterator.remove();
                if(attribute.getType()!=null || attribute.isRecord())
                    definitionRemoved = true;
            }
        }
        
        if(definitionRemoved){
            boolean foundCurrentClass = false;
            for(Class clazz : this.library.getClasses(this.getId().getRaw())){
                if(clazz.uuid.equals(this.uuid)){
                    foundCurrentClass = true;
                    continue;
                }
                if(foundCurrentClass)
                    clazz.removeAttribute(attributeId);
            }
            
            
            ArrayList<Class> childDefList = new ArrayList<Class>();
            for(Class clazz : this.library.getClasses())
                if(clazz.hasSuperClassId() && clazz.getSuperClassId().getRaw().equals(this.getId().getRaw()))
                    childDefList.add(clazz);
                
            while(childDefList.size() != 0){
                ArrayList<Class> newChildDefList = new ArrayList<Class>();
                for(Class childDef : childDefList){
                    for(Class clazz : this.library.getClasses(childDef.getId().getRaw()))
                        clazz.removeAttribute(attributeId);
                    
                    for(Class clazz : this.library.getClasses())
                        if(clazz.hasSuperClassId() && clazz.getSuperClassId().getRaw().equals(childDef.getId().getRaw()))
                            newChildDefList.add(clazz);
                }
                
                childDefList = newChildDefList;
            }
        }
    }
    
    public Identifier getId(){
        if(this.classDefinition != null)
            return this.classDefinition.getId();
        else
            return this.redefClassDefinition.getId();
    }
    
    public Identifier getSuperClassId() throws Exception{
        if(this.classDefinition != null)
            return this.classDefinition.getSuperClassId();
        else
            throw new Exception("The SuperClass Id is not present in a redefined Class");
    }
    
    public boolean hasSuperClassId(){
        return this.classDefinition != null;
    }
    
    public Class getSuperClassDefinition() {
        
        Class ret = null;
        try{
            Class currClassDef = this.library.getClassDefinition(this.getId());
            ret = this.library.getClassDefinition(currClassDef.getSuperClassId());
        }catch(Exception ex){}
        return ret;
    }
    
    public Val findAttributeValue(String attributeId) throws Exception{
        return findAttributeValue(new Identifier(attributeId));
    }
    
    public Val findAttributeValue(Identifier attributeId) throws Exception{
        for(Attribute attribute:attributeList)
            if(attribute.getId().equals(attributeId))
                return attribute.getValue();
        for(RedefAttribute attribute:redefAttributeList)
            if(attribute.getId().equals(attributeId))
                return attribute.getValue();
        
        throw new Exception("Impossible to find an attribute with id " + attributeId);
    }
    
    public boolean hasAttribute(String attributeId){
        return hasAttribute(new Identifier(attributeId));
    }
    
    public boolean hasAttribute(Identifier attributeId){

        for(Attribute attribute:attributeList)
            if(attribute.getId().equals(attributeId))
                return true;
        for(RedefAttribute attribute:redefAttributeList)
            if(attribute.getId().equals(attributeId))
                return true;
        return false;
    }
    
    public boolean hasAttributeDefinition(String attributeId){
        return hasAttributeDefinition(new Identifier(attributeId));
    }
    
    public boolean hasAttributeDefinition(Identifier attributeId){
        for(Attribute attribute:attributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                return true;
        for(RedefAttribute attribute:redefAttributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                return true;
        return false;
    }
    
    public AttributeI getAttributeDefinition(String attributeId){
        return getAttributeDefinition(new Identifier(attributeId));
    }
    
    public AttributeI getAttributeDefinition(Identifier attributeId){
        for(Attribute attribute:attributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                return attribute;
        for(RedefAttribute attribute:redefAttributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                return attribute;
        return null;
    }
    
    public boolean hasMultipleAttributeDefinition(String attributeId){
        return hasMultipleAttributeDefinition(new Identifier(attributeId));
    }
    
    public boolean hasMultipleAttributeDefinition(Identifier attributeId){
        boolean firstFound = false;
        for(Attribute attribute:attributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                if(!firstFound)
                    firstFound = true;
                else
                    return true;
        for(RedefAttribute attribute:redefAttributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                if(!firstFound)
                    firstFound = true;
                else
                    return true;
        return false;
    }
    
    public void setLibrary(Library library){
        this.library = library;
    }
    
    public boolean isLibrarySet(){
        return this.library != null;
    }
    
    public void setAsInternal(boolean isInternal){
        this.isInternal = isInternal;
    }
    
    public boolean isInternal(){
        return this.isInternal;
    }
    
    @Override
    public int hashCode(){
        if(this.hasSuperClassId())
            return 1013 *getId().hashCode() ^ 1009 * 2;
        else
            return getId().hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof Class))
            return o==this;
        
        Class other = (Class)o;
        return other.getId().equals(this.getId()) && this.hasSuperClassId() && other.hasSuperClassId();
    }
    
    @Override
    public String toString(){
        String ret = "";
        if(classDefinition!=null){
            ret += classDefinition.toString();
            for(Attribute attribute:attributeList)
                ret += attribute.toString();
        } else {
            ret += redefClassDefinition.toString();
            for(RedefAttribute attribute:redefAttributeList)
                ret += attribute.toString();
        }
        return ret;
    }
}
