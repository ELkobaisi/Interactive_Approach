package org.adoxx.all.api.library.newlib;

import java.util.ArrayList;

import org.adoxx.all.api.library.InstanceAttributeSetting;
import org.adoxx.all.api.library.Library;
import org.adoxx.all.api.primitive.AttrVal;
import org.adoxx.all.api.primitive.Identifier;

public class BpLib {

    private Identifier identifier = null;
    public Library library = null;
    private ArrayList<InstanceAttributeSetting> instanceAttributeSettingList = new ArrayList<InstanceAttributeSetting>();
    
    public BpLib(Identifier identifier, Library library) throws Exception {
        if(identifier == null || library == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.library = library;
    }

    public void addInstanceAttributeSetting(InstanceAttributeSetting instanceAttributeSetting) throws Exception{
        if(instanceAttributeSetting == null)
            throw new Exception("Not Allowed");
        
        if(instanceAttributeSettingList.contains(instanceAttributeSetting))
            throw new Exception("An Attribute setting with id " + instanceAttributeSetting.getId().toString() + " has been already defined for the library " + this.getId().toString());
        
        instanceAttributeSettingList.add(instanceAttributeSetting);
    }

    public Identifier getId(){
        return identifier;
    }
    
    public boolean hasAttribute(String attributeId) {
        for(InstanceAttributeSetting instanceAttributeSetting:instanceAttributeSettingList)
            if(instanceAttributeSetting.getId().equals(new Identifier(attributeId)))
                return true;
        return false;
    }
    
    public AttrVal findAttributeValue(String attributeId) throws Exception{
        for(InstanceAttributeSetting instanceAttributeSetting:instanceAttributeSettingList)
            if(instanceAttributeSetting.getId().equals(new Identifier(attributeId)))
                return instanceAttributeSetting.getValue();

        throw new Exception("Impossible to find an attribute with id " + attributeId);
    }
    
    @Override
    public String toString(){
        String ret = "BUSINESS PROCESS LIBRARY " +identifier.toString() + "\n\n";
        for(InstanceAttributeSetting instanceAttributeSetting:instanceAttributeSettingList)
            ret += instanceAttributeSetting.toString();
        ret += library.toString();
        return ret;
    }
}
