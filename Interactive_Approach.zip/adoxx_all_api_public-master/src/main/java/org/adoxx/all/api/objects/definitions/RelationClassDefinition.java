package org.adoxx.all.api.objects.definitions;

import org.adoxx.all.api.primitive.Identifier;

public class RelationClassDefinition {

    private Identifier identifier = null;
    private Identifier fromIdentifier = null;
    private Identifier toIdentifier = null;
    
    public RelationClassDefinition(Identifier identifier, Identifier fromIdentifier, Identifier toIdentifier) throws Exception {
        if(identifier == null || fromIdentifier == null || toIdentifier == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.fromIdentifier = fromIdentifier;
        this.toIdentifier = toIdentifier;
    }

    public Identifier getId(){
        return this.identifier;
    }
    
    public Identifier getIdFrom(){
        return this.fromIdentifier;
    }
    
    public Identifier getIdTo(){
        return this.toIdentifier;
    }
    
    @Override
    public String toString(){
        return "RELATIONCLASS " + identifier.toString() + "\nFROM " + fromIdentifier.toString() + "\nTO " + toIdentifier.toString() + "\n\n";
    }
}
