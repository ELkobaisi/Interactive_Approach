package org.adoxx.all.api.objects.definitions;

import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;

public class FacetDefinition {

    private Identifier identifier = null;
    private Val value = null;
    private TypeIdentifier type = null;
    
    public static FacetDefinition factory(Identifier identifier, TypeIdentifier type, Val value) throws Exception {
        if(type!=null && value!=null)
            return new FacetDefinition(identifier, type, value);
        else if(type!=null && value==null)
            return new FacetDefinition(identifier, type);
        else if(type==null && value!=null)
            return new FacetDefinition(identifier, value);
        else
            throw new Exception("the facet with Id " + identifier + " can not have both type and value null");
    }
    
    public FacetDefinition(Identifier identifier, TypeIdentifier type) throws Exception {
        if(identifier == null || type == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.type = type;
    }
    
    public FacetDefinition(Identifier identifier, TypeIdentifier type, Val value) throws Exception {
        if(identifier == null || type == null || value == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.type = type;
        this.value = value;
    }
    
    public FacetDefinition(Identifier identifier, Val value) throws Exception {
        if(identifier == null || value == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.value = value;
    }
    
    public Identifier getId(){
        return this.identifier;
    }
    
    public TypeIdentifier getType(){
        return this.type;
    }
    
    public Val getValue(){
        return this.value;
    }
    
    @Override
    public int hashCode(){
        return identifier.hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof FacetDefinition))
            return o==this;
        return ((FacetDefinition)o).getId().equals(this.getId());
    }
    
    @Override
    public String toString(){
        String ret = "FACET " + identifier.toString() + "\n";
        if(type!=null)
            ret += " TYPE " + type.toString() + "\n";
        if(value!=null)
            ret += " VALUE " + value.toString() + "\n";
        ret += "\n";
        
        return ret;
    }
}
