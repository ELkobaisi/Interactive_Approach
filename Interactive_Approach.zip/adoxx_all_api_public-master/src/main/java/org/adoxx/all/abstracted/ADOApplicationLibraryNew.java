package org.adoxx.all.abstracted;

import java.util.ArrayList;
import java.util.Set;

import org.adoxx.all.api.library.newlib.AttrProf;
import org.adoxx.all.api.library.newlib.Files;
import org.adoxx.all.api.library.newlib.NewLib;
import org.adoxx.all.api.library.newlib.RecordClass;
import org.adoxx.all.api.library.newlib.definitions.ApplicationLibDefinition;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.Val;
import org.adoxx.utils.Utils;

/**
 * <h1>ADOApplicationLibraryNew</h1>
 * Represent the ALL file structure relative to the new library definition (newlib) and contain methods related to it. 
 * 
 * @author Damiano Falcioni
 */
public class ADOApplicationLibraryNew {

    public ADOAllFile parentAllFile = null;
    public NewLib newLib = null;
    private ADOLibrary dynamicLibrary = null;
    private ADOLibrary staticLibrary = null;
    
    /**
     * Generate an instance of this class
     * @param id The id of the new Application Library
     * @param dynamicLibrary A dynamic ADOLibrary instance
     * @param staticLibrary A static ADOLibrary instance
     * @param files A Files instance
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew(String id, ADOLibrary dynamicLibrary, ADOLibrary staticLibrary, Files files) throws Exception {
        if(dynamicLibrary.bpLib == null)
            throw new Exception("The dynamic library have to be redefined (idSuperLibrary not present)");
        if(staticLibrary.weLib == null)
            throw new Exception("The static library have to be redefined (idSuperLibrary not present)");
        
        this.dynamicLibrary = dynamicLibrary;
        this.staticLibrary = staticLibrary;
        
        newLib = new NewLib(new ApplicationLibDefinition(new Identifier(id)), dynamicLibrary.bpLib, staticLibrary.weLib, files);
    }
    
    /**
     * Add a record class to this library
     * @param id The id of the new RecordClass
     * @param attributeList A list of ADOAttribute for the new RecordClass
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew addRecordClass(String id, ADOAttribute[] attributeList) throws Exception{
        return addRecordClass(id, null, attributeList);
    }
    
    /**
     * Add a record class to this library
     * @param id The id of the new RecordClass
     * @param superId The super Id of the new RecordClass
     * @param attributeList A list of ADOAttribute for the new RecordClass
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew addRecordClass(String id, String superId, ADOAttribute[] attributeList) throws Exception{
        RecordClass recordClass = RecordClass.factory(new Identifier(id), superId!=null?new Identifier(superId):null);
        
        for(ADOAttribute attribute:attributeList)
            recordClass.addAttribute(attribute.getAttribute());
        return addRecordClass(recordClass);
    }
    
    /**
     * Add a record class to this library
     * @param id The id of the new RecordClass
     * @param attributeList A list of ADOAttribute for the new RecordClass
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew addRecordClass(String id, ArrayList<ADOAttribute> attributeList) throws Exception{
        return addRecordClass(id, null, attributeList);
    }
    
    /**
     * Add a record class to this library
     * @param id The id of the new RecordClass
     * @param superId The super Id of the new RecordClass
     * @param attributeList A list of ADOAttribute for the new RecordClass
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew addRecordClass(String id, String superId, ArrayList<ADOAttribute> attributeList) throws Exception{
        RecordClass recordClass = RecordClass.factory(new Identifier(id), new Identifier(superId));
        for(ADOAttribute attribute:attributeList)
            recordClass.addAttribute(attribute.getAttribute());
        return addRecordClass(recordClass);
    }
    
    /**
     * Add a record class to this library
     * @param recordClass The new RecordClass instance
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    private ADOApplicationLibraryNew addRecordClass(RecordClass recordClass) throws Exception{
        newLib.addRecordClass(recordClass);
        return this;
    }
    
    /**
     * Add a attribute profile class to this library
     * @param id The id of the new AttrProf
     * @param attributeList A list of ADOAttribute for the new AttrProf
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew addAttrProf(String id, ADOAttribute[] attributeList) throws Exception{
        return addAttrProf(id, null, attributeList);
    }

    /**
     * Add a attribute profile class to this library
     * @param id The id of the new AttrProf
     * @param superId The super Id of the new AttrProf
     * @param attributeList A list of ADOAttribute for the new AttrProf
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew addAttrProf(String id, String superId, ADOAttribute[] attributeList) throws Exception{
        AttrProf attrProf = AttrProf.factory(new Identifier(id), new Identifier(superId));
        for(ADOAttribute attribute:attributeList)
            attrProf.addAttribute(attribute.getAttribute());
        return addAttrProf(attrProf);
    }
    
    /**
     * Add a attribute profile class to this library
     * @param id The id of the new AttrProf
     * @param attributeList A list of ADOAttribute for the new AttrProf
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew addAttrProf(String id, ArrayList<ADOAttribute> attributeList) throws Exception{
        return addAttrProf(id, null, attributeList);
    }
    
    /**
     * Add a attribute profile class to this library
     * @param id The id of the new AttrProf
     * @param superId The super Id of the new AttrProf
     * @param attributeList A list of ADOAttribute for the new AttrProf
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew addAttrProf(String id, String superId, ArrayList<ADOAttribute> attributeList) throws Exception{
        AttrProf attrProf = AttrProf.factory(new Identifier(id), new Identifier(superId));
        for(ADOAttribute attribute:attributeList)
            attrProf.addAttribute(attribute.getAttribute());
        return addAttrProf(attrProf);
    }
    
    /**
     * Add a attribute profile class to this library
     * @param attrProf The new AttrProf instance
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew addAttrProf(AttrProf attrProf) throws Exception{
        newLib.addAttrProfList(attrProf);
        return this;
    }
    
    /**
     * Get the dynamic ADOLibrary defined during the initialisation of this object
     * @return ADOLibrary The dynamic ADOLibrary
     */
    public ADOLibrary getDynamicLibrary(){
        return dynamicLibrary;
    }
    
    /**
     * Get the static ADOLibrary defined during the initialisation of this object
     * @return ADOLibrary The static ADOLibrary
     */
    public ADOLibrary getStaticLibrary(){
        return staticLibrary;
    }

    /**
     * Add a file to this application library
     * @param id The Id of the new file to add
     * @param contentBase64 The content of the file encoded in Base64 (without padding)
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew addFile(String id, String contentBase64) throws Exception{
        newLib.addFile(new Identifier(id), new Val(contentBase64));
        return this;
    }

    /**
     * Add a file to this application library
     * @param id The Id of the new file to add
     * @param filePath Path of the file to add
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew addFilePath(String id, String filePath) throws Exception{
        newLib.addFile(new Identifier(id), new Val(Utils.base64EncodeNoPadding(Utils.readFile(filePath))));
        return this;
    }
    
    /**
     * Get the set of Id of all the added files
     * @return Set&lt;Identifier&gt; The set of Id of all the added files
     */
    public Set<Identifier> getFileList(){
        return newLib.getFileList();
    }
    
    /**
     * Find the value object of the file identified by the provided Id. If the file is not found an exception raise
     * @param fileId The id of the file to search for the value
     * @return Val The object containing the value associated with the requested file
     * @throws Exception in case of error
     */
    public Val findFileValue(String fileId) throws Exception{
        return newLib.findFileValue(fileId);
    }
    
    /**
     * Find the value object of the file identified by the provided Id. If the file is not found an exception raise
     * @param fileId The id of the file to search for the value
     * @return Val The object containing the value associated with the requested file
     * @throws Exception in case of error
     */
    public Val findFileValue(Identifier fileId) throws Exception{
        return newLib.findFileValue(fileId);
    }
    
    /**
     * Check if a file has been added in this application library
     * @param fileId The id of the file to search
     * @return boolean true if the file has been added, false otherwise
     */
    public boolean hasFile(String fileId) {
        return newLib.hasFile(fileId);
    }
    
    /**
     * Get a list of all the RecordClass added in this application library 
     * @return RecordClass[] The list of all the added RecordClass
     */
    public RecordClass[] getRecordClasses(){
        return newLib.getRecordClasses();
    }
    
    /**
     * Find the RecordClass added in this application library with the provided id. If the RecordClass is not present an exception raise 
     * @param id The id of the RecordClass to search
     * @return RecordClass The RecordClass requested
     * @throws Exception in case of error
     */
    public RecordClass findRecordClass(String id) throws Exception{
        return newLib.findRecordClass(id);
    }
    
    /**
     * Get a list of all the AttrProf added in this application library 
     * @return AttrProf[] The list of all the added AttrProf
     */
    public AttrProf[] getAttributeProfileClasses(){
        return newLib.getAttributeProfileClasses();
    }
    
    /**
     * Find the AttrProf added in this application library with the provided id. If the AttrProf is not present an exception raise 
     * @param id The id of the AttrProf to search
     * @return AttrProf The AttrProf requested
     * @throws Exception in case of error
     */
    public AttrProf findAttributeProfileClass(String id) throws Exception{
        return newLib.findAttributeProfileClass(id);
    }
    
    /**
     * Import all the record classes from another ADOApplicationLibraryNew object
     * @param otherApplicationLibraryNew The application library  object from where import the record classes
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew importRecordClasses(ADOApplicationLibraryNew otherApplicationLibraryNew) throws Exception{
        if(otherApplicationLibraryNew == null)
            throw new Exception("Incompatible libraries: The provided ADOApplicationLibraryNew is null");

        String log = "";
        for(RecordClass recordClass: otherApplicationLibraryNew.getRecordClasses()){
            try{
                this.addRecordClass(recordClass);
            }catch(Exception ex){log += "Skipped RecordClass with ID "+recordClass.getId()+"\n";}
        }
        
        System.err.println(log);
        return this;
    }
    
    /**
     * Import a specific record class from another ADOApplicationLibraryNew object
     * @param otherApplicationLibraryNew The application library object from where import the record class
     * @param recordClassId The id of the record class to import
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew importRecordClass(ADOApplicationLibraryNew otherApplicationLibraryNew, String recordClassId) throws Exception{
        this.addRecordClass(otherApplicationLibraryNew.findRecordClass(recordClassId));
        return this;
    }
    
    /**
     * Import all the attribute profile classes from another ADOApplicationLibraryNew object
     * @param otherApplicationLibraryNew The application library  object from where import the attribute profile classes
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew importAttributeProfileClasses(ADOApplicationLibraryNew otherApplicationLibraryNew) throws Exception{
        if(otherApplicationLibraryNew == null)
            throw new Exception("Incompatible libraries: The provided ADOApplicationLibraryNew is null");

        String log = "";
        for(AttrProf attributeProfileClass: otherApplicationLibraryNew.getAttributeProfileClasses()){
            try{
                this.addAttrProf(attributeProfileClass);
            }catch(Exception ex){log += "Skipped AttrProf with ID "+attributeProfileClass.getId()+"\n";}
        }
        
        System.err.println(log);
        return this;
    }
    
    /**
     * Import a specific attribute profile class from another ADOApplicationLibraryNew object
     * @param otherApplicationLibraryNew The application library object from where import the attribute profile class
     * @param attributeProfileClassId The id of the attribute profile class to import
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew importAttributeProfileClass(ADOApplicationLibraryNew otherApplicationLibraryNew, String attributeProfileClassId) throws Exception{
        this.addAttrProf(otherApplicationLibraryNew.findAttributeProfileClass(attributeProfileClassId));
        return this;
    }
    
    /**
     * Import all the files from another ADOApplicationLibraryNew object
     * @param otherApplicationLibraryNew The application library object from where import the files
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew importFiles(ADOApplicationLibraryNew otherApplicationLibraryNew) throws Exception{
        if(otherApplicationLibraryNew == null)
            throw new Exception("Incompatible libraries: The provided ADOApplicationLibraryNew is null");

        String log = "";
        for(Identifier otherFileId : otherApplicationLibraryNew.getFileList()){
            try{
                Val otherFileVal = otherApplicationLibraryNew.findFileValue(otherFileId);
                this.addFile(otherFileId.getRaw(), otherFileVal.getRaw(false));
            }catch(Exception ex){log += "Skipped File with ID "+otherFileId+"\n";}
        }
        System.err.println(log);
        return this;
    }
    
    /**
     * Import a specific file from another ADOApplicationLibraryNew object
     * @param otherApplicationLibraryNew The application library object from where import the file
     * @param fileId The id of the file to import
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew importFile(ADOApplicationLibraryNew otherApplicationLibraryNew, String fileId) throws Exception{
        if(otherApplicationLibraryNew == null)
            throw new Exception("Incompatible libraries: The provided ADOApplicationLibraryNew is null");

        this.addFile(fileId, otherApplicationLibraryNew.findFileValue(fileId).getRaw(false));
        
        return this;
    }
    
    /**
     * Import all classes and relations from another ADOApplicationLibraryNew object
     * @param otherApplicationLibraryNew The application library  object from where import the classes and relations
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew importClassesAndRelations(ADOApplicationLibraryNew otherApplicationLibraryNew) throws Exception{
        if(otherApplicationLibraryNew == null)
            throw new Exception("Incompatible libraries: The provided ADOApplicationLibraryNew is null");

        String log = "";
        for(ADOClass adoClass : otherApplicationLibraryNew.getDynamicLibrary().getClasses()){
            try{
                if(!adoClass.isInternal())
                    this.getDynamicLibrary().addClass(adoClass);
            }catch(Exception ex){ex.printStackTrace(); log += "Skipped ADOClass "+adoClass.getId()+"\n";}
        }
       
        for(ADORelation adoRelation : otherApplicationLibraryNew.getDynamicLibrary().getRelations()){
            try{
                if(!adoRelation.isInternal())
                    this.getDynamicLibrary().addRelation(adoRelation);
            }catch(Exception ex){ex.printStackTrace(); log += "Skipped ADORelation "+adoRelation.getId()+"\n";}
        }
        
        
        for(ADOClass adoClass : otherApplicationLibraryNew.getStaticLibrary().getClasses()){
            try{
                if(!adoClass.isInternal())
                    this.getStaticLibrary().addClass(adoClass);
            }catch(Exception ex){ex.printStackTrace(); log += "Skipped ADOClass "+adoClass.getId()+"\n";}
        }
       
        for(ADORelation adoRelation : otherApplicationLibraryNew.getStaticLibrary().getRelations()){
            try{
                if(!adoRelation.isInternal())
                    this.getStaticLibrary().addRelation(adoRelation);
            }catch(Exception ex){ex.printStackTrace(); log += "Skipped ADORelation "+adoRelation.getId()+"\n";}
        }
        
        System.err.println(log);
        return this;
    }
    
    /**
     * Import all the special classes from another ADOApplicationLibraryNew object
     * @param otherApplicationLibraryNew The application library object from where import the special classes
     * @param fromDynamicLib When true import the special classes presents in the dynamic library ("__ModelTypeMetaData__" and "__LibraryMetaData__"). When false  import the special classes presents in the static library  
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew importSpecialClasses(ADOApplicationLibraryNew otherApplicationLibraryNew, boolean fromDynamicLib) throws Exception{
        if(fromDynamicLib)
            for(String specialClass : ADOClass.specialDynamicClasses)
                importClass(otherApplicationLibraryNew, fromDynamicLib, specialClass);
        return this;
    }
    
    /**
     * Import a specific class from another ADOApplicationLibraryNew object maintaining the library consistency
     * @param otherApplicationLibraryNew The application library object from where import the class
     * @param fromDynamicLib When true import the class from-to the dynamic library. When false the static library is used
     * @param classId The Id of the class to import  
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew importClass(ADOApplicationLibraryNew otherApplicationLibraryNew, boolean fromDynamicLib, String classId) throws Exception{
        ADOLibrary otherLib = (fromDynamicLib)?otherApplicationLibraryNew.getDynamicLibrary():otherApplicationLibraryNew.getStaticLibrary();
        ADOLibrary myLib = (fromDynamicLib)?this.getDynamicLibrary():this.getStaticLibrary();
        
        ArrayList<ADOClass> classList = otherLib.getClasses(classId);
        ArrayList<ADOClass> notInternalClassList = new ArrayList<ADOClass>();
        
        ADOClass classDef = null;
        for(ADOClass clazz : classList){
            if(clazz.hasSuperClassId())
                classDef = clazz;
            if(!clazz.isInternal())
                notInternalClassList.add(clazz);
        }
        
        if(classDef != null)
            importClass(otherApplicationLibraryNew, fromDynamicLib, classDef.getSuperClassId().getRaw());

        ArrayList<ADOClass> alreadyPresentClassList = myLib.getClasses(classId);
        ADOClass alreadyPresentClassDef = null;
        for(ADOClass alreadyPresentClass : alreadyPresentClassList){
            if(!alreadyPresentClass.isInternal()){
                if(alreadyPresentClass.hasSuperClassId())
                    alreadyPresentClassDef = alreadyPresentClass;
            }
        }
        /*
         NOTES:
         - if the classes I want to import does not have an external definition, then I can import them without definition (because for sure is internal)
         - if the classes I want to import does have an external definition, then:
         --- if I already have a class with that definition, I must add only the redefined one,
         --- else I must add a class with the definition
         */
        
        ADOClass classToAdd = null;
        if(classDef == null || classDef.isInternal() || alreadyPresentClassDef != null)
            classToAdd = new ADOClass(classId);
        else
            classToAdd = new ADOClass(classId, classDef.getSuperClassId().getRaw());
        
        myLib.addClass(false, classToAdd);

        /*Here add all the attributes of all the classes to add*/
        for(ADOClass notInternalClass : notInternalClassList){
            for(ADOAttribute attrib : notInternalClass.getAttributes()){
                
                if(classToAdd.checkAttributeDefinitionPresence(attrib.getId().getRaw())){
                    /*Here we have to add the attribute without definition, so only with the value*/
                    if(attrib.getValue() == null)
                        continue;
                    ADOAttribute attributeToAdd = new ADOAttribute(attrib.isClassAttribute(), attrib.getId().getRaw(), attrib.getValue());
                    attributeToAdd.addFacet(attrib.getFacets());
                    classToAdd.addAttribute(attributeToAdd);
                }else{
                    /*Here we have to add the attribute with definition*/
                    if((attrib.getType() != null || attrib.isRecordAttribute()))
                        classToAdd.addAttribute(attrib);
                    else {
                        /*When the attribute definition is not present I have to search it in the super classes*/
                        ADOAttribute attribDef = notInternalClass.getGeneralAttributeDefinition(attrib.getId().getRaw());
                        classToAdd.addAttribute(attribDef);
                        classToAdd.addAttribute(attrib);
                    }
                }

            }
        }
        return this;
    }
    
    /**
     * Import a specific relation from another ADOApplicationLibraryNew object maintaining the library consistency
     * @param otherApplicationLibraryNew The application library object from where import the relation
     * @param fromDynamicLib When true import the relation from-to the dynamic library. When false the static library is used
     * @param relationId The Id of the relation to import  
     * @return ADOApplicationLibraryNew This object
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew importRelation(ADOApplicationLibraryNew otherApplicationLibraryNew, boolean fromDynamicLib, String relationId) throws Exception{
        ADOLibrary otherLib = (fromDynamicLib)?otherApplicationLibraryNew.getDynamicLibrary():otherApplicationLibraryNew.getStaticLibrary();
        ADOLibrary myLib = (fromDynamicLib)?this.getDynamicLibrary():this.getStaticLibrary();
        
        ArrayList<ADORelation> relationList = otherLib.getRelations(relationId);
        ArrayList<ADORelation> notInternalRelationList = new ArrayList<ADORelation>();
        
        ADORelation relationDef = null;
        for(ADORelation relation : relationList){
            if(relation.hasFromTo())
                relationDef = relation;
            if(!relation.isInternal())
                notInternalRelationList.add(relation);
        }

        /*
        NOTES:
        - if the relations I want to import does not have an external definition, then I can import them without definition (because for sure is internal)
        - if the relations I want to import does have an external definition, then:
        --- if I already have a relations with that definition, I must add only the redefined one,
        --- else I must add a relations with the definition
        */

        ADORelation relationToAdd = null;
        if(myLib.hasRelationDefinition(relationId))
            relationToAdd = new ADORelation(relationId);
        else
            relationToAdd = new ADORelation(relationId, relationDef.getIdFrom(), relationDef.getIdTo());
        
        myLib.addRelation(false, relationToAdd);
        
        /*Here add all the attributes of all the relations to add*/
        for(ADORelation notInternalRelation : notInternalRelationList){
            for(ADOAttribute attrib : notInternalRelation.getAttributes()){
                
                if(relationToAdd.checkAttributeDefinitionPresence(attrib.getId().getRaw())){
                    /*Here we have to add the attribute without definition, so only with the value*/
                    if(attrib.getValue() == null)
                        continue;
                    ADOAttribute attributeToAdd = new ADOAttribute(attrib.isClassAttribute(), attrib.getId().getRaw(), attrib.getValue());
                    attributeToAdd.addFacet(attrib.getFacets());
                    relationToAdd.addAttribute(attributeToAdd);
                }else{
                    /*Here we have to add the attribute with definition*/
                    if((attrib.getType() != null || attrib.isRecordAttribute()))
                        relationToAdd.addAttribute(attrib);
                    else {
                        /*When the attribute definition is not present I have to search it in the upper relations*/
                        ADOAttribute attribDef = notInternalRelation.getGeneralAttributeDefinition(attrib.getId().getRaw());
                        relationToAdd.addAttribute(attribDef);
                        relationToAdd.addAttribute(attrib);
                    }
                }
            }
        }
        return this;
    }
}
