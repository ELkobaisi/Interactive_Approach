package org.adoxx.all.api.primitive;

import java.util.HashMap;
import java.util.Map.Entry;

public class RecordVal {

    private HashMap<Identifier, Val> attrVal = new HashMap<Identifier, Val>();
    
    public RecordVal addAttribute(Identifier identifier, Val val) throws Exception{
        if(identifier == null || val == null)
            throw new Exception("Not Allowed");
        attrVal.put(identifier, val);
        
        return this;
    }
    
    public RecordVal addAttribute(HashMap<Identifier, Val> attrList) throws Exception{
        for(Entry<Identifier, Val> entry:attrList.entrySet())
            addAttribute(entry.getKey(), entry.getValue());
        return this;
    }
    
    @Override
    public String toString(){
        String ret = "RECORD\n\n";
        for(Entry<Identifier, Val> entry : attrVal.entrySet())
            ret += "ATTRIBUTE "+entry.getKey().toString()+"\nVALUE "+entry.getValue().toString() + "\n\n";
        ret += "END\n\n";
        return ret;
    }
}
