package org.adoxx.all.api.library.newlib;

import java.util.ArrayList;
import java.util.Set;

import org.adoxx.all.api.library.newlib.definitions.ApplicationLibDefinition;
import org.adoxx.all.api.primitive.AttrVal;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.Val;

public class NewLib {

    private ApplicationLibDefinition applicationLibDefinition = null;
    private BpLib bpLib = null;
    private WeLib weLib = null;
    private Files files = null;
    private ArrayList<RecordClass> recordClassList = new ArrayList<RecordClass>();
    private ArrayList<AttrProf> attrProfList = new ArrayList<AttrProf>();
    
    
    public NewLib(ApplicationLibDefinition applicationLibDefinition, BpLib bpLib, WeLib weLib, Files files) throws Exception {
        if(applicationLibDefinition == null || bpLib == null || weLib == null || files == null)
            throw new Exception("Not Allowed");
        
        this.applicationLibDefinition = applicationLibDefinition;
        this.bpLib = bpLib;
        this.weLib = weLib;
        this.files = files;
    }

    public void addRecordClass(RecordClass recordClass) throws Exception{
        if(recordClass == null)
            throw new Exception("Not Allowed");
        
        if(recordClassList.contains(recordClass))
            throw new Exception("An Record Class with id " + recordClass.getId().toString() + " has been already defined for the Library " + this.getId().toString());
        
        recordClassList.add(recordClass);
    }
    
    public void addAttrProfList(AttrProf attrProf) throws Exception{
        if(attrProf == null)
            throw new Exception("Not Allowed");
        
        if(attrProfList.contains(attrProf))
            throw new Exception("An Attribute Profile Class with id " + attrProf.getId().toString() + " has been already defined for the Library " + this.getId().toString());
        
        attrProfList.add(attrProf);
    }
    
    public Identifier getId(){
        return this.applicationLibDefinition.getId();
    }
    
    public Identifier getDynamicLibId(){
        return this.bpLib.getId();
    }

    public AttrVal findDynamicLibAttributeValue(String attributeId) throws Exception{
        return this.bpLib.findAttributeValue(attributeId);
    }
    
    public Identifier getStaticLibId(){
        return this.weLib.getId();
    }

    public AttrVal findStaticLibAttributeValue(String attributeId) throws Exception{
        return this.weLib.findAttributeValue(attributeId);
    }
    
    public Files addFile(Identifier identifier, Val valBase64) throws Exception{
        return files.addFile(identifier, valBase64);
    }
    
    public Val findFileValue(String fileId) throws Exception{
        return files.findFileValue(fileId);
    }
    
    public Val findFileValue(Identifier fileId) throws Exception{
        return files.findFileValue(fileId);
    }
    
    public boolean hasFile(String fileId) {
        return files.hasFile(fileId);
    }
    
    public Set<Identifier> getFileList(){
        return files.getFileList();
    }
    
    public RecordClass findRecordClass(String id) throws Exception{
        for(RecordClass recordClass:recordClassList)
            if(recordClass.getId().equals(new Identifier(id)))
                return recordClass;

        throw new Exception("Impossible to find an Record Class with id " + id);
    }
    
    public AttrProf findAttributeProfileClass(String id) throws Exception{
        for(AttrProf attrProf:attrProfList)
            if(attrProf.getId().equals(new Identifier(id)))
                return attrProf;

        throw new Exception("Impossible to find an Attribute Profile Class with id " + id);
    }
    
    public RecordClass[] getRecordClasses(){
        RecordClass[] ret = new RecordClass[recordClassList.size()];
        recordClassList.toArray(ret);
        return ret;
    }
    
    public AttrProf[] getAttributeProfileClasses(){
        AttrProf[] ret = new AttrProf[attrProfList.size()];
        attrProfList.toArray(ret);
        return ret;
    }
    
    @Override
    public String toString(){
        String ret = applicationLibDefinition.toString();
        for(RecordClass recordClass:recordClassList)
            ret += recordClass.toString();
        for(AttrProf attrProf:attrProfList)
            ret += attrProf.toString();
        ret += bpLib.toString() + weLib.toString() + files.toString();
        return ret;
    }
}
