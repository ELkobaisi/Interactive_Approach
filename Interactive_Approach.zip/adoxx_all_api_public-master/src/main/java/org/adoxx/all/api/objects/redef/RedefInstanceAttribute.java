package org.adoxx.all.api.objects.redef;

import java.util.ArrayList;

import org.adoxx.all.api.objects.Attribute;
import org.adoxx.all.api.objects.AttributeI;
import org.adoxx.all.api.objects.definitions.FacetDefinition;
import org.adoxx.all.api.objects.redef.definitions.RedefInstanceAttributeDefinition;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;

public class RedefInstanceAttribute implements AttributeI {

    public RedefInstanceAttributeDefinition redefInstanceAttributeDefinition = null;
    private ArrayList<FacetDefinition> facetList = new ArrayList<FacetDefinition>();
    
    public RedefInstanceAttribute(RedefInstanceAttributeDefinition redefInstanceAttributeDefinition) throws Exception {
        if(redefInstanceAttributeDefinition == null)
            throw new Exception("Not Allowed");
        
        this.redefInstanceAttributeDefinition = redefInstanceAttributeDefinition;
    }

    public void addFacet(FacetDefinition facet) throws Exception{
        if(facet == null)
            throw new Exception("Not Allowed");
        
        if(facetList.contains(facet))
            throw new Exception("A facet with id " + facet.getId().toString() + " has been already defined for the attribute " + this.getId().toString());
        
        facetList.add(facet);
    }
    
    public boolean hasFacet(String facetId) {
        for(FacetDefinition facet: facetList)
            if(facet.getId().equals(new Identifier(facetId)))
                return true;
        return false;
    }
    
    public Val findFacetValue(String facetId) throws Exception{
        for(FacetDefinition facet: facetList)
            if(facet.getId().equals(new Identifier(facetId)))
                return facet.getValue();
        
        throw new Exception("Impossible to find an facet with id " + facetId);
    }
    
    public Identifier getId(){
        return this.redefInstanceAttributeDefinition.getId();
    }
    
    public TypeIdentifier getType(){
        return this.redefInstanceAttributeDefinition.getType();
    }
    
    public Val getValue(){
        return this.redefInstanceAttributeDefinition.getValue();
    }
    
    public boolean isRecord(){
        return this.redefInstanceAttributeDefinition.isRecord();
    }
    
    public FacetDefinition[] getFacets(){
        FacetDefinition[] ret = new FacetDefinition[this.facetList.size()];
        this.facetList.toArray(ret);
        return ret;
    }
    
    public boolean isClassAttribute() {
        return false;
    }
    
    @Override
    public int hashCode(){
        /*
        if(this.getType() == null)
            if(this.isRecord())
                return 1013 *getId().hashCode() ^ 1009 * 2;
            else
                return getId().hashCode();
        else
            return 1013 *getId().hashCode() ^ 1009 *this.getType().toString().hashCode();
        */
        
        if(this.getType() != null || this.isRecord())
            return 1013 *getId().hashCode() ^ 1009 * 2;
        else
            return getId().hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof Attribute))
            return o==this;
        
        Attribute other = (Attribute)o;
        //return ((Attribute)o).getId().equals(this.getId()) && (((Attribute)o).getType() == this.getType()) && this.getType() != null;
        //return ((Attribute)o).getId().equals(this.getId()) && (((((Attribute)o).getType() == this.getType()) && this.getType() != null) || (((Attribute)o).isRecord() && this.isRecord()));
        return (other.getId().equals(this.getId())) && (this.getType() != null || this.isRecord()) && (other.getType() != null || other.isRecord());
    }
    
    @Override
    public String toString(){
        String ret = redefInstanceAttributeDefinition.toString();
        for(FacetDefinition facet:facetList)
            ret += facet.toString();
        
        return ret;
    }
}
