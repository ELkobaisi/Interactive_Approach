package org.adoxx.all.api.objects.definitions;

import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;

public class AttributeDefinition {

    public ClassAttributeDefinition classAttributeDefinition = null;
    public InstanceAttributeDefinition instanceAttributeDefinition = null;
    
    public AttributeDefinition(ClassAttributeDefinition classAttributeDefinition) throws Exception{
        if(classAttributeDefinition == null)
            throw new Exception("Not allowed");
        
        this.classAttributeDefinition = classAttributeDefinition;
    }
    
    public AttributeDefinition(InstanceAttributeDefinition instanceAttributeDefinition) throws Exception{
        if(instanceAttributeDefinition == null)
            throw new Exception("Not allowed");
        
        this.instanceAttributeDefinition = instanceAttributeDefinition;
    }
    
    public Identifier getId(){
        if(this.classAttributeDefinition != null)
            return this.classAttributeDefinition.getId();
        else
            return this.instanceAttributeDefinition.getId();
    }
    
    public TypeIdentifier getType(){
        if(this.classAttributeDefinition != null)
            return this.classAttributeDefinition.getType();
        else
            return this.instanceAttributeDefinition.getType();
    }
    
    public Val getValue(){
        if(this.classAttributeDefinition != null)
            return this.classAttributeDefinition.getValue();
        else
            return this.instanceAttributeDefinition.getValue();
    }
    
    public boolean isRecord(){
        if(this.classAttributeDefinition != null)
            return this.classAttributeDefinition.isRecord();
        else
            return this.instanceAttributeDefinition.isRecord();
    }
    
    @Override
    public String toString(){
        if(classAttributeDefinition != null)
            return classAttributeDefinition.toString();
        else
            return instanceAttributeDefinition.toString();
    }
}
