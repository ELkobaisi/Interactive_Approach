package org.adoxx.all.abstracted;

import org.adoxx.ado.ADOUtils;
import org.adoxx.all.api.AllFile;
import org.adoxx.all.api.Version;
import org.adoxx.utils.Utils;

/**
 * <h1>ADOAllFile</h1>
 * Represent the main ALL file structure and contain methods related to it. 
 * 
 * @author Damiano Falcioni
 */
public class ADOAllFile {

    private AllFile allFile = null;
    private ADOApplicationLibraryNew adoApplicationLibraryNew = null;
    private ADOApplicationLibraryExtend adoApplicationLibraryExtend = null;
    
    /**
     * Generate an instance of this class based on a ADOApplicationLibraryNew using the default version (5.1)
     * @param adoApplicationLibraryNew The ADOApplicationLibraryNew object in case of new library generation
     * @throws Exception in case of error
     */
    public ADOAllFile(ADOApplicationLibraryNew adoApplicationLibraryNew) throws Exception {
        this(Version.defaultVersion, adoApplicationLibraryNew);
    }
    
    /**
     * Generate an instance of this class based on a ADOApplicationLibraryNew and a specific version 
     * @param version The ADOxx ALL version to use
     * @param adoApplicationLibraryNew The ADOApplicationLibraryNew object in case of new library generation
     * @throws Exception in case of error
     */
    public ADOAllFile(String version, ADOApplicationLibraryNew adoApplicationLibraryNew) throws Exception {
        adoApplicationLibraryNew.parentAllFile = this;
        this.adoApplicationLibraryNew = adoApplicationLibraryNew;
        this.allFile = new AllFile(new Version(version), adoApplicationLibraryNew.newLib);
    }
    
    /**
     * Generate an instance of this class based on a ADOApplicationLibraryExtend using the default version (5.1)
     * @param adoApplicationLibraryExtend The ADOApplicationLibraryExtend object in case of new library generation
     * @throws Exception in case of error
     */
    public ADOAllFile(ADOApplicationLibraryExtend adoApplicationLibraryExtend) throws Exception {
        this(Version.defaultVersion, adoApplicationLibraryExtend);
    }
    
    /**
     * Generate an instance of this class based on a ADOApplicationLibraryExtend and a specific version 
     * @param version The ADOxx ALL version to use
     * @param adoApplicationLibraryExtend The ADOApplicationLibraryExtend object in case of new library generation
     * @throws Exception in case of error
     */
    public ADOAllFile(String version, ADOApplicationLibraryExtend adoApplicationLibraryExtend) throws Exception {
        adoApplicationLibraryExtend.parentAllFile = this;
        this.adoApplicationLibraryExtend = adoApplicationLibraryExtend;
        this.allFile = new AllFile(new Version(version), adoApplicationLibraryExtend.libraries, adoApplicationLibraryExtend.applicationLibraries);
    }
    
    /**
     * Get the ADOApplicationLibraryNew when initialised in the constructor, or an exception if in the constructor an ADOApplicationLibraryExtend has been provided
     * @return ADOApplicationLibraryNew The ADOApplicationLibraryNew as provided by the constructor
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryNew getApplicationLibraryNew() throws Exception{
        if(adoApplicationLibraryNew == null)
            throw new Exception("Impossible to obtain the ADOApplicationLibraryNew. The ADOAllFile contain only a ADOApplicationLibraryExtend");
        return adoApplicationLibraryNew;
    }
    
    /**
     * Get the ADOApplicationLibraryExtend when initialised in the constructor, or an exception if in the constructor an ADOApplicationLibraryNew has been provided
     * @return ADOApplicationLibraryExtend The ADOApplicationLibraryExtend as provided by the constructor
     * @throws Exception in case of error
     */
    public ADOApplicationLibraryExtend getApplicationLibraryExtend() throws Exception{
        if(adoApplicationLibraryExtend == null)
            throw new Exception("Impossible to obtain the ADOApplicationLibraryExtend. The ADOAllFile contain only a ADOApplicationLibraryNew");
        return adoApplicationLibraryExtend;
    }
    
    /**
     * Get the ADO ALL Version defined for this ADOAllFile
     * @return Version The ADO ALL Version
     */
    public Version getVersion(){
        return allFile.getVersion();
    }
    
    /**
     * Generate the ALL representation of this class
     * @return String The ALL string representing this ADOAllFile and all its content
     */
    public String generateALL(){
        return allFile.generateAll();
    }
    
    /**
     * Generate the ALL representation of this class and save it as a file in the provided path
     * @param outputFile The path of the ALL file to generate
     * @return ADOAllFile This object
     * @throws Exception in case of error
     */
    public ADOAllFile generateALLFile(String outputFile) throws Exception{
        String allModel = generateALL();
        Utils.writeFile(allModel.getBytes("UTF-8"), outputFile, false);
        return this;
    }
    
    /**
     * Generate the ALL representation of this class and encode it in the ABL format automatically using the internal algorithm when available or when not available, using the remote web service 
     * @return byte[] The ALL encoded in ABL binary format
     * @throws Exception in case of error
     */
    public byte[] generateABL() throws Exception{
        String allModel = allFile.generateAll();
        byte[] abl = null;
        try {
            abl = ADOUtils.convertALL2ABL(allModel);
        } catch(Exception e) {
            abl = ADOUtils.callALL2ABLService(allModel, "adoxxDynamicDB");
        }
        return abl;
    }
    
    /**
     * Generate the ALL representation of this class and encode it in the ABL format automatically using the internal algorithm when available or when not available, using the remote web service 
     * @param outputFile The path of the ABL file to generate
     * @return ADOAllFile This object
     * @throws Exception in case of error
     */
    public ADOAllFile generateABLFile(String outputFile) throws Exception{
        byte[] abl = generateABL();  
        Utils.writeFile(abl, outputFile, false);
        return this;
    }
    
    /**
     * Generate internally the ABL encoding of the ALL representation of this object and create the ADOxx Database. Then execute the ADOxx modelling toolkit with this Database giving the possibility to check if everything is correctly working
     * @param dbName The name of the ADOxx Database to create. In case an existing database is selected it will be dropped before
     * @param adoxxLicenseKey A valid license key required to create the ADOxx database (like in the ADOxx installation process)
     * @return ADOAllFile This object
     * @throws Exception in case of error
     */
    public ADOAllFile generateDB(String dbName, String adoxxLicenseKey) throws Exception{
        return generateDB(dbName, adoxxLicenseKey, null, null, null, null, null, null);
    }
    
    /**
     * Generate internally the ABL encoding of the ALL representation of this object and create the ADOxx Database. Then execute the ADOxx modelling toolkit with this Database giving the possibility to check if everything is correctly working
     * @param dbName The name of the ADOxx Database to create. In case an existing database is selected it will be dropped before
     * @param adoxxLicenseKey A valid license key required to create the ADOxx database (like in the ADOxx installation process)
     * @param adoxxLicenseIni (only for advanced users) replace the content of the license ini file 
     * @return ADOAllFile This object
     * @throws Exception in case of error
     */
    public ADOAllFile generateDB(String dbName, String adoxxLicenseKey, String adoxxLicenseIni) throws Exception{
        return generateDB(dbName, adoxxLicenseKey, null, adoxxLicenseIni, null, null, null, null);
    }
    
    /**
     * Generate internally the ABL encoding of the ALL representation of this object and create the ADOxx Database. Then execute the ADOxx modelling toolkit with this Database giving the possibility to check if everything is correctly working
     * @param dbName The name of the ADOxx Database to create. In case an existing database is selected it will be dropped before
     * @param adoxxLicenseKey A valid license key required to create the ADOxx database (like in the ADOxx installation process)
     * @param ablFilePath (optional) The file where to save the generated ABL file
     * @param adoxxLicenseIni (only for advanced users) replace the content of the license ini file 
     * @param adoxxInstallationPath The personalised ADOxx installation folder. When null or empty the default one will be used (%ProgramFiles(x86)%/BOC/ADOxx15_EN_SA)
     * @param sqlInstance The SQL Server instance to use. When null or empty the default one will be used (.\ADOXX15EN)
     * @param sqlSAUser The SQL SA username. When null or empty the default one will be used (sa)
     * @param sqlSAPassword The SQL password related to the SA username. When null or empty the default one will be used (12+*ADOxx*+34)
     * @return ADOAllFile This object
     * @throws Exception in case of error
     */
    public ADOAllFile generateDB(String dbName, String adoxxLicenseKey, String ablFilePath, String adoxxLicenseIni, String adoxxInstallationPath, String sqlInstance, String sqlSAUser, String sqlSAPassword) throws Exception{
        String ablPath = (ablFilePath != null) ? ablFilePath : System.getProperty("java.io.tmpdir")+ "/adoxxDynamicDB.abl";
        generateABLFile(ablPath);    
        ADOUtils.callABL2DBScript(ablPath, dbName, adoxxLicenseKey, adoxxLicenseIni, adoxxInstallationPath, sqlInstance, sqlSAUser, sqlSAPassword);
        return this;
    }
}