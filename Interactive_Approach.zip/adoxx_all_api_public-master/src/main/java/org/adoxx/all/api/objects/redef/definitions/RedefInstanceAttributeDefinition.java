package org.adoxx.all.api.objects.redef.definitions;

import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;

public class RedefInstanceAttributeDefinition {

    private Identifier identifier = null;
    private TypeIdentifier type = null;
    private Val value = null;
    private boolean isRecord = false;
    
    public RedefInstanceAttributeDefinition(Identifier identifier, boolean isRecord) throws Exception {
        if(identifier == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.isRecord = isRecord;
    }
    
    public RedefInstanceAttributeDefinition(Identifier identifier, TypeIdentifier type) throws Exception {
        if(identifier == null || type == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.type = type;
    }
    
    public RedefInstanceAttributeDefinition(Identifier identifier, TypeIdentifier type, Val value) throws Exception {
        if(identifier == null || type == null || value == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.type = type;
        this.value = value;
    }

    public RedefInstanceAttributeDefinition(Identifier identifier, Val value) throws Exception {
        if(identifier == null || value == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.value = value;
    }
    
    public Identifier getId(){
        return identifier;
    }
    
    public TypeIdentifier getType(){
        return type;
    }
    
    public Val getValue(){
        return value;
    }
    
    public boolean isRecord(){
        return isRecord;
    }
    
    @Override
    public String toString(){
        String ret = "ATTRIBUTE " + identifier.toString() + "\n";
        if(type!=null)
            ret += " TYPE " + type.toString() + "\n";
        if(value!=null)
            ret += " VALUE " + value.toString() + "\n";
        if(isRecord)
            ret += " TYPE RECORD\n";
        ret += "\n";
        
        return ret;
    }
}
