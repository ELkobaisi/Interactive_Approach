package org.adoxx.all.abstracted.factory;

import org.adoxx.ado.ADOUtils;
import org.adoxx.all.abstracted.ADOAllFile;
import org.adoxx.all.abstracted.ADOApplicationLibraryNew;
import org.adoxx.all.abstracted.ADOAttribute;
import org.adoxx.all.abstracted.ADOClass;
import org.adoxx.all.abstracted.ADOLibrary;
import org.adoxx.all.abstracted.ADORelation;
import org.adoxx.all.api.library.newlib.Files;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;
import org.adoxx.all.parser.ADOAllParser;
import org.adoxx.all.parser.IStatusMonitor;
import org.adoxx.all.parser.JSONParser;
import org.adoxx.utils.Utils;

/**
 * <h1>ADOLibFactory</h1>
 * Represent a factory for ADOAllFile instances
 * 
 * @author Damiano Falcioni
 */
public class ADOLibFactory {
    
    /**
     * Generate an empty instance of the ADOAllFile class containing only an empty dynamic and and empty static library with the provided name and with the default ADOxx libraries attributes
     * @param libraryName The name of the library to generate
     * @return ADOAllFile An instance of the ADOAllFile class
     * @throws Exception in case of error
     */
    public static ADOAllFile generateADOxxTotalEmptyLibrary(String libraryName) throws Exception{
        return new ADOAllFile(
            new ADOApplicationLibraryNew(libraryName, 
                new ADOLibrary(true, libraryName + " Dynamic").addADOxxDefaultAttributes(),
                new ADOLibrary(false, libraryName + " Static").addADOxxDefaultAttributes(), 
                new Files()
            )
        );
    }
    
    /**
     * Generate an empty instance of the ADOAllFile class containing only an a dynamic library with the required ADOxx classes "__LibraryMetaData__" and "__ModelTypeMetaData__" (with attributes) and an empty static library with the provided name and with the default ADOxx libraries attributes
     * @param libraryName The name of the library to generate
     * @return ADOAllFile An instance of the ADOAllFile class
     * @throws Exception in case of error
     */
    public static ADOAllFile generateADOxxEmptyLibrary(String libraryName) throws Exception{
        return new ADOAllFile(
            new ADOApplicationLibraryNew(libraryName, 
                new ADOLibrary(true, libraryName + " Dynamic").addADOxxDefaultAttributes()
                    .addClass(
                        new ADOClass("__LibraryMetaData__", ADOClass.defaultSuperIdDynamic)
                            .setClassAbrstractAttribute(1)
                            .setAttrRepAttribute("NOTEBOOK\nCHAPTER \"Description\"\nATTR \"Name\"")
                            .addAttribute(new ADOAttribute(true, "homedir", TypeIdentifier.STRING, new Val("c:\\Program Files (x86)\\BOC\\ADOxx15_EN_SA\\")).addADOxxDefaultFacets())
                            .addAttribute(new ADOAttribute(true, "__ModelListChangeCounter__", TypeIdentifier.INTEGER, new Val(0)).addADOxxDefaultFacets())
                            .addAttribute(new ADOAttribute(true, "__APListChangeCounter__", TypeIdentifier.INTEGER, new Val(0)).addADOxxDefaultFacets())
                            .addAttribute(new ADOAttribute(true, "__UserListChangeCounter__", TypeIdentifier.INTEGER, new Val(0)).addADOxxDefaultFacets())
                            .addAttribute(new ADOAttribute(true, "ClassVisible", new Val(1)).addADOxxDefaultFacets())
                    )
                    .addClass(
                        new ADOClass("__ModelTypeMetaData__", ADOClass.defaultSuperIdDynamic)
                            .setClassAbrstractAttribute(1)
                            .setAttrRepAttribute("NOTEBOOK\nCHAPTER \"Description\"\nATTR \"Name\"")
                            .addAttribute(new ADOAttribute(true, "ClassVisible", new Val(1)).addADOxxDefaultFacets())
                            .addAttribute(new ADOAttribute(true, "__GfxThumb__", TypeIdentifier.LONGSTRING, new Val("")).addADOxxDefaultFacets())
                    )
                , 
                new ADOLibrary(false, libraryName + " Static").addADOxxDefaultAttributes(), 
                new Files()
            )
        );
    }

    /**
     * Generate an instance of the ADOAllFile class containing a dynamic library with two classes and a relation between them and empty static library with the provided names
     * @param libraryName The name of the library to generate
     * @param firstClassName The name of the first class to add to the dynamic library
     * @param secondClassName The name of the second class to add to the dynamic library
     * @return ADOAllFile An instance of the ADOAllFile class
     * @throws Exception in case of error
     */
    public static ADOAllFile generateADOxxTutorialLibrary(String libraryName, String firstClassName, String secondClassName) throws Exception{
        ADOAllFile lib = generateADOxxEmptyLibrary(libraryName);
        
        lib.getApplicationLibraryNew().getDynamicLibrary()
            .addClass(
                new ADOClass(firstClassName, ADOClass.defaultSuperIdDynamic)
                    .setClassAbrstractAttribute(0)
                    .setGraphRepAttribute("GRAPHREP\nSHADOW off\nFILL color:blue\nELLIPSE x:0.00cm y:0cm rx:1cm ry:1cm\nATTR \"Name\" x:0.00cm y:1.0cm w:c")
                    .setAttrRepAttribute("NOTEBOOK\nCHAPTER \"Description\"\nATTR \"Name\"\nATTR \"Attribute"+firstClassName+"\"")
                    .addAttribute(new ADOAttribute(false, "Attribute"+firstClassName, TypeIdentifier.STRING, new Val("Test")).addADOxxDefaultFacets())
            )
            .addClass(
                new ADOClass(secondClassName, ADOClass.defaultSuperIdDynamic)
                    .setClassAbrstractAttribute(0)
                    .setGraphRepAttribute("GRAPHREP\nSHADOW off\nFILL color:blue\nPOLYGON 3 x1:-1cm y1:1cm x2:0cm y2:-1cm x3:1cm y3:1cm\nATTR \"Name\" x:0.00cm y:1.0cm w:c")
                    .setAttrRepAttribute("NOTEBOOK\nCHAPTER \"Description\"\nATTR \"Name\"")
                    .setAttributeValue(true, "HlpTxt", new Val("test"))
            )
            .addRelation(
                new ADORelation(firstClassName+"2"+secondClassName, firstClassName, secondClassName)
            )
            .setModi("MODELTYPE \""+libraryName+"\"\nINCL \""+firstClassName+"\"\nINCL \""+secondClassName+"\"\nINCL \""+firstClassName+"2"+secondClassName+"\"");
        
        return lib;
    }
    
    /**
     * Load an instance of the ADOAllFile class with the data contained in an ABL file
     * @param ablFilePath The path of the ABL file to read
     * @param defaultMonitor If true, informations about the parsing are displayed in the error console every 5 seconds. If false nothing is displayed
     * @return ADOAllFile The instance of the ADOAllFile class generated
     * @throws Exception in case of error
     */
    public static ADOAllFile loadFromAblFile(String ablFilePath, boolean defaultMonitor) throws Exception{
        byte[] abl = Utils.readFile(ablFilePath);
        String allModel = ADOUtils.convertABL2ALL(abl);
        return loadFromAll(allModel, defaultMonitor);
    }
    
    /**
     * Load an instance of the ADOAllFile class with the data contained in an ABL file. This method give the possibility to manually provide a monitor for the ABL parsing status
     * @param ablFilePath The path of the ABL file to read
     * @param monitorIntervalInSeconds The interval in second for the monitoring. When this value is &lt;= 0 the monitor is disabled
     * @param monitor An instance of IStatusMonitor that manage the monitor data visualisation. When this value is null the default monitor is used
     * @return ADOAllFile The instance of the ADOAllFile class generated
     * @throws Exception in case of error
     */
    public static ADOAllFile loadFromAblFile(String ablFilePath, int monitorIntervalInSeconds, IStatusMonitor monitor) throws Exception{
        byte[] abl = Utils.readFile(ablFilePath);
        String allModel = ADOUtils.convertABL2ALL(abl);
        return loadFromAll(allModel, monitorIntervalInSeconds, monitor);
    }
    
    /**
     * Load an instance of the ADOAllFile class with the data provided as ABL
     * @param abl The binary content of the ABL file
     * @param defaultMonitor If true, informations about the parsing are displayed in the error console every 5 seconds. If false nothing is displayed
     * @return ADOAllFile The instance of the ADOAllFile class generated
     * @throws Exception in case of error
     */
    public static ADOAllFile loadFromAbl(byte[] abl, boolean defaultMonitor) throws Exception{
        String allModel = ADOUtils.convertABL2ALL(abl);
        return loadFromAll(allModel, defaultMonitor);
    }
    
    /**
     * Load an instance of the ADOAllFile class with the data provided as ABL. This method give the possibility to manually provide a monitor for the ABL parsing status
     * @param abl The binary content of the ABL file
     * @param monitorIntervalInSeconds The interval in second for the monitoring. When this value is &lt;= 0 the monitor is disabled
     * @param monitor An instance of IStatusMonitor that manage the monitor data visualisation. When this value is null the default monitor is used
     * @return ADOAllFile The instance of the ADOAllFile class generated
     * @throws Exception in case of error
     */
    public static ADOAllFile loadFromAbl(byte[] abl, int monitorIntervalInSeconds, IStatusMonitor monitor) throws Exception{
        String allModel = ADOUtils.convertABL2ALL(abl);
        return loadFromAll(allModel, monitorIntervalInSeconds, monitor);
    }
    
    /**
     * Load an instance of the ADOAllFile class with the data contained in an ALL file
     * @param allFilePath The path of the ALL file to read
     * @param defaultMonitor If true, informations about the parsing are displayed in the error console every 5 seconds. If false nothing is displayed
     * @return ADOAllFile The instance of the ADOAllFile class generated
     * @throws Exception in case of error
     */
    public static ADOAllFile loadFromAllFile(String allFilePath, boolean defaultMonitor) throws Exception {
        String allModel = new String(Utils.readFile(allFilePath), "UTF-8");
        return loadFromAll(allModel, defaultMonitor);
    }
    
    /**
     * Load an instance of the ADOAllFile class with the data contained in an ALL file. This method give the possibility to manually provide a monitor for the ALL parsing status
     * @param allFilePath The path of the ALL file to read
     * @param monitorIntervalInSeconds The interval in second for the monitoring. When this value is &lt;= 0 the monitor is disabled
     * @param monitor An instance of IStatusMonitor that manage the monitor data visualisation. When this value is null the default monitor is used
     * @return ADOAllFile The instance of the ADOAllFile class generated
     * @throws Exception in case of error
     */
    public static ADOAllFile loadFromAllFile(String allFilePath, int monitorIntervalInSeconds, IStatusMonitor monitor) throws Exception {
        String allModel = new String(Utils.readFile(allFilePath), "UTF-8");
        return loadFromAll(allModel, monitorIntervalInSeconds, monitor);
    }
    
    /**
     * Load an instance of the ADOAllFile class with the data provided as ALL
     * @param allModel The content of the ALL file
     * @param defaultMonitor If true, informations about the parsing are displayed in the error console every 5 seconds. If false nothing is displayed
     * @return ADOAllFile The instance of the ADOAllFile class generated
     * @throws Exception in case of error
     */
    public static ADOAllFile loadFromAll(String allModel, boolean defaultMonitor) throws Exception{
        if(defaultMonitor)
            return loadFromAll(allModel, 5, null);
        else
            return loadFromAll(allModel, -1, null);
    }
    
    /**
     * Load an instance of the ADOAllFile class with the data provided as ALL. This method give the possibility to manually provide a monitor for the ALL parsing status
     * @param allModel The content of the ALL file
     * @param monitorIntervalInSeconds The interval in second for the monitoring. When this value is &lt;= 0 the monitor is disabled
     * @param monitor An instance of IStatusMonitor that manage the monitor data visualisation. When this value is null the default monitor is used
     * @return ADOAllFile The instance of the ADOAllFile class generated
     * @throws Exception in case of error
     */
    public static ADOAllFile loadFromAll(String allModel, int monitorIntervalInSeconds, IStatusMonitor monitor) throws Exception {
        if(monitor == null)
            return new ADOAllParser(allModel)
                .setDefaultMonitor(monitorIntervalInSeconds)
                .parse()
                .getADOAllFile();
        else
            return new ADOAllParser(allModel)
                .setMonitor(monitor, monitorIntervalInSeconds)
                .parse()
                .getADOAllFile();
    }
    
    /**
     * Load an instance of the ADOAllFile class with the data provided as JSON string
     * @param jsonModel The JSON containing the data to parse 
     * @return ADOAllFile The instance of the ADOAllFile class generated
     * @throws Exception in case of error
     */
    public static ADOAllFile loadFromJson(String jsonModel) throws Exception {
        return new JSONParser(jsonModel).parse().getADOAllFile();
    }
    
    /**
     * Load an instance of the ADOAllFile class with the data provided in a JSON file
     * @param jsonFilePath The path of the JSON file containing the data to parse 
     * @return ADOAllFile The instance of the ADOAllFile class generated
     * @throws Exception in case of error
     */
    public static ADOAllFile loadFromJsonFile(String jsonFilePath) throws Exception {
        String jsonModel = new String(Utils.readFile(jsonFilePath), "UTF-8");
        return loadFromJson(jsonModel);
    }
    
    /**
     * Generate a Java file that contain the code to generate the provided ALL
     * @param filePath The path of the Java file to generate
     * @param allFilePath The path of the ALL file to read
     * @param defaultMonitor If true, informations about the parsing are displayed in the error console every 5 seconds. If false nothing is displayed
     * @throws Exception in case of error
     */
    public static void generateJavaCodeFileFromAllFile(String filePath, String allFilePath, boolean defaultMonitor) throws Exception {
        String allModel = new String(Utils.readFile(allFilePath), "UTF-8");
        generateJavaCodeFileFromAll(filePath, allModel, defaultMonitor);
    }
    
    /**
     * Generate a Java file that contain the code to generate the provided ALL
     * @param filePath The path of the Java file to generate
     * @param allFilePath The path of the ALL file to read
     * @param monitorIntervalInSeconds The interval in second for the monitoring. When this value is &lt;= 0 the monitor is disabled
     * @param monitor An instance of IStatusMonitor that manage the monitor data visualisation. When this value is null the default monitor is used
     * @throws Exception in case of error
     */
    public static void generateJavaCodeFileFromAllFile(String filePath, String allFilePath, int monitorIntervalInSeconds, IStatusMonitor monitor) throws Exception {
        String allModel = new String(Utils.readFile(allFilePath), "UTF-8");
        generateJavaCodeFileFromAll(filePath, allModel, monitorIntervalInSeconds, monitor);
    }
    
    /**
     * Generate a Java file that contain the code to generate the provided ALL
     * @param filePath The path of the Java file to generate
     * @param allModel The content of the ALL file
     * @param defaultMonitor If true, informations about the parsing are displayed in the error console every 5 seconds. If false nothing is displayed
     * @throws Exception in case of error
     */
    public static void generateJavaCodeFileFromAll(String filePath, String allModel, boolean defaultMonitor) throws Exception{
        if(defaultMonitor)
            generateJavaCodeFileFromAll(filePath, allModel, 5, null);
        else
            generateJavaCodeFileFromAll(filePath, allModel, -1, null);
    }
    
    /**
     * Generate a Java file that contain the code to generate the provided ALL
     * @param filePath The path of the Java file to generate
     * @param allModel The content of the ALL file
     * @param monitorIntervalInSeconds The interval in second for the monitoring. When this value is &lt;= 0 the monitor is disabled
     * @param monitor An instance of IStatusMonitor that manage the monitor data visualisation. When this value is null the default monitor is used
     * @throws Exception in case of error
     */
    public static void generateJavaCodeFileFromAll(String filePath, String allModel, int monitorIntervalInSeconds, IStatusMonitor monitor) throws Exception {
        if(!filePath.endsWith(".java"))
            throw new Exception("Please specify a .java file");
        String fileName = Utils.extractFileName(filePath);
        String out = "";
        
        if(monitor == null)
            out = new ADOAllParser(allModel)
                .setDefaultMonitor(monitorIntervalInSeconds)
                .parse()
                .getADOAllJavaCode(fileName);
        else
            out = new ADOAllParser(allModel)
                .setMonitor(monitor, monitorIntervalInSeconds)
                .parse()
                .getADOAllJavaCode(fileName);
                
        Utils.writeFile(out.getBytes("UTF-8"), filePath, false);
    }
}
