package org.adoxx.all.api.library.newlib.definitions;

import org.adoxx.all.api.primitive.Identifier;

public class ApplicationLibDefinition {

    private Identifier libraryId = null;
    
    public ApplicationLibDefinition(Identifier libraryId) throws Exception {
        if(libraryId == null)
            throw new Exception("Not Allowed");
        
        this.libraryId = libraryId;
    }
    
    public Identifier getId(){
        return libraryId;
    }

    @Override
    public String toString(){
        return "APPLICATION LIBRARY " + libraryId.toString() + "\n\n";
    }
}
