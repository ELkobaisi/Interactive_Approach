package org.adoxx.all.abstracted;

import java.util.ArrayList;

import org.adoxx.all.api.library.InstanceAttributeSetting;
import org.adoxx.all.api.library.Library;
import org.adoxx.all.api.library.newlib.BpLib;
import org.adoxx.all.api.library.newlib.WeLib;
import org.adoxx.all.api.library.presetlib.libraries.BpLibrary;
import org.adoxx.all.api.library.presetlib.libraries.WeLibrary;
import org.adoxx.all.api.library.presetlib.libraries.definitions.BpLibraryDefinition;
import org.adoxx.all.api.library.presetlib.libraries.definitions.WeLibraryDefinition;
import org.adoxx.all.api.objects.RelationClass;
import org.adoxx.all.api.primitive.AttrVal;
import org.adoxx.all.api.primitive.Identifier;

/**
 * <h1>ADOLibrary</h1>
 * Represent the ALL file structure relative to a Library in ADOxx and contain methods related to it. 
 * 
 * @author Damiano Falcioni
 */
public class ADOLibrary {

    /**
     * <h1>IdAttrVal</h1>
     * Represent a pair containing an id and an AttrVal obect
     * 
     * @author Damiano Falcioni
     */
    public static class IdAttrVal{
        public String id = null;
        public AttrVal val = null;
        /**
         * Create a new Pair of id and AttrVal
         * @param id The id of the Pair
         * @param val The AttrVal of the Pair
         */
        public IdAttrVal(String id, AttrVal val){
            this.id = id;
            this.val = val;
        }
    }
    
    protected BpLib bpLib = null;
    protected WeLib weLib = null;
    protected BpLibrary bpLibrary = null;
    protected WeLibrary weLibrary = null;
    
    private Library library = null;
    
    private Identifier id = null;
    private Identifier superLibid = null;
    
    private boolean isRedefined = false;
    private boolean isDynamic = true;
    
    private static boolean postponedAddDefault = false;
    private static boolean mergeAddDefault = true;
    
    private ArrayList<ADOClass> toAddPostponedClassList = new ArrayList<ADOClass>();
    private ArrayList<ADORelation> toAddPostponedRelationList = new ArrayList<ADORelation>();
    
    protected ADOLibrary(BpLib bpLib){
        this.id = bpLib.getId();
        this.superLibid = null;
        this.isRedefined = true;
        this.isDynamic = true;
        
        this.bpLib = bpLib;
        this.library = bpLib.library;
    }
    
    protected ADOLibrary(WeLib weLib){
        this.id = weLib.getId();
        this.superLibid = null;
        this.isRedefined = true;
        this.isDynamic = false;
        this.weLib = weLib;
        this.library = weLib.library;
    }
    
    protected ADOLibrary(BpLibrary bpLibrary){
        this.id = bpLibrary.getId();
        this.superLibid = bpLibrary.getSuperLibId();
        this.isRedefined = false;
        this.isDynamic = true;
        this.bpLibrary = bpLibrary;
        this.library = bpLibrary.library;
    }
    
    protected ADOLibrary(WeLibrary weLibrary){
        this.id = weLibrary.getId();
        this.superLibid = weLibrary.getSuperLibId();
        this.isRedefined = false;
        this.isDynamic = false;
        this.weLibrary = weLibrary;
        this.library = weLibrary.library;
    }
    
    /**
     * Create a new ADOxx Library
     * @param isDynamic Indicate if the library is dynamic or not
     * @param idLibrary The id of the library
     * @throws Exception in case of error
     */
    public ADOLibrary(boolean isDynamic, String idLibrary) throws Exception {
        this.id = new Identifier(idLibrary);
        this.superLibid = null;
        this.isRedefined = true;
        this.isDynamic = isDynamic;
        this.library = new Library(isDynamic);
        
        if(isDynamic)
            bpLib = new BpLib(this.id, library);
        else
            weLib = new WeLib(this.id, library);
        
        if(isDynamic)
            ADOInternalMetaModelHelper.createDefaultADOxxDynamicClassesAndRelations(this);
        else
            ADOInternalMetaModelHelper.createDefaultADOxxStaticClassesAndRelations(this);
    }
    
    /**
     * Create a new ADOxx Library extending a previous one
     * @param isDynamic Indicate if the library is dynamic or not
     * @param idLibrary The id of the library
     * @param idSuperLibrary The id of the original library to extend
     * @throws Exception in case of error
     */
    public ADOLibrary(boolean isDynamic, String idLibrary, String idSuperLibrary) throws Exception {
        this.id = new Identifier(idLibrary);
        this.superLibid = new Identifier(idSuperLibrary);
        this.isRedefined = false;
        this.isDynamic = isDynamic;
        this.library = new Library(isDynamic);
        
        if(isDynamic)
            bpLibrary = new BpLibrary(new BpLibraryDefinition(this.id, this.superLibid), library);
        else
            weLibrary = new WeLibrary(new WeLibraryDefinition(this.id, this.superLibid), library);
        
        if(isDynamic)
            ADOInternalMetaModelHelper.createDefaultADOxxDynamicClassesAndRelations(this);
        else
            ADOInternalMetaModelHelper.createDefaultADOxxStaticClassesAndRelations(this);
    }
    
    /**
     * Add a class to the library. If a class definition with the same id is already present, an exception raise. Depending on the value of the static variable "mergeAddDefault" the added class is merged or not to a previously existing class with the same id. Depending on the value of the static variable "postponedAddDefault" the added class is added in a queue of cumulative additions or not
     * @param classToAdd The class to add
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addClass(ADOClass classToAdd) throws Exception{
        return addClass(ADOLibrary.mergeAddDefault, classToAdd);
    }
    
    /**
     * Add a class to the library. If a class definition with the same id is already present, an exception raise. Depending on the value of the static variable "mergeAddDefault" the added class is merged or not to a previously existing class with the same id
     * @param classToAdd The class to add
     * @param postponedAdd If true the class is put in a queue and added to the library only when the "finalizePostponedAdd" method is called
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addClass(ADOClass classToAdd, boolean postponedAdd) throws Exception{
        return addClass(ADOLibrary.mergeAddDefault, classToAdd, postponedAdd);
    }
    
    /**
     * Add a class to the library. If a class definition with the same id is already present, an exception raise. Depending on the value of the static variable "postponedAddDefault" the added class is added in a queue of cumulative additions or not
     * @param mergeIfAlreadyDefined If true the class is merged with a previous with the same id when available
     * @param classToAdd The class to add
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addClass(boolean mergeIfAlreadyDefined, ADOClass classToAdd) throws Exception{
        return addClass(mergeIfAlreadyDefined, classToAdd, ADOLibrary.postponedAddDefault);
    }
    
    /**
     * Add a class to the library. If a class definition with the same id is already present, an exception raise
     * @param mergeIfAlreadyDefined If true the class is merged with a previous with the same id when available
     * @param classToAdd The class to add
     * @param postponedAdd If true the class is put in a queue and added to the library only when the "finalizePostponedAdd" method is called
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addClass(boolean mergeIfAlreadyDefined, ADOClass classToAdd, boolean postponedAdd) throws Exception{
        /*
         addClass here merge all the redefined classes into the defined one when specified
         */
        if(mergeIfAlreadyDefined && !classToAdd.hasSuperClassId() && !classToAdd.isInternal()){ //if is redefined
            ArrayList<ADOClass> classList = this.getClasses(classToAdd.getId());
            if(postponedAdd) {
                for(ADOClass clazz : this.toAddPostponedClassList)
                    if(clazz.getId().equals(classToAdd.getId()))
                        classList.add(clazz);
            }
            
            if(classList.size()==0) {
                if(postponedAdd)
                    this.toAddPostponedClassList.add(classToAdd);
                else
                    throw new Exception("A Class with id " + classToAdd.getId().toString() + " has never been defined");
            } else {
                ADOClass lastClass = classList.get(classList.size()-1);
                if(lastClass.isInternal()) {
                    if(postponedAdd)
                        this.toAddPostponedClassList.add(classToAdd);
                    else
                        this.library.addClass(classToAdd.adoClass);
                } else
                    lastClass.addAttribute(classToAdd.getAttributes());
            }
        } else {
            if(postponedAdd)
                this.toAddPostponedClassList.add(classToAdd);
            else
                this.library.addClass(classToAdd.adoClass);
        }
        
        return this;
    }
    
    /**
     * Add a list of classes to the library. If a class definition with the same id is already present, an exception raise. Depending on the value of the static variable "mergeAddDefault" the added class is merged or not to a previously existing class with the same id. Depending on the value of the static variable "postponedAddDefault" the added class is added in a queue of cumulative additions or not
     * @param adoClassList The list of classes to add
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addClass(ADOClass[] adoClassList) throws Exception{
        for(ADOClass adoClass:adoClassList)
            addClass(adoClass);
        return this;
    }
    
    /**
     * Add a list of classes to the library. If a class definition with the same id is already present, an exception raise. Depending on the value of the static variable "mergeAddDefault" the added class is merged or not to a previously existing class with the same id. Depending on the value of the static variable "postponedAddDefault" the added class is added in a queue of cumulative additions or not
     * @param adoClassList The list of classes to add
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addClass(ArrayList<ADOClass> adoClassList) throws Exception{
        for(ADOClass adoClass:adoClassList)
            addClass(adoClass);
        return this;
    }
    
    private void finalizePostponedAddClassRec(ADOClass recursiveSuperClass) throws Exception {
        while(this.toAddPostponedClassList.size() != 0) {
            ADOClass toAddClass = (recursiveSuperClass!=null)?recursiveSuperClass:this.toAddPostponedClassList.get(0);
            
            for(ADOClass clazz : this.toAddPostponedClassList)
                if(clazz.getId().equals(toAddClass.getId()) && clazz.hasSuperClassId())
                    toAddClass = clazz;
            
            if(toAddClass.hasSuperClassId()) {
                ADOClass superToAddBefore = null;
                for(ADOClass clazz : this.toAddPostponedClassList)
                    if(clazz.getId().equals(toAddClass.getSuperClassId()))
                        superToAddBefore = clazz;
                if(superToAddBefore != null)
                    finalizePostponedAddClassRec(superToAddBefore);
            }
            
            this.library.addClass(toAddClass.adoClass);
            this.toAddPostponedClassList.remove(toAddClass);
            
            ArrayList<ADOClass> toAddAndRemove = new ArrayList<ADOClass>();
            for(ADOClass clazz : this.toAddPostponedClassList)
                if(clazz.getId().equals(toAddClass.getId()))
                    toAddAndRemove.add(clazz);
            while(toAddAndRemove.size() != 0) {
                this.library.addClass(toAddAndRemove.get(0).adoClass);
                this.toAddPostponedClassList.remove(toAddAndRemove.get(0));
                toAddAndRemove.remove(0);
            }
        }
    }
    
    /**
     * Add a relation to the library. If a relation definition with the same id is already present, an exception raise. Depending on the value of the static variable "mergeAddDefault" the added relation is merged or not to a previously existing relation with the same id. Depending on the value of the static variable "postponedAddDefault" the added relation is added in a queue of cumulative additions or not
     * @param adoRelation The relation to add
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addRelation(ADORelation adoRelation) throws Exception{
        return addRelation(ADOLibrary.mergeAddDefault, adoRelation);
    }
    
    /**
     * Add a relation to the library. If a relation definition with the same id is already present, an exception raise. Depending on the value of the static variable "mergeAddDefault" the added relation is merged or not to a previously existing relation with the same id
     * @param adoRelation The relation to add
     * @param postponedAdd If true the relation is put in a queue and added to the library only when the "finalizePostponedAdd" method is called
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addRelation(ADORelation adoRelation, boolean postponedAdd) throws Exception{
        return addRelation(ADOLibrary.mergeAddDefault, adoRelation, postponedAdd);
    }
    
    /**
     * Add a relation to the library. If a relation definition with the same id is already present, an exception raise. Depending on the value of the static variable "postponedAddDefault" the added relation is added in a queue of cumulative additions or not
     * @param mergeIfAlreadyDefined If true the relation is merged with a previous with the same id when available
     * @param adoRelation The relation to add
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addRelation(boolean mergeIfAlreadyDefined, ADORelation adoRelation) throws Exception{
        return addRelation(mergeIfAlreadyDefined, adoRelation, ADOLibrary.postponedAddDefault);
    }
    
    /**
     * Add a relation to the library. If a relation definition with the same id is already present, an exception raise
     * @param mergeIfAlreadyDefined If true the relation is merged with a previous with the same id when available
     * @param adoRelation The relation to add
     * @param postponedAdd If true the relation is put in a queue and added to the library only when the "finalizePostponedAdd" method is called
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addRelation(boolean mergeIfAlreadyDefined, ADORelation adoRelation, boolean postponedAdd) throws Exception{
        /*
        addRelation here merge all the redefined relations into the defined one
        */
        if(mergeIfAlreadyDefined && !adoRelation.hasFromTo() && !adoRelation.isInternal()){ //if is redefined
            ArrayList<ADORelation> relationList = this.getRelations(adoRelation.getId());
            if(postponedAdd) {
                for(ADORelation relation : this.toAddPostponedRelationList)
                    if(relation.getId().equals(adoRelation.getId()))
                        relationList.add(relation);
            }
            
            if(relationList.size()==0) {
                if(postponedAdd)
                    this.toAddPostponedRelationList.add(adoRelation);
                else
                    throw new Exception("A Relation with id " + adoRelation.getId().toString() + " has never been defined");
            } else {
                ADORelation lastRelation = relationList.get(relationList.size()-1);
                if(lastRelation.isInternal()) {
                    if(postponedAdd)
                        this.toAddPostponedRelationList.add(adoRelation);
                    else
                        this.library.addRelationClass(adoRelation.adoRelation);
                } else
                    lastRelation.addAttribute(adoRelation.getAttributes());
            }
        } else {
            if(postponedAdd)
                this.toAddPostponedRelationList.add(adoRelation);
            else
                this.library.addRelationClass(adoRelation.adoRelation);
        }
        
        return this;
    }
    
    /**
     * Add a list of relations to the library. If a relation definition with the same id is already present, an exception raise. Depending on the value of the static variable "mergeAddDefault" the added relation is merged or not to a previously existing relation with the same id. Depending on the value of the static variable "postponedAddDefault" the added relation is added in a queue of cumulative additions or not
     * @param adoRelationList The list of relations to add
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addRelation(ADORelation[] adoRelationList) throws Exception{
        for(ADORelation adoRelation:adoRelationList)
            addRelation(adoRelation);
        return this;
    }
    
    /**
     * Add a list of relations to the library. If a relation definition with the same id is already present, an exception raise. Depending on the value of the static variable "mergeAddDefault" the added relation is merged or not to a previously existing relation with the same id. Depending on the value of the static variable "postponedAddDefault" the added relation is added in a queue of cumulative additions or not
     * @param adoRelationList The list of relations to add
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addRelation(ArrayList<ADORelation> adoRelationList) throws Exception{
        for(ADORelation adoRelation:adoRelationList)
            addRelation(adoRelation);
        return this;
    }
    
    private void finalizePostponedAddRelation() throws Exception {
        while(this.toAddPostponedRelationList.size() != 0) {
            ADORelation toAddRelation = this.toAddPostponedRelationList.get(0);
            
            for(ADORelation relation : this.toAddPostponedRelationList)
                if(relation.getId().equals(toAddRelation.getId()) && relation.hasFromTo())
                    toAddRelation = relation;

            this.library.addRelationClass(toAddRelation.adoRelation);
            this.toAddPostponedRelationList.remove(toAddRelation);
            
            ArrayList<ADORelation> toAddAndRemove = new ArrayList<ADORelation>();
            for(ADORelation relation : this.toAddPostponedRelationList)
                if(relation.getId().equals(toAddRelation.getId()))
                    toAddAndRemove.add(relation);
            while(toAddAndRemove.size() != 0) {
                this.library.addRelationClass(toAddAndRemove.get(0).adoRelation);
                this.toAddPostponedRelationList.remove(toAddAndRemove.get(0));
                toAddAndRemove.remove(0);
            }
        }
    }
    
    /**
     * Finalise the addition of all the queued Classes and Relations, automatically identifying their dependencies and keeping the right addition order
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary finalizePostponedAdd() throws Exception {
        finalizePostponedAddClassRec(null);
        finalizePostponedAddRelation();
        return this;
    }
    
    /**
     * Get the list of classes defined for this library
     * @return ArrayList&lt;ADOClass&gt; The list of classes defined
     * @throws Exception in case of error
     */
    public ArrayList<ADOClass> getClasses() throws Exception{
        ArrayList<ADOClass> ret = new ArrayList<ADOClass>();
        for(org.adoxx.all.api.objects.Class clazz : this.library.getClasses())
            ret.add(new ADOClass(clazz));
        return ret;
    }
    
    /**
     * Get the list of classes with a specific id defined for this library
     * @param classId The id of the classes to retrieve
     * @return ArrayList&lt;ADOClass&gt; The list of classes defined
     * @throws Exception in case of error
     */
    public ArrayList<ADOClass> getClasses(Identifier classId) throws Exception{
        ArrayList<ADOClass> ret = new ArrayList<ADOClass>();
        for(org.adoxx.all.api.objects.Class clazz : this.library.getClasses(classId))
            ret.add(new ADOClass(clazz));
        return ret;
    }
    
    /**
     * Get the list of classes with a specific id defined for this library
     * @param classId The id of the classes to retrieve
     * @return ArrayList&lt;ADOClass&gt; The list of classes defined
     * @throws Exception in case of error
     */
    public ArrayList<ADOClass> getClasses(String classId) throws Exception{
        ArrayList<ADOClass> ret = new ArrayList<ADOClass>();
        for(org.adoxx.all.api.objects.Class clazz : this.library.getClasses(classId))
            ret.add(new ADOClass(clazz));
        return ret;
    }
    
    /**
     * Get the definition of the class with a specific id
     * @param classId The id of the class to retrieve
     * @return ADOClass The class definition
     * @throws Exception in case of error
     */
    public ADOClass getClassDefinition(Identifier classId) throws Exception{
        return new ADOClass(this.library.getClassDefinition(classId));
    }
    
    /**
     * Get the definition of the class with a specific id
     * @param classId The id of the class to retrieve
     * @return ADOClass The class definition
     * @throws Exception in case of error
     */
    public ADOClass getClassDefinition(String classId) throws Exception{
        return new ADOClass(this.library.getClassDefinition(classId));
    }
    
    /**
     * Get the list of relations defined for this library
     * @return ArrayList&lt;ADORelation&gt; The list of relations defined
     * @throws Exception in case of error
     */
    public ArrayList<ADORelation> getRelations() throws Exception{
        ArrayList<ADORelation> ret = new ArrayList<ADORelation>();
        for(RelationClass relation : this.library.getRelations())
            ret.add(new ADORelation(relation));
        return ret;
    }
    
    /**
     * Get the list of relations with a specific id defined for this library
     * @param relationId The id of the relations to retrieve
     * @return ArrayList&lt;ADORelation&gt; The list of relations defined
     * @throws Exception in case of error
     */
    public ArrayList<ADORelation> getRelations(Identifier relationId) throws Exception{
        ArrayList<ADORelation> ret = new ArrayList<ADORelation>();
        for(RelationClass relation : this.library.getRelations(relationId))
            ret.add(new ADORelation(relation));
        return ret;
    }
    
    /**
     * Get the list of relations with a specific id defined for this library
     * @param relationId The id of the relations to retrieve
     * @return ArrayList&lt;ADORelation&gt; The list of relations defined
     * @throws Exception in case of error
     */
    public ArrayList<ADORelation> getRelations(String relationId) throws Exception{
        ArrayList<ADORelation> ret = new ArrayList<ADORelation>();
        for(RelationClass relation : this.library.getRelations(relationId))
            ret.add(new ADORelation(relation));
        return ret;
    }
    
    /**
     * Get the definition of the relation with a specific id
     * @param relationId The id of the relation to retrieve
     * @return ADORelation The relation definition
     * @throws Exception in case of error
     */
    public ADORelation getRelationDefinition(Identifier relationId) throws Exception{
        return new ADORelation(this.library.getRelationDefinition(relationId));
    }
    
    /**
     * Get the definition of the relation with a specific id
     * @param relationId The id of the relation to retrieve
     * @return ADORelation The relation definition
     * @throws Exception in case of error
     */
    public ADORelation getRelationDefinition(String relationId) throws Exception{
        return new ADORelation(this.library.getRelationDefinition(relationId));
    }

    /**
     * Check if a specific class is present in the library
     * @param classId The id of the class to check
     * @return boolean True or false in case the class is present of not
     */
    public boolean hasClass(Identifier classId){
        return this.library.hasClass(classId);
    }
    
    /**
     * Check if a specific class is present in the library
     * @param classId The id of the class to check
     * @return boolean True or false in case the class is present of not
     */
    public boolean hasClass(String classId){
        return this.library.hasClass(classId);
    }
    
    /**
     * Check if a specific class definition (class with super id) is present in the library
     * @param classId The id of the class to check
     * @return boolean True or false in case the class definition is present of not
     */
    public boolean hasClassDefinition(Identifier classId){
        return this.library.hasClassDefinition(classId);
    }
    
    /**
     * Check if a specific class definition (class with super id) is present in the library
     * @param classId The id of the class to check
     * @return boolean True or false in case the class definition is present of not
     */
    public boolean hasClassDefinition(String classId){
        return this.library.hasClassDefinition(classId);
    }
    
    /**
     * Check if a specific relation is present in the library
     * @param relationId The id of the relation to check
     * @return boolean True or false in case the relation is present of not
     */
    public boolean hasRelation(String relationId){
        return this.library.hasRelation(relationId);
    }
    
    /**
     * Check if a specific relation is present in the library
     * @param relationId The id of the relation to check
     * @return boolean True or false in case the relation is present of not
     */
    public boolean hasRelation(Identifier relationId){
        return this.library.hasRelation(relationId);
    }
    
    /**
     * Check if a specific relation definition (class with classes from/to ids) is present in the library
     * @param relationId The id of the relation to check
     * @return boolean True or false in case the relation definition is present of not
     */
    public boolean hasRelationDefinition(Identifier relationId){
        return this.library.hasRelationDefinition(relationId);
    }
    
    /**
     * Check if a specific relation definition (class with classes from/to ids) is present in the library
     * @param relationId The id of the relation to check
     * @return boolean True or false in case the relation definition is present of not
     */
    public boolean hasRelationDefinition(String relationId){
        return this.library.hasRelationDefinition(relationId);
    }
    
    /**
     * Add an attribute to the library. If an attribute definition with the same id is already present, an exception raise
     * @param id The id of the attribute to create and add
     * @param value The value to associate to the attribute
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addLibraryAttribute(String id, AttrVal value) throws Exception{
        if(bpLib != null)
            bpLib.addInstanceAttributeSetting(new InstanceAttributeSetting(new Identifier(id), value));
        if(weLib != null)
            weLib.addInstanceAttributeSetting(new InstanceAttributeSetting(new Identifier(id), value));
        if(bpLibrary != null)
            bpLibrary.addInstanceAttributeSetting(new InstanceAttributeSetting(new Identifier(id), value));
        if(weLibrary != null)
            weLibrary.addInstanceAttributeSetting(new InstanceAttributeSetting(new Identifier(id), value));
        return this;
    }
    
    /**
     * Add an attribute to the library. If an attribute definition with the same id is already present, an exception raise
     * @param idVal An object containing the pair id, value of an attribute
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addLibraryAttribute(IdAttrVal idVal) throws Exception{
        return addLibraryAttribute(idVal.id, idVal.val);
    }
    
    /**
     * Add a list of attributes to the library. If an attribute definition with the same id is already present, an exception raise
     * @param idValList A list of objects containing the pair id, value of an attribute
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addLibraryAttribute(ArrayList<IdAttrVal> idValList) throws Exception{
        for(IdAttrVal idVal:idValList)
            addLibraryAttribute(idVal);
        return this;
    }
    
    /**
     * Add a list of attributes to the library. If an attribute definition with the same id is already present, an exception raise
     * @param idValList A list of objects containing the pair id, value of an attribute
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addLibraryAttribute(IdAttrVal[] idValList) throws Exception{
        for(IdAttrVal idVal:idValList)
            addLibraryAttribute(idVal);
        return this;
    }
    
    /**
     * Get the library id
     * @return Identifier The Id of this library
     */
    public Identifier getId(){
        return id;
    }
    
    /**
     * Get the super library id. An Exception raise if the super library id has not been defined
     * @return Identifier The Id of this super library
     * @throws Exception in case of error
     */
    public Identifier getSuperLibId() throws Exception{
        if(this.superLibid == null)
            throw new Exception("The Super Library Id is not present for redefined libraries");
        
        return this.superLibid;
    }
    
    /**
     * Check if the library is a new or a redefined library
     * @return boolean True if the library is redefined, false otherwise
     */
    public boolean isRedefined(){
        return isRedefined;
    }
    
    /**
     * Check if the library is dynamic or static
     * @return boolean True if the library is dynamic, false if is static
     */
    public boolean isDynamic(){
        return isDynamic;
    }
    
    /**
     * Check if a specific attribute is present in the library
     * @param attributeId The id of the attribute to check
     * @return boolean True or false in case the attribute is present of not
     * @throws Exception in case of error
     */
    public boolean hasAttribute(String attributeId) throws Exception {
        if(bpLib != null)
            return bpLib.hasAttribute(attributeId);
        if(weLib != null)
            return weLib.hasAttribute(attributeId);
        if(bpLibrary != null)
            return bpLibrary.hasAttribute(attributeId);
        if(weLibrary != null)
            return weLibrary.hasAttribute(attributeId);
        
        throw new Exception("Nothing defined");
    }
    
    /**
     * Find a specific attribute in this library. An exception raise if the attribute is not present
     * @param attributeId The id of the attribute to search
     * @return AttrVal The value of the library attribute
     * @throws Exception in case of error
     */
    public AttrVal findAttributeValue(String attributeId) throws Exception{
        if(bpLib != null)
            return bpLib.findAttributeValue(attributeId);
        if(weLib != null)
            return weLib.findAttributeValue(attributeId);
        if(bpLibrary != null)
            return bpLibrary.findAttributeValue(attributeId);
        if(weLibrary != null)
            return weLibrary.findAttributeValue(attributeId);
        
        throw new Exception("Nothing defined");
    }
    
    /**
     * Add the default ADOxx required attributes to the library. If an attribute definition with the same id is already present, an exception raise
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addADOxxDefaultAttributes() throws Exception{
        this.addLibraryAttribute("Version number", new AttrVal(""));
        this.addLibraryAttribute("Date last changed", new AttrVal(""));
        this.addLibraryAttribute("Last user", new AttrVal(""));
        this.addLibraryAttribute("Keywords", new AttrVal(""));
        this.addLibraryAttribute("Comment", new AttrVal(""));
        this.addLibraryAttribute("Description", new AttrVal(""));
        this.addLibraryAttribute("Modi", new AttrVal(""));
        this.addLibraryAttribute("Page layouts", new AttrVal("LAYOUT \"Full page (without header/footer)\"\nPAGE w:p h:p"));
        this.addLibraryAttribute("Simmapping", new AttrVal("SIMOPTION undefined"));
        this.addLibraryAttribute("Simtext", new AttrVal("SIMTEXT undefined"));
        this.addLibraryAttribute("Queries", new AttrVal(""));
        this.addLibraryAttribute("Input fields", new AttrVal(""));
        this.addLibraryAttribute("AQL commands", new AttrVal(""));
        this.addLibraryAttribute("Result attributes", new AttrVal(""));
        this.addLibraryAttribute("Relation analysis", new AttrVal(""));
        this.addLibraryAttribute("Service", new AttrVal("http://www.adoxx.org\n\nfaq@adoxx.org"));
        this.addLibraryAttribute("User defined", new AttrVal("yes"));
        this.addLibraryAttribute("Library icons", new AttrVal(""));
        this.addLibraryAttribute("Evaluation queries", new AttrVal(""));
        this.addLibraryAttribute("Evaluation input fields", new AttrVal(""));
        this.addLibraryAttribute("Evaluation AQL commands", new AttrVal(""));
        this.addLibraryAttribute("Evaluation result attributes", new AttrVal(""));
        this.addLibraryAttribute("Sim result mapping", new AttrVal(""));
        this.addLibraryAttribute("Numbering", new AttrVal("numeric"));
        this.addLibraryAttribute("Graphical representation", new AttrVal("GRAPHREP\nFILL color:aliceblue\nRECTANGLE x:-.3cm y:-.3cm w:.6cm h:.6cm"));
        this.addLibraryAttribute("Days per year", new AttrVal(170));
        this.addLibraryAttribute("Hours per day", new AttrVal(8));
        this.addLibraryAttribute("CCC mapping", new AttrVal(""));
        this.addLibraryAttribute("CCC default setting", new AttrVal(""));
        this.addLibraryAttribute("Object arrangement", new AttrVal(""));
        this.addLibraryAttribute("External coupling", new AttrVal("ON_EVENT \"AppInitialized\"\n{}"));
        this.addLibraryAttribute("Agent definition", new AttrVal(""));
        this.addLibraryAttribute("Variable check", new AttrVal("off"));
        this.addLibraryAttribute("Configuration of documentation", new AttrVal(""));
        this.addLibraryAttribute("Default settings", new AttrVal("GRID snap:on visible:off w:0.50cm h:0.50cm\nGRADIENT_PRINTING mode:avg-color"));
        this.addLibraryAttribute("Predefined queries", new AttrVal(""));
        this.addLibraryAttribute("Predefined evaluation queries", new AttrVal(""));
        this.addLibraryAttribute("Dynamic evaluation modules", new AttrVal(""));
        this.addLibraryAttribute("Path navigator", new AttrVal(""));
        this.addLibraryAttribute("Versioning format", new AttrVal(""));
        return this;
    }
    
    /**
     * Add the internal ADOxx Metamodel Classes and Relations to the library. This operation is required in order to evaluate the correctness of the generated ALL
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary addADOxxInternalMetaModelClassesAndRelations() throws Exception{
        if(this.isDynamic())
            ADOInternalMetaModelHelper.createDefaultADOxxDynamicClassesAndRelations(this);
        else
            ADOInternalMetaModelHelper.createDefaultADOxxStaticClassesAndRelations(this);
        return this;
    }
    
    /**
     * Set the value of the Modi attribute into the library
     * @param modi The value of the Modi attribute
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary setModi(String modi) throws Exception{
        this.findAttributeValue("Modi").set(modi);
        return this;
    }
    
    /**
     * Set the value of the "External coupling" attribute into the library
     * @param extCoupling The value of the "External coupling" attribute
     * @return ADOLibrary This object
     * @throws Exception in case of error
     */
    public ADOLibrary setExternalCoupling(String extCoupling) throws Exception{
        this.findAttributeValue("External coupling").set(extCoupling);
        return this;
    }
}
