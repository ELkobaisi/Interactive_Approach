package org.adoxx.all.api.objects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.UUID;

import org.adoxx.all.api.library.Library;
import org.adoxx.all.api.objects.definitions.RelationClassDefinition;
import org.adoxx.all.api.objects.redef.RedefInstanceAttribute;
import org.adoxx.all.api.objects.redef.definitions.RedefRelationClassDefinition;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.Val;

public class RelationClass {
    private String uuid = UUID.randomUUID().toString();
    
    public RelationClassDefinition relationClassDefinition = null;
    public RedefRelationClassDefinition redefRelationClassDefinition = null;
    
    public ArrayList<InstanceAttribute> attributeList = new ArrayList<InstanceAttribute>();
    public ArrayList<RedefInstanceAttribute> redefAttributeList = new ArrayList<RedefInstanceAttribute>();
    
    private Library library = null;
    private boolean isInternal = false;
    
    public RelationClass(RelationClassDefinition relationClassDefinition) throws Exception {
        if(relationClassDefinition == null)
            throw new Exception("Not Allowed");
        
        this.relationClassDefinition = relationClassDefinition;
    }
    
    public RelationClass(RedefRelationClassDefinition redefRelationClassDefinition) throws Exception {
        if(redefRelationClassDefinition == null)
            throw new Exception("Not Allowed");
        
        this.redefRelationClassDefinition = redefRelationClassDefinition;
    }
    
    public void addInstanceAttribute(InstanceAttribute attribute) throws Exception{
        if(relationClassDefinition == null || attribute == null)
            throw new Exception("Not Allowed");
        
        if(attributeList.contains(attribute))
            throw new Exception("An Attribute with id " + attribute.getId().toString() + " has been already defined for the Relation Class " + this.getId().toString());

        attributeList.add(attribute);
        
        if(this.library != null)
            checkAttribute(attribute);
    }
    
    public void addInstanceAttribute(RedefInstanceAttribute attribute) throws Exception{
        if(redefRelationClassDefinition == null || attribute == null)
            throw new Exception("Not Allowed");
        
        if(redefAttributeList.contains(attribute))
            throw new Exception("An Attribute with id " + attribute.getId().toString() + " has been already defined for the Relation Class " + this.getId().toString());
        
        redefAttributeList.add(attribute);
        
        if(this.library != null)
            checkAttribute(attribute);
    }
    
    public void chackAllAddedAttributes() throws Exception{
        for(AttributeI attribute: attributeList)
            checkAttribute(attribute);
        for(AttributeI attribute: redefAttributeList)
            checkAttribute(attribute);
    }
    
    private void checkAttribute(AttributeI attribute) throws Exception{
        if(this.library == null)
            throw new Exception("set the library before checking attributes");
        
        if(attribute.getType() != null || attribute.isRecord()){
            RelationClass[] allRe = this.library.getRelations(this.getId());
            for(RelationClass relation : allRe)
                if(relation.hasMultipleAttributeDefinition(attribute.getId()))
                    throw new Exception("Impossible to add the attribute " + attribute.getId().getRaw() + " to the relation " + this.getId().getRaw() + " because it is already defined");
        } else {
            boolean definitionOk = false;
            RelationClass[] allRe = this.library.getRelations(this.getId());
            for(RelationClass relation : allRe)
                if(relation.hasAttributeDefinition(attribute.getId())){
                    definitionOk = true;
                    break;
                }
            if(!definitionOk)
                throw new Exception("Impossible to add the attribute " + attribute.getId().getRaw() + " to the relation " + this.getId().getRaw() + " because it has never been defined");
        }
    }
    
    public boolean checkAttributeDefinitionPresence(String attributeId) throws Exception{
        if(this.library == null)
            throw new Exception("set the library before checking attributes");
        
        boolean definitionOk = false;
        RelationClass[] allRe = this.library.getRelations(this.getId());
        for(RelationClass relation : allRe)
            if(relation.hasAttributeDefinition(attributeId)){
                definitionOk = true;
                break;
            }
        
        return definitionOk;
    }
    
    public AttributeI getGeneralAttributeDefinition(String attributeId) throws Exception{
        if(this.library == null)
            throw new Exception("set the library before checking attributes");
        
        RelationClass[] allRe = this.library.getRelations(this.getId());
        for(RelationClass relation : allRe){
            AttributeI attributeDef = relation.getAttributeDefinition(attributeId);
            if(attributeDef != null)
                return attributeDef;
        }
        
        throw new Exception("Definition for the attrbute " + attributeId + " not found");
    }
    
    public void removeInstanceAttribute(String attributeId) throws Exception{
        removeInstanceAttribute(new Identifier(attributeId));
    }
    public void removeInstanceAttribute(Identifier attributeId){
        boolean definitionRemoved = false;
        
        Iterator<InstanceAttribute> attributeIterator = attributeList.iterator();
        while(attributeIterator.hasNext()){
            InstanceAttribute attribute = attributeIterator.next();
            if(attribute.getId().equals(attributeId)){
                attributeIterator.remove();
                if(attribute.getType()!=null || attribute.isRecord())
                    definitionRemoved = true;
            }
        }
        
        Iterator<RedefInstanceAttribute> redefAttributeIterator = redefAttributeList.iterator();
        while(redefAttributeIterator.hasNext()){
            RedefInstanceAttribute attribute = redefAttributeIterator.next();
            if(attribute.getId().equals(attributeId)){
                redefAttributeIterator.remove();
                if(attribute.getType()!=null || attribute.isRecord())
                    definitionRemoved = true;
            }
        }
        
        if(definitionRemoved){
            boolean foundCurrentRelation = false;
            for(RelationClass relation : this.library.getRelations(this.getId().getRaw())){
                if(relation.uuid.equals(this.uuid)){
                    foundCurrentRelation = true;
                    continue;
                }
                if(foundCurrentRelation)
                    relation.removeInstanceAttribute(attributeId);
            }
        }
    }
    
    public Identifier getId(){
        if(this.relationClassDefinition != null)
            return this.relationClassDefinition.getId();
        else
            return this.redefRelationClassDefinition.getId();
    }
    
    public Identifier getIdFrom() throws Exception{
        if(this.relationClassDefinition != null)
            return this.relationClassDefinition.getIdFrom();
        else
            throw new Exception("The From Id is not present in a redefined Relation Class");
    }
    
    public Identifier getIdTo() throws Exception{
        if(this.relationClassDefinition != null)
            return this.relationClassDefinition.getIdTo();
        else
            throw new Exception("The To Id is not present in a redefined Relation Class");
    }
    
    public Class getFromClassDefinition(){
        if(this.relationClassDefinition == null)
            return null;
        Class ret = null;
        try{
            ret = this.library.getClassDefinition(this.relationClassDefinition.getIdFrom());
        }catch(Exception ex){}
        return ret;
    }
    
    public Class getToClassDefinition(){
        if(this.relationClassDefinition == null)
            return null;
        Class ret = null;
        try{
            ret = this.library.getClassDefinition(this.relationClassDefinition.getIdTo());
        }catch(Exception ex){}
        return ret;
    }
    
    public boolean hasFromTo(){
        return this.relationClassDefinition != null;
    }
    
    public Val findAttributeValue(String attributeId) throws Exception{
        return findAttributeValue(new Identifier(attributeId));
    }
    
    public Val findAttributeValue(Identifier attributeId) throws Exception{
        for(InstanceAttribute attribute:attributeList)
            if(attribute.getId().equals(attributeId))
                return attribute.getValue();
        for(RedefInstanceAttribute attribute:redefAttributeList)
            if(attribute.getId().equals(attributeId))
                return attribute.getValue();
        
        throw new Exception("Impossible to find an attribute with id " + attributeId);
    }
    
    public boolean hasAttribute(String attributeId){
        return hasAttribute(new Identifier(attributeId));
    }
    
    public boolean hasAttribute(Identifier attributeId){
        for(InstanceAttribute attribute:attributeList)
            if(attribute.getId().equals(attributeId))
                return true;
        for(RedefInstanceAttribute attribute:redefAttributeList)
            if(attribute.getId().equals(attributeId))
                return true;
        
        return false;
    }
    
    public boolean hasAttributeDefinition(String attributeId){
        return hasAttributeDefinition(new Identifier(attributeId));
    }
    
    public boolean hasAttributeDefinition(Identifier attributeId){
        for(InstanceAttribute attribute:attributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                return true;
        for(RedefInstanceAttribute attribute:redefAttributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                return true;
        return false;
    }
    
    public AttributeI getAttributeDefinition(String attributeId){
        return getAttributeDefinition(new Identifier(attributeId));
    }
    
    public AttributeI getAttributeDefinition(Identifier attributeId){
        for(InstanceAttribute attribute:attributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                return attribute;
        for(RedefInstanceAttribute attribute:redefAttributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                return attribute;
        return null;
    }
    
    public boolean hasMultipleAttributeDefinition(String attributeId){
        return hasMultipleAttributeDefinition(new Identifier(attributeId));
    }
    
    public boolean hasMultipleAttributeDefinition(Identifier attributeId){
        boolean firstFound = false;
        for(InstanceAttribute attribute:attributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                if(!firstFound)
                    firstFound = true;
                else
                    return true;
        for(RedefInstanceAttribute attribute:redefAttributeList)
            if(attribute.getId().equals(attributeId) && (attribute.getType()!=null || attribute.isRecord()))
                if(!firstFound)
                    firstFound = true;
                else
                    return true;
        return false;
    }
    
    public void setLibrary(Library library){
        this.library = library;
    }
    
    public void setAsInternal(boolean isInternal){
        this.isInternal = isInternal;
    }
    
    public boolean isInternal(){
        return this.isInternal;
    }
    
    @Override
    public int hashCode(){
        if(this.hasFromTo())
            return 1013 *getId().hashCode() ^ 1009 * 2;
        else
            return getId().hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof RelationClass))
            return o==this;
        
        RelationClass other = (RelationClass)o;
        return other.getId().equals(this.getId()) && this.hasFromTo() && other.hasFromTo();
    }
    
    @Override
    public String toString(){
        String ret = "";
        if(relationClassDefinition != null){
            ret += relationClassDefinition.toString();
            for(InstanceAttribute attribute:attributeList)
                ret += attribute.toString();
        } else {
            ret += redefRelationClassDefinition.toString();
            for(RedefInstanceAttribute attribute:redefAttributeList)
                ret += attribute.toString();
        }
        return ret;
    }
}
