package org.adoxx.all.api.library.presetlib.libraries;

import java.util.ArrayList;

import org.adoxx.all.api.library.InstanceAttributeSetting;
import org.adoxx.all.api.library.Library;
import org.adoxx.all.api.library.presetlib.libraries.definitions.BpLibraryDefinition;
import org.adoxx.all.api.primitive.AttrVal;
import org.adoxx.all.api.primitive.Identifier;

public class BpLibrary {

    private BpLibraryDefinition bpLibraryDefinition = null;
    public Library library = null;
    private ArrayList<InstanceAttributeSetting> instanceAttributeSettingList = new ArrayList<InstanceAttributeSetting>();
    
    public BpLibrary(BpLibraryDefinition bpLibraryDefinition, Library library) throws Exception {
        if(bpLibraryDefinition == null || library == null)
            throw new Exception("Not Allowed");
        
        this.bpLibraryDefinition = bpLibraryDefinition;
        this.library = library;
    }

    public void addInstanceAttributeSetting(InstanceAttributeSetting instanceAttributeSetting) throws Exception{
        if(instanceAttributeSetting == null)
            throw new Exception("Not Allowed");
        
        if(instanceAttributeSettingList.contains(instanceAttributeSetting))
            throw new Exception("An Attribute setting with id " + instanceAttributeSetting.getId().toString() + " has been already defined for the library " + this.getId().toString());
        
        instanceAttributeSettingList.add(instanceAttributeSetting);
    }

    public Identifier getId(){
        return this.bpLibraryDefinition.getId();
    }
    
    public Identifier getSuperLibId(){
        return this.bpLibraryDefinition.getSuperLibId();
    }
    
    public boolean hasAttribute(String attributeId) {
        for(InstanceAttributeSetting instanceAttributeSetting:instanceAttributeSettingList)
            if(instanceAttributeSetting.getId().equals(new Identifier(attributeId)))
                return true;
        return false;
    }
    
    public AttrVal findAttributeValue(String attributeId) throws Exception{
        for(InstanceAttributeSetting instanceAttributeSetting:instanceAttributeSettingList)
            if(instanceAttributeSetting.getId().equals(new Identifier(attributeId)))
                return instanceAttributeSetting.getValue();

        throw new Exception("Impossible to find an attribute with id " + attributeId);
    }
    
    @Override
    public String toString(){
        String ret = bpLibraryDefinition.toString();
        for(InstanceAttributeSetting instanceAttributeSetting:instanceAttributeSettingList)
            ret += instanceAttributeSetting.toString();
        ret += library.toString();
        return ret;
    }
}
