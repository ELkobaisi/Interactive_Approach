package org.adoxx.all.api.objects;

import org.adoxx.all.api.objects.definitions.FacetDefinition;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.TypeIdentifier;
import org.adoxx.all.api.primitive.Val;

public interface AttributeI {
    public void addFacet(FacetDefinition facet) throws Exception;
    public Val findFacetValue(String facetId) throws Exception;
    public FacetDefinition[] getFacets();
    public Identifier getId();
    public TypeIdentifier getType();
    public Val getValue();
    public boolean isRecord();
    public boolean isClassAttribute();
}
