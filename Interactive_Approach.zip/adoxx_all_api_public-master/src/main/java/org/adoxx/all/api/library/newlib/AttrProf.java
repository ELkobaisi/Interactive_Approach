package org.adoxx.all.api.library.newlib;

import java.util.ArrayList;

import org.adoxx.all.api.objects.Attribute;
import org.adoxx.all.api.primitive.Identifier;
import org.adoxx.all.api.primitive.Val;

public class AttrProf {

    private Identifier identifier = null;
    private Identifier superClassIdentifier = null;
    private ArrayList<Attribute> attributeList = new ArrayList<Attribute>();
    
    public static AttrProf factory(Identifier identifier, Identifier superClassIdentifier) throws Exception {
        if(superClassIdentifier != null)
            return new AttrProf(identifier, superClassIdentifier);
        else
            return new AttrProf(identifier);
    }
    
    public AttrProf(Identifier identifier, Identifier superClassIdentifier) throws Exception {
        if(identifier == null || superClassIdentifier == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.superClassIdentifier = superClassIdentifier;
    }
    
    public AttrProf(Identifier identifier) throws Exception {
        if(identifier == null)
            throw new Exception("Not Allowed");
        
        this.identifier = identifier;
        this.superClassIdentifier = new Identifier("AttributeProfileClass");
    }

    public void addAttribute(Attribute attribute) throws Exception{
        if(attribute == null)
            throw new Exception("Not Allowed");
        
        if(attributeList.contains(attribute))
            throw new Exception("An Attribute with id " + attribute.getId().toString() + " has been already defined for the Attribute Profile Class " + this.getId().toString());
        
        attributeList.add(attribute);
    }
    
    public Identifier getId(){
        return identifier;
    }
    
    public Identifier getSuperClassId(){
        return superClassIdentifier;
    }
    
    public Val findAttributeValue(String attributeId) throws Exception{
        for(Attribute attribute:attributeList)
            if(attribute.getId().equals(new Identifier(attributeId)))
                return attribute.getValue();

        throw new Exception("Impossible to find an attribute with id " + attributeId);
    }
    
    @Override
    public int hashCode(){
        return getId().hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof AttrProf))
            return o==this;
        return ((AttrProf)o).getId().equals(this.getId());
    }
    
    @Override
    public String toString(){
        String ret = "ATTRIBUTEPROFILECLASS " + identifier.toString() + " : " + superClassIdentifier.toString() + "\n\n";
        for(Attribute attribute:attributeList)
            ret += attribute.toString();
        return ret;
    }
}
