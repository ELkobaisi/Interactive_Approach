package org.adoxx.all.api;

public class Version {
    
    public static final String defaultVersion = "5.1";
    private String version = null;
    
    public Version(String version) throws Exception{
        if(version == null)
            throw new Exception("Not Allowed");
        
        this.version = version;
    }
    
    public Version(){
        this.version = defaultVersion;
    }
    
    public void set(String version){
        this.version = version;
    }
    
    @Override
    public int hashCode(){
        return version.hashCode();
    }
    
    @Override
    public boolean equals(Object o){
        if(!(o instanceof Version))
            return o==this;
        return ((Version)o).toString().equals(this.toString());
    }
    
    @Override
    public String toString(){ 
        return "VERSION <"+version+">\n\n";
    }
}
