package org.adoxx.ado;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import org.adoxx.utils.Utils;
import org.w3c.dom.Document;

/**
 * <h1>ADOUtils</h1>
 * Contain some utilities methods for the ADOxx platform
 * 
 * @author Damiano Falcioni
 */
public class ADOUtils {

    /**
     * Convert a string in ALL format to the ABL encoded byte array using the internal algorithm.
     * The method wrap through Java refactoring the private function that provide the functionality
     * @param allModel The ALL library to convert
     * @return byte[] The ALL encoded in the ABL format 
     * @throws Exception in case of error
     */
    public static byte[] convertALL2ABL(String allModel) throws Exception{
        try {
            Class<?> c = Class.forName("org.adoxx.ado.secret.ADOUtilsPrivate");
            java.lang.reflect.Method m = c.getDeclaredMethod("convertALL2ABL", new Class[]{allModel.getClass()});
            return (byte[]) m.invoke(null, new Object[]{allModel});
            //return org.adoxx.ado.secret.ADOUtilsPrivate.convertALL2ABL(allModel);
        } catch(ClassNotFoundException e) {
            throw new Exception("This feature is not publicly available");
        } catch(NoClassDefFoundError e) {
            throw new Exception("This feature is not publicly available");
        }
    }
    
    /**
     * Convert the encoded ABL in the corresponding ALL string format using the internal algorithm.
     * The method wrap through Java refactoring the private function that provide the functionality
     * @param abl The ABL encoded library to convert
     * @return String The decoded ALL library 
     * @throws Exception in case of error
     */
    public static String convertABL2ALL(byte[] abl) throws Exception{
        try {
            Class<?> c = Class.forName("org.adoxx.ado.secret.ADOUtilsPrivate");
            java.lang.reflect.Method m = c.getDeclaredMethod("convertABL2ALL", new Class[]{abl.getClass()});
            return (String) m.invoke(null, new Object[]{abl});
            //return org.adoxx.ado.secret.ADOUtilsPrivate.convertABL2ALL(abl);
        } catch(ClassNotFoundException e) {
            throw new Exception("This feature is not publicly available");
        } catch(NoClassDefFoundError e) {
            throw new Exception("This feature is not publicly available");
        }
    }
    
    /**
     * Generate the ADOxx default standard user name from the user e-mail
     * The method wrap through Java refactoring the private function that provide the functionality
     * @param eMail The mail of the customer
     * @return String The customer name to be used for the license generation 
     * @throws Exception in case of error
     */
    public static String generateLicenseCustomerName(String eMail) throws Exception{
        try {
            Class<?> c = Class.forName("org.adoxx.ado.secret.ADOUtilsPrivate");
            java.lang.reflect.Method m = c.getDeclaredMethod("generateLicenseCustomerName", new Class[]{eMail.getClass()});
            return (String) m.invoke(null, new Object[]{eMail});
            //return org.adoxx.ado.secret.ADOUtilsPrivate.generateLicenseCustomerName(eMail);
        } catch(ClassNotFoundException e) {
            throw new Exception("This feature is not publicly available");
        } catch(NoClassDefFoundError e) {
            throw new Exception("This feature is not publicly available");
        }
    }
    
    /**
     * Generate the ADOxx license key for the provided customer name using the standard ADOxx parameters
     * The method wrap through Java refactoring the private function that provide the functionality
     * @param customerName The customer name used to generate the license
     * @return String The customer license generated 
     * @throws Exception in case of error
     */
    public static String generateLicenseKey(String customerName) throws Exception{
        try {
            Class<?> c = Class.forName("org.adoxx.ado.secret.ADOUtilsPrivate");
            java.lang.reflect.Method m = c.getDeclaredMethod("generateLicenseKey", new Class[]{customerName.getClass()});
            return (String) m.invoke(null, new Object[]{customerName});
            //return org.adoxx.ado.secret.ADOUtilsPrivate.generateLicenseKey(customerName);
        } catch(ClassNotFoundException e) {
            throw new Exception("This feature is not publicly available");
        } catch(NoClassDefFoundError e) {
            throw new Exception("This feature is not publicly available");
        }
    }
    
    /**
     * Generate the ADOxx license key for the provided customer name using the provided parameters
     * The method wrap through Java refactoring the private function that provide the functionality
     * @param customerName The customer name used to generate the license
     * @param numUsers The number of users that can connect in parallel the the ADOxx database
     * @param isExtended Specify if an extended license key have to be generated
     * @param acquisition_tables Specify if the license enable acquisition tables
     * @param attribute_profile_management Specify if the license enable the attribute profile management
     * @param queries Specify if the license enable the queries in ADOxx
     * @param predefined_queries Specify if the license enable the predefined queries
     * @param relation_tables Specify if the license enable relation tables
     * @param analytical_evaluation Specify if the license enable analytical evaluation
     * @param path_analysis Specify if the license enable the path analysis algorithm
     * @param capacity_analysis Specify if the license enable the capacity analysis algorithm
     * @param workload_analysis_steady_state Specify if the license enable the workload analysis steady state algorithm
     * @param workload_analysis_fixed_time_period Specify if the license enable the workload analysis fixed time period algorithm
     * @param agents Specify if the license enable the usage of agents during the simulation
     * @param flowmark_audit_trial_evaluation Specify if the license enable the flowmark audit trial evaluation
     * @param result_evaluation Specify if the license enable the result evaluation
     * @param evaluation_queries Specify if the license enable the evaluation queries
     * @param adl_import_export Specify if the license enable the ADL import and export
     * @param xml_import_export Specify if the license enable the XML import and export
     * @param documentation Specify if the license enable the documentation generation
     * @param case_4_0_link Specify if the license enable the case 4.0 link
     * @param objectif_link Specify if the license enable the objectif links
     * @param cost_cutting_component Specify if the license enable the cost cutting component
     * @param dynamic_evaluation_modules Specify if the license enable the dynamic evaluation modules
     * @param class_hierarchy_management Specify if the license enable the class hierarchy management
     * @param test_version Specify if the license enable the test version
     * @param no_additional_databases Specify if the license allow additional databases or not
     * @param allow_base_language_only Specify if the license allow more than one language or only the base one
     * @param named_use_licence Specify if the license allow named use licence
     * @param standalone_version Specify if the license enable standalone mode
     * @return String The customer license generated 
     * @throws Exception in case of error
     */
    public static String generateLicenseKey(String customerName, int numUsers, boolean isExtended, boolean acquisition_tables, boolean attribute_profile_management, boolean queries, boolean predefined_queries, boolean relation_tables, boolean analytical_evaluation, boolean path_analysis, boolean capacity_analysis, boolean workload_analysis_steady_state, boolean workload_analysis_fixed_time_period, boolean agents, boolean flowmark_audit_trial_evaluation, boolean result_evaluation, boolean evaluation_queries, boolean adl_import_export, boolean xml_import_export, boolean documentation, boolean case_4_0_link, boolean objectif_link, boolean cost_cutting_component, boolean dynamic_evaluation_modules, boolean class_hierarchy_management, boolean test_version, boolean no_additional_databases, boolean allow_base_language_only, boolean named_use_licence, boolean standalone_version) throws Exception{
        try {
            Class<?> c = Class.forName("org.adoxx.ado.secret.ADOUtilsPrivate");
            java.lang.reflect.Method m = c.getDeclaredMethod("generateLicenseKey", new Class[]{customerName.getClass(), int.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class, boolean.class});
            return (String) m.invoke(null, new Object[]{customerName, numUsers, isExtended, acquisition_tables, attribute_profile_management, queries, predefined_queries, relation_tables, analytical_evaluation, path_analysis, capacity_analysis, workload_analysis_steady_state, workload_analysis_fixed_time_period, agents, flowmark_audit_trial_evaluation, result_evaluation, evaluation_queries, adl_import_export, xml_import_export, documentation, case_4_0_link, objectif_link, cost_cutting_component, dynamic_evaluation_modules, class_hierarchy_management, test_version, no_additional_databases, allow_base_language_only, named_use_licence, standalone_version});
            //return org.adoxx.ado.secret.ADOUtilsPrivate.generateLicenseKey(customerName, numUsers, isExtended, acquisition_tables, attribute_profile_management, queries, predefined_queries, relation_tables, analytical_evaluation, path_analysis, capacity_analysis, workload_analysis_steady_state, workload_analysis_fixed_time_period, agents, flowmark_audit_trial_evaluation, result_evaluation, evaluation_queries, adl_import_export, xml_import_export, documentation, case_4_0_link, objectif_link, cost_cutting_component, dynamic_evaluation_modules, class_hierarchy_management, test_version, no_additional_databases, allow_base_language_only, named_use_licence, standalone_version);
        } catch(ClassNotFoundException e) {
            throw new Exception("This feature is not publicly available");
        } catch(NoClassDefFoundError e) {
            throw new Exception("This feature is not publicly available");
        }
    }
    
    /**
     * Convert a string in ALL format to the ABL encoded byte array using the online web service and save it in a file
     * @param allModel The ALL library to convert
     * @param name The ALL library name
     * @param outputFile The file where to save the generated ABL
     * @throws Exception in case of error
     */
    public static void callALL2ABLService(String allModel, String name, String outputFile) throws Exception{
        byte[] ablModel = callALL2ABLService(allModel, name);
        Utils.writeFile(ablModel, outputFile, false);
    }
    
    /**
     * Convert a string in ALL format to the ABL encoded byte array using the online web service
     * @param allModel The ALL library to convert
     * @param name The ALL library name
     * @return byte[] The ALL encoded in the ABL format 
     * @throws Exception in case of error
     */
    public static byte[] callALL2ABLService(String allModel, String name) throws Exception{
        String allModelB64 = Utils.base64Encode(allModel.getBytes("UTF-8"));
        
        String url = "https://www.adoxx.org/ALL2ABL/services/ALL2ABLWebServicePort";
        String soapAction = "urn:ConvertALL2ABL";
        String envelope = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://webservice.service.all2abl.adoxx.org/\"><soapenv:Header/><soapenv:Body><web:convertALL2ABL><fileDescription>" + name + "</fileDescription><version>1</version><ALLFile>" + allModelB64  + "</ALLFile><ALLFileName>" + name + "</ALLFileName></web:convertALL2ABL></soapenv:Body></soapenv:Envelope>";
        
        ArrayList<String[]> htmlHeaderList = new ArrayList<String[]>();
        htmlHeaderList.add(new String[]{"Content-Type", "text/xml; charset=UTF-8"});
        htmlHeaderList.add(new String[]{"SOAPAction", soapAction});
        byte[] ret = Utils.sendHTTPPOST(url, envelope, htmlHeaderList, true, true);
        String responseEvelope = new String(ret, "UTF-8");
        
        if(!responseEvelope.contains("<return>"))
            throw new Exception("Error calling ALL2ABL Service:\n"+responseEvelope);
        
        String ablModelB64 = responseEvelope.substring(responseEvelope.indexOf("<return>")+"<return>".length(), responseEvelope.indexOf("</return>"));
        byte[] ablModel = Utils.base64Decode(ablModelB64);
        return ablModel;
    }
    
    /**
     * Create an ADOxx Database from the provided ABL file and execute the ADOxx modelling toolkit with this Database giving the possibility to check if the ABL is correctly working
     * @param ablFilePath The ABL library file path to use
     * @param adoxxDBName The name of the ADOxx Database to create. In case an existing database is selected it will be dropped before
     * @param adoxxLicenseKey A valid license key required to create the ADOxx database (like in the ADOxx installation process)
     * @throws Exception in case of error
     */
    public static void callABL2DBScript(String ablFilePath, String adoxxDBName, String adoxxLicenseKey) throws Exception{
        callABL2DBScript(ablFilePath, adoxxDBName, adoxxLicenseKey, null, null, null, null, null);
    }
    
    /**
     * Create an ADOxx Database from the provided ABL file and execute the ADOxx modelling toolkit with this Database giving the possibility to check if the ABL is correctly working
     * @param ablFilePath The ABL library file path to use
     * @param adoxxDBName The name of the ADOxx Database to create. In case an existing database is selected it will be dropped before
     * @param adoxxLicenseKey A valid license key required to create the ADOxx database (like in the ADOxx installation process)
     * @param adoxxLicenseIni (only for advanced users) replace the content of the license ini file 
     * @param adoxxInstallationPath The personalised ADOxx installation folder. When null or empty the default one will be used (%ProgramFiles(x86)%/BOC/ADOxx15_EN_SA)
     * @param sqlInstance The SQL Server instance to use. When null or empty the default one will be used (.\ADOXX15EN)
     * @param sqlSAUser The SQL SA username. When null or empty the default one will be used (sa)
     * @param sqlSAPassword The SQL password related to the SA username. When null or empty the default one will be used (12+*ADOxx*+34)
     * @throws Exception in case of error
     */
    public static void callABL2DBScript(String ablFilePath, String adoxxDBName, String adoxxLicenseKey, String adoxxLicenseIni, String adoxxInstallationPath, String sqlInstance, String sqlSAUser, String sqlSAPassword) throws Exception{
        if(!System.getProperty("os.name").toLowerCase().contains("windows"))
            throw new Exception("This function can be used only on a Windows OS");
        if(ablFilePath == null || ablFilePath.trim().isEmpty())
            throw new Exception("ablFilePath can not be empty");
        if(adoxxDBName == null || adoxxDBName.trim().isEmpty())
            throw new Exception("adoxxDBName can not be empty");
        
        if(adoxxLicenseIni == null || adoxxLicenseIni.trim().isEmpty())
            adoxxLicenseIni = "";
        if(adoxxInstallationPath == null || adoxxInstallationPath.trim().isEmpty())
            if(System.getenv("ProgramFiles(x86)") != null)
                adoxxInstallationPath = System.getenv("ProgramFiles(x86)") + "\\BOC\\ADOxx15_EN_SA";
            else
                adoxxInstallationPath = System.getenv("ProgramFiles") + "\\BOC\\ADOxx15_EN_SA";
        if(sqlInstance == null || sqlInstance.trim().isEmpty())
            sqlInstance = ".\\ADOXX15EN";
        if(sqlSAUser == null || sqlSAUser.trim().isEmpty())
            sqlSAUser = "sa";
        if(sqlSAPassword == null || sqlSAPassword.trim().isEmpty())
            sqlSAPassword = "12+*ADOxx*+34";
        
        String scriptTmpPath = System.getProperty("java.io.tmpdir")+"/ABL2DB.bat";
        String script = new String(Utils.toByteArray(ADOUtils.class.getResourceAsStream("_ABL2DB.bat")), "UTF-8");
        script = script.replace("%ADO_DBNAME%", adoxxDBName)
                .replace("%ADO_LICENSEKEY%", adoxxLicenseKey)
                .replace("%ADO_INILICENSEFILE%", adoxxLicenseIni)
                .replace("%ADO_ADOXXPATH%", adoxxInstallationPath)
                .replace("%ADO_SQLINSTANCE%", sqlInstance)
                .replace("%ADO_SQLSAUSER%", sqlSAUser)
                .replace("%ADO_SQLSAPASSWORD%", sqlSAPassword);
        
        Utils.writeFile(script.getBytes("UTF-8"), scriptTmpPath, false);
        
        final Process proc = Runtime.getRuntime().exec(scriptTmpPath+" \"" + ablFilePath+"\"");
        proc.waitFor();
    }
    
    /**
     * Convert an SVG image to the GraphRep format
     * @param svgPath Path of the SVG to convert
     * @return The string representation of the GraphRep
     * @throws Exception in case of error
     */
    public static String callSVG2GRAPHREPTransformation(String svgPath) throws Exception {
        byte[] svgB = svgPath.startsWith("http")?Utils.sendHTTP(svgPath, "GET", null, null, true, true):Utils.readFile(svgPath);
        int xsetoff = 0;
        int ysetoff = 0;
        String svg = new String(svgB, "UTF-8");
        svg = svg.replaceAll("<!--[\\s\\S]*?-->", "").replaceAll("<!DOCTYPE[\\s\\S]*?>", "").replaceAll("<\\?xml[\\s\\S]*?>", "");
        Document svgXml = Utils.getXmlDocFromString(svg);
        String width = svgXml.getDocumentElement().getAttribute("width").replace("px", "");
        String height = svgXml.getDocumentElement().getAttribute("height").replace("px", "");
        String viewBox = svgXml.getDocumentElement().getAttribute("viewBox");
        if(width.contains("%") || height.contains("%")) throw new Exception("The width and height svg attributes cannot be percentages. Current: width: "+width+", height: "+height);
        if(!viewBox.isEmpty()) {
           String[] viewBoxArray = viewBox.split(viewBox.contains(" ")?" ":",");
           if(!width.equals(viewBoxArray[2])) throw new Exception("The width in the viewBox attribute must be equal to the svg width attribute. Current: viewBox width: "+viewBoxArray[2]+", svg width: "+width);
           if(!height.equals(viewBoxArray[3])) throw new Exception("The height in the viewBox attribute must be equal to the svg height attribute. Current: viewBox height: "+viewBoxArray[3]+", svg height: "+height);
           xsetoff = Integer.parseInt(viewBoxArray[0]);
           ysetoff = Integer.parseInt(viewBoxArray[1]);
        }
        //centering the x,y for adoxx
        xsetoff += Math.round(Integer.parseInt(width) / 2);
        ysetoff += Math.round(Integer.parseInt(height) / 2);
        
        //TODO: search for all image links and import in DB
        
        String xsl = new String(Utils.toByteArray(ADOUtils.class.getResourceAsStream("SVG2GRAPHREP.xsl")), "UTF-8");
        xsl = xsl.replace("%xsetoff%", ""+xsetoff).replace("%ysetoff%", ""+ysetoff);
        
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Utils.executeXSL(new ByteArrayInputStream(svg.getBytes("UTF-8")), new ByteArrayInputStream(xsl.getBytes("UTF-8")), out, null);
        return out.toString("UTF-8");
    }
    
    /*
    public static void main(String[] args) {
        try {
            System.out.println(callSVG2GRAPHREPTransformation("C:\\Users\\dfalcioni.BOCGroup\\Desktop\\test.svg"));
        } catch(Exception ex) {ex.printStackTrace();}
    }
    */
}
