package org.adoxx.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.XMLConstants;
import javax.xml.bind.DatatypeConverter;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.URIResolver;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Utils {
	
	public static byte[] sendHTTPPOST(String url, String dataToSend, ArrayList<String[]> htmlHeaderList, boolean ignoreSSLSelfSigned, boolean ignoreSSLWrongCN) throws Exception{
		return sendHTTP(url, "POST", dataToSend, htmlHeaderList, ignoreSSLSelfSigned, ignoreSSLWrongCN);
	}
	
	public static byte[] sendHTTPGET(String url, ArrayList<String[]> htmlHeaderList, boolean ignoreSSLSelfSigned, boolean ignoreSSLWrongCN) throws Exception{
		return sendHTTP(url, "GET", null, htmlHeaderList, ignoreSSLSelfSigned, ignoreSSLWrongCN);
	}
	
	public static byte[] sendHTTP(String url, String mode, String dataToSend, ArrayList<String[]> htmlHeaderList, boolean ignoreSSLSelfSigned, boolean ignoreSSLWrongCN) throws Exception{
		
		System.setProperty("java.net.useSystemProxies", "true");
		
		if(ignoreSSLSelfSigned){
			TrustManager[] trustAllCerts = new TrustManager[]{
				    new X509TrustManager() {
				        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				            return null;
				        }
				        public void checkClientTrusted(
				            java.security.cert.X509Certificate[] certs, String authType) {
				        }
				        public void checkServerTrusted(
				            java.security.cert.X509Certificate[] certs, String authType) {
				        }
				    }
				};
			SSLContext sc = SSLContext.getInstance("SSL");
		    sc.init(null, trustAllCerts, new java.security.SecureRandom());
		    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		}
		if(ignoreSSLWrongCN){
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				public boolean verify(String hostname, javax.net.ssl.SSLSession session) {
					return true;
				}
			};
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		}
		
		HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
		
		if(htmlHeaderList != null)
			for(String[] htmlHeader:htmlHeaderList)
				if(htmlHeader.length==2)
					connection.setRequestProperty(htmlHeader[0], htmlHeader[1]);

		if(mode.equals("POST") && dataToSend != null){
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Length", "" + Integer.toString(dataToSend.getBytes("UTF-8").length));
			
			DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
			wr.write(dataToSend.getBytes("UTF-8"));
			wr.flush();
			wr.close();
		}
		
		byte[] output = new byte[0];
		if(connection.getResponseCode() >= 400)
			output = toByteArray(connection.getErrorStream());
		else
			output = toByteArray(connection.getInputStream());

		connection.disconnect();
		
		return output;
	}
	
	private static void copyInputStreamToOutputStream(InputStream input, OutputStream output) throws Exception{
        int n = 0;
        int DEFAULT_BUFFER_SIZE = 1024 * 1024 * 10;
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        while (-1 != (n = input.read(buffer)))
            output.write(buffer, 0, n);
    }
    
	public static void inheritIO(final InputStream src, final PrintStream dest) {
        new Thread(new Runnable() {
            public void run() {
                Scanner sc = new Scanner(src);
                while (sc.hasNextLine()) {
                    dest.println(sc.nextLine());
                }
                sc.close();
            }
        }).start();
    }
	
    public static byte[] toByteArray(InputStream is) throws Exception{
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        copyInputStreamToOutputStream(is, out);
        byte[] ret = out.toByteArray();
        out.close();
        out = null;
        return ret;
    }
    
    public static void writeFile(byte[] data, String filePath, boolean appendData) throws Exception{
        FileOutputStream fos = new FileOutputStream(new File(filePath), appendData);
        fos.write(data);
        fos.flush();
        fos.close();
    }
    
    public static byte[] readFile(String file) throws Exception{
        return readFile(new File(file));
    }
    
    public static byte[] readFile(File file) throws Exception{
        RandomAccessFile raf = new RandomAccessFile(file, "r");
        byte[] ret = new byte[(int)raf.length()];
        raf.read(ret);
        raf.close();
        return ret;
    }
    
    public static String extractFileName(String filePath){
        String ret = new File(filePath).getName();
        if(ret.contains("."))
            return ret.substring(0, ret.lastIndexOf('.'));
        else
            return ret;
    }
    
    public static byte[] base64Decode(String encodedData) {
        return DatatypeConverter.parseBase64Binary(encodedData);
    }
    
    public static String base64Encode(byte[] dataToEncode) {
        return DatatypeConverter.printBase64Binary(dataToEncode);
    }
    
    public static String base64EncodeNoPadding(byte[] dataToEncode) {
        return DatatypeConverter.printBase64Binary(dataToEncode).replace("=", "");
    }
    
    public static String convertoMillisecondsToStringDateTime(long totalMilliseconds){
        //yy:ddd:hh:mm:ss
        String ret = "";
        ret += String.format("%02d", (TimeUnit.MILLISECONDS.toDays(totalMilliseconds)/365));
        ret += ":" + String.format("%03d", (TimeUnit.MILLISECONDS.toDays(totalMilliseconds)%365));
        ret += ":" + String.format("%02d", (TimeUnit.MILLISECONDS.toHours(totalMilliseconds)%24));
        ret += ":" + String.format("%02d", (TimeUnit.MILLISECONDS.toMinutes(totalMilliseconds)%60));
        ret += ":" + String.format("%02d", (TimeUnit.MILLISECONDS.toSeconds(totalMilliseconds)%60));
        return ret;
    }
    
    public static Document getXmlDocFromString(String xml) throws Exception{
        return getXmlDocFromIS(new ByteArrayInputStream(xml.getBytes("UTF-8")));
    }
    
    public static Document getXmlDocFromIS(InputStream is) throws Exception{
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        DocumentBuilder builder = dbf.newDocumentBuilder();
        builder.setEntityResolver(new EntityResolver() {
            public InputSource resolveEntity(String publicId, String systemId)
                    throws SAXException, IOException {
                return new InputSource(new StringReader(""));
            }
        });
        return builder.parse(is);
    }
    
    public static String getStringFromXmlDoc(org.w3c.dom.Node node) throws Exception{
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        StringWriter writer = new StringWriter();
        transformer.transform(new DOMSource(node), new StreamResult(writer));
        return writer.getBuffer().toString().replaceAll("\n|\r", "");
    }
    
    public static Document getXmlDocFromURI(String xmlFile) throws Exception{
        if(xmlFile.startsWith("http"))
            return getXmlDocFromIS(new URL(xmlFile).openStream());
        else
            return getXmlDocFromIS(new FileInputStream(new File(xmlFile)));
    }
    
    public static Document createNewDocument() throws Exception{
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        //dbf.setIgnoringElementContentWhitespace(true);
        return dbf.newDocumentBuilder().newDocument();
    }
    
    public static String escapeXPathField(String field) {
        Matcher matcher = Pattern.compile("['\"]").matcher(field);
        StringBuilder buffer = new StringBuilder("concat(");
        int start = 0;
        while (matcher.find()) {
            buffer.append("'").append(field.substring(start, matcher.start())).append("',");
            buffer.append("'".equals(matcher.group()) ? "\"'\"," : "'\"',");
            start = matcher.end();
        }
        if (start == 0)
            return "'" + field + "'";
        return buffer.append("'").append(field.substring(start)).append("'").append(")").toString();
    }
    
    private static XPath xPath = XPathFactory.newInstance().newXPath();
    public static Object execXPath(org.w3c.dom.Node node, String pattern, QName xPathConstantsType) throws Exception{
         return xPath.compile(pattern).evaluate(node, xPathConstantsType);
    }
    
    public static void executeXSL(InputStream xmlInput, InputStream xsl, OutputStream xmlOutput, URIResolver customURIResolver) throws Exception{
        TransformerFactory trasformerFactory = TransformerFactory.newInstance();
        if(customURIResolver!=null)
            trasformerFactory.setURIResolver(customURIResolver);

        Transformer transformer = trasformerFactory.newTransformer(new StreamSource(xsl));
        transformer.transform(new StreamSource(xmlInput), new StreamResult(xmlOutput));
    }
    /* Require SAXON
    public static void executeXSLSaxon(InputStream xmlInput, InputStream xsl, OutputStream xmlOutput, URIResolver customURIResolver) throws Exception{
        
        ExtensionFunctionDefinition randomUUID = new ExtensionFunctionDefinition(){
            @Override
            public SequenceType[] getArgumentTypes() {
                return new SequenceType[0];
            }
            @Override
            public StructuredQName getFunctionQName() {
                return new StructuredQName("", "http://boc-group.com/", "randomUUID");
            }
            @Override
            public SequenceType getResultType(SequenceType[] arg0) {
                return SequenceType.OPTIONAL_STRING;
            }
            @Override
            public ExtensionFunctionCall makeCallExpression() {
                return new ExtensionFunctionCall(){
                    @Override
                    public Sequence call(XPathContext arg0, Sequence[] arg1) throws XPathException {
                        return StringValue.makeStringValue(UUID.randomUUID().toString());
                    }
                };
            }
            public boolean dependsOnFocus(){return true;}
        };

      Processor aProcessor = new Processor(false);
      aProcessor.registerExtensionFunction(randomUUID);
      XsltCompiler aCompiler = aProcessor.newXsltCompiler();
      aCompiler.setCompileWithTracing(true);
      if(customURIResolver!=null)
          aCompiler.setURIResolver(customURIResolver);
      XsltExecutable aXSLTExec =  aCompiler.compile(new StreamSource(xsl));
      XsltTransformer aTransformer = aXSLTExec.load();
      aTransformer.setInitialContextNode(aProcessor.newDocumentBuilder().build(new StreamSource(xmlInput)));
      aTransformer.setDestination(aProcessor.newSerializer(xmlOutput));
      aTransformer.transform();
    }
    */
    public static URIResolver createURIResolver(final Class<?> thisClass, final String hrefRelativeDir){
        return new URIResolver(){
            @Override
            public Source resolve(String href, String base) throws TransformerException {
                try{
                    return new StreamSource(thisClass.getResourceAsStream(hrefRelativeDir+"/" + href));
                }catch(Exception ex){
                    throw new TransformerException("Impossible to find HREF " + href);
                }
            }
        };
    }
    
    public static byte[] cryptDESECB(boolean encrypting, byte[] in, byte[] key) throws Exception{
        if(in == null || in.length % 8 != 0)
            throw new Exception("Input length must be multiple of 8");
        if(key == null || key.length != 8)
            throw new Exception("Key length must be 8 bytes");
        
        byte[] out = new byte[in.length];
        short[] bytebit = {0200, 0100, 040, 020, 010, 04, 02, 01};
        int[] bigbyte = {0x800000, 0x400000, 0x200000, 0x100000, 0x80000, 0x40000, 0x20000, 0x10000, 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400, 0x200, 0x100, 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1};
        byte[] pc1 = {56, 48, 40, 32, 24, 16, 8, 0, 57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35, 62, 54, 46, 38, 30, 22, 14, 6, 61, 53, 45, 37, 29, 21, 13, 5, 60, 52, 44, 36, 28, 20, 12, 4, 27, 19, 11, 3};
        byte[] totrot = {1, 2, 4, 6, 8, 10, 12, 14, 15, 17, 19, 21, 23, 25, 27, 28};
        byte[] pc2 = {13, 16, 10, 23, 0, 4, 2, 27, 14, 5, 20, 9, 22, 18, 11, 3, 25, 7, 15, 6, 26, 19, 12,  1, 40, 51, 30, 36, 46, 54, 29, 39, 50, 44, 32, 47, 43, 48, 38, 55, 33, 52, 45, 41, 49, 35, 28, 31};
        int[] SP1 = {0x01010400, 0x00000000, 0x00010000, 0x01010404, 0x01010004, 0x00010404, 0x00000004, 0x00010000, 0x00000400, 0x01010400, 0x01010404, 0x00000400, 0x01000404, 0x01010004, 0x01000000, 0x00000004, 0x00000404, 0x01000400, 0x01000400, 0x00010400, 0x00010400, 0x01010000, 0x01010000, 0x01000404, 0x00010004, 0x01000004, 0x01000004, 0x00010004, 0x00000000, 0x00000404, 0x00010404, 0x01000000, 0x00010000, 0x01010404, 0x00000004, 0x01010000, 0x01010400, 0x01000000, 0x01000000, 0x00000400, 0x01010004, 0x00010000, 0x00010400, 0x01000004, 0x00000400, 0x00000004, 0x01000404, 0x00010404, 0x01010404, 0x00010004, 0x01010000, 0x01000404, 0x01000004, 0x00000404, 0x00010404, 0x01010400, 0x00000404, 0x01000400, 0x01000400, 0x00000000, 0x00010004, 0x00010400, 0x00000000, 0x01010004};
        int[] SP2 = {0x80108020, 0x80008000, 0x00008000, 0x00108020, 0x00100000, 0x00000020, 0x80100020, 0x80008020, 0x80000020, 0x80108020, 0x80108000, 0x80000000, 0x80008000, 0x00100000, 0x00000020, 0x80100020, 0x00108000, 0x00100020, 0x80008020, 0x00000000, 0x80000000, 0x00008000, 0x00108020, 0x80100000, 0x00100020, 0x80000020, 0x00000000, 0x00108000, 0x00008020, 0x80108000, 0x80100000, 0x00008020, 0x00000000, 0x00108020, 0x80100020, 0x00100000, 0x80008020, 0x80100000, 0x80108000, 0x00008000, 0x80100000, 0x80008000, 0x00000020, 0x80108020, 0x00108020, 0x00000020, 0x00008000, 0x80000000, 0x00008020, 0x80108000, 0x00100000, 0x80000020, 0x00100020, 0x80008020, 0x80000020, 0x00100020, 0x00108000, 0x00000000, 0x80008000, 0x00008020, 0x80000000, 0x80100020, 0x80108020, 0x00108000};
        int[] SP3 = {0x00000208, 0x08020200, 0x00000000, 0x08020008,0x08000200, 0x00000000, 0x00020208, 0x08000200, 0x00020008, 0x08000008, 0x08000008, 0x00020000, 0x08020208, 0x00020008, 0x08020000, 0x00000208, 0x08000000, 0x00000008, 0x08020200, 0x00000200, 0x00020200, 0x08020000, 0x08020008, 0x00020208, 0x08000208, 0x00020200, 0x00020000, 0x08000208, 0x00000008, 0x08020208, 0x00000200, 0x08000000, 0x08020200, 0x08000000, 0x00020008, 0x00000208, 0x00020000, 0x08020200, 0x08000200, 0x00000000, 0x00000200, 0x00020008, 0x08020208, 0x08000200, 0x08000008, 0x00000200, 0x00000000, 0x08020008, 0x08000208, 0x00020000, 0x08000000, 0x08020208, 0x00000008, 0x00020208, 0x00020200, 0x08000008, 0x08020000, 0x08000208, 0x00000208, 0x08020000, 0x00020208, 0x00000008, 0x08020008, 0x00020200};
        int[] SP4 = {0x00802001, 0x00002081, 0x00002081, 0x00000080, 0x00802080, 0x00800081, 0x00800001, 0x00002001, 0x00000000, 0x00802000, 0x00802000, 0x00802081, 0x00000081, 0x00000000, 0x00800080, 0x00800001, 0x00000001, 0x00002000, 0x00800000, 0x00802001, 0x00000080, 0x00800000, 0x00002001, 0x00002080, 0x00800081, 0x00000001, 0x00002080, 0x00800080, 0x00002000, 0x00802080, 0x00802081, 0x00000081, 0x00800080, 0x00800001, 0x00802000, 0x00802081, 0x00000081, 0x00000000, 0x00000000, 0x00802000, 0x00002080, 0x00800080, 0x00800081, 0x00000001, 0x00802001, 0x00002081, 0x00002081, 0x00000080, 0x00802081, 0x00000081, 0x00000001, 0x00002000, 0x00800001, 0x00002001, 0x00802080, 0x00800081, 0x00002001, 0x00002080, 0x00800000, 0x00802001, 0x00000080, 0x00800000, 0x00002000, 0x00802080};
        int[] SP5 = {0x00000100, 0x02080100, 0x02080000, 0x42000100, 0x00080000, 0x00000100, 0x40000000, 0x02080000, 0x40080100, 0x00080000, 0x02000100, 0x40080100, 0x42000100, 0x42080000, 0x00080100, 0x40000000, 0x02000000, 0x40080000, 0x40080000, 0x00000000, 0x40000100, 0x42080100, 0x42080100, 0x02000100, 0x42080000, 0x40000100, 0x00000000, 0x42000000, 0x02080100, 0x02000000, 0x42000000, 0x00080100, 0x00080000, 0x42000100, 0x00000100, 0x02000000, 0x40000000, 0x02080000, 0x42000100, 0x40080100, 0x02000100, 0x40000000, 0x42080000, 0x02080100, 0x40080100, 0x00000100, 0x02000000, 0x42080000, 0x42080100, 0x00080100, 0x42000000, 0x42080100, 0x02080000, 0x00000000, 0x40080000, 0x42000000, 0x00080100, 0x02000100, 0x40000100, 0x00080000, 0x00000000, 0x40080000, 0x02080100, 0x40000100};
        int[] SP6 = {0x20000010, 0x20400000, 0x00004000, 0x20404010, 0x20400000, 0x00000010, 0x20404010, 0x00400000, 0x20004000, 0x00404010, 0x00400000, 0x20000010, 0x00400010, 0x20004000, 0x20000000, 0x00004010, 0x00000000, 0x00400010, 0x20004010, 0x00004000, 0x00404000, 0x20004010, 0x00000010, 0x20400010, 0x20400010, 0x00000000, 0x00404010, 0x20404000, 0x00004010, 0x00404000, 0x20404000, 0x20000000, 0x20004000, 0x00000010, 0x20400010, 0x00404000, 0x20404010, 0x00400000, 0x00004010, 0x20000010, 0x00400000, 0x20004000, 0x20000000, 0x00004010, 0x20000010, 0x20404010, 0x00404000, 0x20400000, 0x00404010, 0x20404000, 0x00000000, 0x20400010, 0x00000010, 0x00004000, 0x20400000, 0x00404010, 0x00004000, 0x00400010, 0x20004010, 0x00000000, 0x20404000, 0x20000000, 0x00400010, 0x20004010};
        int[] SP7 = {0x00200000, 0x04200002, 0x04000802, 0x00000000, 0x00000800, 0x04000802, 0x00200802, 0x04200800, 0x04200802, 0x00200000, 0x00000000, 0x04000002, 0x00000002, 0x04000000, 0x04200002, 0x00000802, 0x04000800, 0x00200802, 0x00200002, 0x04000800, 0x04000002, 0x04200000, 0x04200800, 0x00200002, 0x04200000, 0x00000800, 0x00000802, 0x04200802, 0x00200800, 0x00000002, 0x04000000, 0x00200800, 0x04000000, 0x00200800, 0x00200000, 0x04000802, 0x04000802, 0x04200002, 0x04200002, 0x00000002, 0x00200002, 0x04000000, 0x04000800, 0x00200000, 0x04200800, 0x00000802, 0x00200802, 0x04200800, 0x00000802, 0x04000002, 0x04200802, 0x04200000, 0x00200800, 0x00000000, 0x00000002, 0x04200802, 0x00000000, 0x00200802, 0x04200000, 0x00000800, 0x04000002, 0x04000800, 0x00000800, 0x00200002};
        int[] SP8 = {0x10001040, 0x00001000, 0x00040000, 0x10041040, 0x10000000, 0x10001040, 0x00000040, 0x10000000, 0x00040040, 0x10040000, 0x10041040, 0x00041000, 0x10041000, 0x00041040, 0x00001000, 0x00000040, 0x10040000, 0x10000040, 0x10001000, 0x00001040, 0x00041000, 0x00040040, 0x10040040, 0x10041000, 0x00001040, 0x00000000, 0x00000000, 0x10040040, 0x10000040, 0x10001000, 0x00041040, 0x00040000, 0x00041040, 0x00040000, 0x10041000, 0x00001000, 0x00000040, 0x10040040, 0x00001000, 0x00041040, 0x10001000, 0x00000040, 0x10000040, 0x10040000, 0x10040040, 0x10000000, 0x00040000, 0x10001040, 0x00000000, 0x10041040, 0x00040040, 0x10000040, 0x10040000, 0x10001000, 0x10001040, 0x00000000, 0x10041040, 0x00041000, 0x00041000, 0x00001040, 0x00001040, 0x00040040, 0x10000000, 0x10041000};       
        int[] newKey = new int[32];
        boolean[] pc1m = new boolean[56];
        boolean[] pcr = new boolean[56];
        
        for (int j = 0; j < 56; j++){
            int l = pc1[j];
            pc1m[j] = ((key[l >>> 3] & bytebit[l & 07]) != 0);
        }
        for (int i = 0; i < 16; i++){
            int l;
            int m = (encrypting) ? i << 1 : (15 - i) << 1;
            int n = m + 1;
            newKey[m] = newKey[n] = 0;
            for (int j = 0; j < 28; j++){
                l = j + totrot[i];
                pcr[j] = (l < 28) ? pc1m[l] : pc1m[l - 28];
            }
            for (int j = 28; j < 56; j++){
                l = j + totrot[i];
                pcr[j] = (l < 56) ? pc1m[l] : pc1m[l - 28];
            }
            for (int j = 0; j < 24; j++){
                if (pcr[pc2[j]])
                    newKey[m] |= bigbyte[j];
                if (pcr[pc2[j + 24]])
                    newKey[n] |= bigbyte[j];
            }
        }
        for (int i = 0; i != 32; i += 2){
            int i1 = newKey[i];
            int i2 = newKey[i + 1];
            newKey[i] = ((i1 & 0x00fc0000) << 6) | ((i1 & 0x00000fc0) << 10) | ((i2 & 0x00fc0000) >>> 10) | ((i2 & 0x00000fc0) >>> 6);
            newKey[i + 1] = ((i1 & 0x0003f000) << 12) | ((i1 & 0x0000003f) << 16) | ((i2 & 0x0003f000) >>> 4) | (i2 & 0x0000003f);
        }
        
        for(int offset = 0; offset < in.length; offset+=8){
            int left = (in[offset + 0] & 0xff) << 24;
            left |= (in[offset + 1] & 0xff) << 16;
            left |= (in[offset + 2] & 0xff) << 8;
            left |= (in[offset + 3] & 0xff);   
            int right = (in[offset + 4] & 0xff) << 24;
            right |= (in[offset + 5] & 0xff) << 16;
            right |= (in[offset + 6] & 0xff) << 8;
            right |= (in[offset + 7] & 0xff);
            int work = ((left >>> 4) ^ right) & 0x0f0f0f0f;
            right ^= work;
            left ^= (work << 4);
            work = ((left >>> 16) ^ right) & 0x0000ffff;
            right ^= work;
            left ^= (work << 16);
            work = ((right >>> 2) ^ left) & 0x33333333;
            left ^= work;
            right ^= (work << 2);
            work = ((right >>> 8) ^ left) & 0x00ff00ff;
            left ^= work;
            right ^= (work << 8);
            right = ((right << 1) | ((right >>> 31) & 1)) & 0xffffffff;
            work = (left ^ right) & 0xaaaaaaaa;
            left ^= work;
            right ^= work;
            left = ((left << 1) | ((left >>> 31) & 1)) & 0xffffffff;
            for (int round = 0; round < 8; round++){
                work  = (right << 28) | (right >>> 4);
                work ^= newKey[round * 4 + 0];
                int fval  = SP7[work & 0x3f];
                fval |= SP5[(work >>> 8) & 0x3f];
                fval |= SP3[(work >>> 16) & 0x3f];
                fval |= SP1[(work >>> 24) & 0x3f];
                work = right ^ newKey[round * 4 + 1];
                fval |= SP8[work & 0x3f];
                fval |= SP6[(work >>> 8) & 0x3f];
                fval |= SP4[(work >>> 16) & 0x3f];
                fval |= SP2[(work >>> 24) & 0x3f];
                left ^= fval;
                work = (left << 28) | (left >>> 4);
                work ^= newKey[round * 4 + 2];
                fval = SP7[work & 0x3f];
                fval |= SP5[(work >>> 8) & 0x3f];
                fval |= SP3[(work >>> 16) & 0x3f];
                fval |= SP1[(work >>> 24) & 0x3f];
                work = left ^ newKey[round * 4 + 3];
                fval |= SP8[work & 0x3f];
                fval |= SP6[(work >>> 8) & 0x3f];
                fval |= SP4[(work >>> 16) & 0x3f];
                fval |= SP2[(work >>> 24) & 0x3f];
                right ^= fval;
            }
            right = (right << 31) | (right >>> 1);
            work = (left ^ right) & 0xaaaaaaaa;
            left ^= work;
            right ^= work;
            left = (left << 31) | (left >>> 1);
            work = ((left >>> 8) ^ right) & 0x00ff00ff;
            right ^= work;
            left ^= (work << 8);
            work = ((left >>> 2) ^ right) & 0x33333333;
            right ^= work;
            left ^= (work << 2);
            work = ((right >>> 16) ^ left) & 0x0000ffff;
            left ^= work;
            right ^= (work << 16);
            work = ((right >>> 4) ^ left) & 0x0f0f0f0f;
            left ^= work;
            right ^= (work << 4);
            out[offset + 0] = (byte)((right >>> 24) & 0xff);
            out[offset + 1] = (byte)((right >>> 16) & 0xff);
            out[offset + 2] = (byte)((right >>> 8) & 0xff);
            out[offset + 3] = (byte)(right & 0xff);
            out[offset + 4] = (byte)((left >>> 24) & 0xff);
            out[offset + 5] = (byte)((left >>> 16) & 0xff);
            out[offset + 6] = (byte)((left >>> 8) & 0xff);
            out[offset + 7] = (byte)(left & 0xff);
        }
        
        return out;
    }
}
