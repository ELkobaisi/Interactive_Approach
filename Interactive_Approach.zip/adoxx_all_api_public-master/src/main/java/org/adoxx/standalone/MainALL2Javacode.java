package org.adoxx.standalone;

import org.adoxx.all.abstracted.factory.ADOLibFactory;

public class MainALL2Javacode {

    public static void main(String[] args) {
        try{
            if(args.length==0) {
                System.out.println("USAGE: org.adoxx.standalone.MainALL2Javacode allFilePath [javaFilePath]");
                return;
            }
            
            String allFile = args[0];           
            String javaFile = (args.length==2)?args[1]:allFile+".java";
            ADOLibFactory.generateJavaCodeFileFromAllFile(javaFile, allFile, 2, null);
        }catch(Exception ex){ex.printStackTrace();}
    }
}
