package org.adoxx.standalone;

import org.adoxx.ado.ADOUtils;
import org.adoxx.utils.Utils;

public class MainABL2ALL {

    public static void main(String[] args) {
        try{
            if(args.length==0) {
                System.out.println("USAGE: org.adoxx.standalone.MainABL2ALL ablFilePath [allFilePath]");
                return;
            }
            
            String ablFile = args[0];           
            String allFile = (args.length==2)?args[1]:ablFile+".all";
            byte[] abl = Utils.readFile(ablFile);
            String allModel = ADOUtils.convertABL2ALL(abl);
            Utils.writeFile(allModel.getBytes("UTF-8"), allFile, false);
            
        }catch(Exception ex){ex.printStackTrace();}
    }
}
