package org.adoxx.standalone;

import org.adoxx.all.abstracted.factory.ADOLibFactory;

public class MainJSON2ALL {

    public static void main(String[] args) {
        try{
            if(args.length==0) {
                System.out.println("USAGE: org.adoxx.standalone.MainJSON2ALL jsonFilePath [allFilePath]");
                return;
            }
            
            String jsonFile = args[0];           
            String allFile = (args.length==2)?args[1]:jsonFile+".all";
            ADOLibFactory.loadFromJsonFile(jsonFile).generateALLFile(allFile);
        }catch(Exception ex){ex.printStackTrace();}
    }

}
