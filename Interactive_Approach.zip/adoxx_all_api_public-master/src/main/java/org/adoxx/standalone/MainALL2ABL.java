package org.adoxx.standalone;

import org.adoxx.ado.ADOUtils;
import org.adoxx.utils.Utils;

public class MainALL2ABL {

    public static void main(String[] args) {
        try{
            if(args.length<2) {
                System.out.println("USAGE: org.adoxx.standalone.MainALL2ABL webservice|nowebservice allFilePath [ablFilePath]");
                return;
            }
            
            boolean useWebservice = args[0].equals("webservice");
            
            String allFile = args[1];           
            String ablFile = (args.length==3)?args[2]:allFile+".abl";
            String allModel = new String(Utils.readFile(allFile), "UTF-8");
            
            if(useWebservice) {
                ADOUtils.callALL2ABLService(allModel, "local", ablFile);
            } else {
                byte[] abl = ADOUtils.convertALL2ABL(allModel);
                Utils.writeFile(abl, ablFile, false);
            }
        }catch(Exception ex){ex.printStackTrace();}
    }

}
