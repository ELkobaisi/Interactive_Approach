package org.adoxx.standalone;

import org.adoxx.ado.ADOUtils;

public class MainABL2DB {

    public static void main(String[] args) {
        try{
            if(args.length<3) {
                System.out.println("USAGE: org.adoxx.standalone.MainABL2DB ablFilePath adoxxDBName adoxxLicenseKey");
                return;
            }
            
            String ablFilePath = args[0];
            String adoxxDBName = args[1];
            String adoxxLicenseKey = args[2];
            
            ADOUtils.callABL2DBScript(ablFilePath, adoxxDBName, adoxxLicenseKey);
            
        }catch(Exception ex){ex.printStackTrace();}
    }
}
