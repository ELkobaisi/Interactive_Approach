package org.adoxx.standalone;

import org.adoxx.ado.ADOUtils;

public class MainLicenseGen {

    public static void main(String[] args) {
        try{
            if(args.length!=2) {
                System.out.println("USAGE: org.adoxx.standalone.MainLicenseGen ismail|isnotmail name");
                return;
            }
            String customerName = args[1];
            if(args[0].equals("ismail"))
                customerName = ADOUtils.generateLicenseCustomerName(customerName);
            String license = ADOUtils.generateLicenseKey(customerName);
            System.out.println(license);
        }catch(Exception ex){ex.printStackTrace();}
    }

}
