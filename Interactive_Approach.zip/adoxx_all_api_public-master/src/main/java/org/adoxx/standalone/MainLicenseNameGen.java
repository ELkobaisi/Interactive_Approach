package org.adoxx.standalone;

import org.adoxx.ado.ADOUtils;

public class MainLicenseNameGen {

    public static void main(String[] args) {
        try{
            if(args.length==0) {
                System.out.println("USAGE: org.adoxx.standalone.MainLicenseNameGen eMail");
                return;
            }
            String eMail = args[0];
            String customerName = ADOUtils.generateLicenseCustomerName(eMail);
            System.out.println(customerName);
        }catch(Exception ex){ex.printStackTrace();}
    }

}
