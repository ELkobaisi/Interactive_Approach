package org.adoxx.examples;

import org.adoxx.all.abstracted.ADOAllFile;
import org.adoxx.all.abstracted.factory.ADOLibFactory;

public class WeavHEML_BPMN {

	public static void main(String[] args) {
		try{
		
			
			  ADOAllFile mainLib = ADOLibFactory.loadFromAllFile("D:\\lib\\BPMN.all", true);
	          ADOAllFile secondLib = ADOLibFactory.loadFromAllFile("D:\\lib\\New_HEML.all", true);
	          ADOAllFile mergedLib = ADOLibFactory.generateADOxxTotalEmptyLibrary("WeavedBPMN");
	            
//	          mergedLib.getApplicationLibraryNew().getDynamicLibrary();
//	          mergedLib.getApplicationLibraryNew().getStaticLibrary();	            
	            
		
			  mergedLib.getApplicationLibraryNew()
			                                    .importClassesAndRelations(mainLib.getApplicationLibraryNew())
			                                    .importAttributeProfileClasses(mainLib.getApplicationLibraryNew())
			                                    .importRecordClasses(mainLib.getApplicationLibraryNew())
			                                    .importFiles(mainLib.getApplicationLibraryNew())
			                                    
			                                    .importSpecialClasses(secondLib.getApplicationLibraryNew(), true)
			                                    .importClass(secondLib.getApplicationLibraryNew(), true, "Emotion")
			                                    .importClass(secondLib.getApplicationLibraryNew(), true, "Capability")
			                                    .importClass(secondLib.getApplicationLibraryNew(), true, "ES")
			                                    .importClass(secondLib.getApplicationLibraryNew(), true, "Operation")
			                                   
			                                    .importRelation(secondLib.getApplicationLibraryNew(), true, "ES-Emotion")
			                                    .importRelation(secondLib.getApplicationLibraryNew(), true, "ES-Operation")
			                                    .importRelation(secondLib.getApplicationLibraryNew(), true, "ES-Capability")
			                                    .importRelation(secondLib.getApplicationLibraryNew(), true, "Capability-Operation")
			                                    .importRecordClasses(secondLib.getApplicationLibraryNew())
		                                        .importAttributeProfileClasses(secondLib.getApplicationLibraryNew())
		                                        .importFiles(secondLib.getApplicationLibraryNew());	
		                                        

		                                        
		                                        
    String dynamicModi = "GENERAL order-of-classes:custom \n DISPLAYED_MODELATTR \"State\" default-hidden enum-value1:\"In process\" bitmap1:\"db:\\\\symbol_state_s_draft.bmp\" enum-value2:\"Ready\" bitmap2:\"db:\\\\symbol_state_s_qa.bmp\" \n enum-value3:\"Reviewed\" bitmap3:\"db:\\\\symbol_state_s_released.bmp\" \n MODELTYPE \"Company map\" from:none plural:\"Company maps\" pos:1 not-simulateable bitmap:\"db:\\\\compmap.bmp\" attrrep:\"BP Model Attributes\" graphrep:\"BP Model Graphrep\" \n INCL \"Swimlane (vertical)\" \n INCL \"Swimlane (horizontal)\" \n INCL \"Process\" \n INCL \"Performance\" \n INCL \"actor\" \n INCL \"External partner\" \n INCL \"Performance indicator\" \n INCL \"Performance indicator overview\" \n INCL \"Aggregation\" \n INCL \"Note\" \n INCL \"Has process\" \n INCL \"Value flow\" \n INCL \"Owns\" \n INCL \"Is inside\" \n INCL \"has Note\" \n MODE \"Standard\" from:all \n EXCL \"Performance indicator overview\" \n EXCL \"Performance indicator\" \n EXCL \"Owns\" \n MODE \"Standard - including Performance indicators\" from:all \n MODE \"All modelling objects\" from:all \n MODE \"Documentation\" from:all no-modeling \n MODELTYPE \"Business process diagram (BPMN 2.0)\" from:none plural:\"Business process diagrams (BPMN 2.0)\" pos:2 bitmap:\"db:\\\\mfb_bpmn20_bpd.bmp\" attrrep:\"BPMN20 Model Attributes\" graphrep:\"BPM Model Graphrep\" \n INCL \"Pool\" \n INCL \"Pool (collapsed)\" \n INCL \"Lane\" \n INCL \"Start Event\" \n INCL \"Intermediate Event (boundary)\" \n INCL \"Intermediate Event (sequence flow)\" \n INCL \"End Event\" \n INCL \"Task\" \n INCL \"Sub-Process\" \n INCL \"Exclusive Gateway\" \n INCL \"Non-exclusive Gateway\" \n INCL \"Non-exclusive Gateway (converging)\" \n INCL \"Data Object\" \n INCL \"Message\" \n INCL \"Group\" \n INCL \"Text Annotation\" \n INCL \"Relation Node\" \n INCL \"Variable\" \n INCL \"Random generator\" \n INCL \"Performance indicator\" \n INCL \"Performance indicator overview\" \n INCL \"Note\" \n INCL \"Aggregation\" \n INCL \"Subsequent\" \n INCL \"Message Flow\" \n INCL \"Association\" \n INCL \"Data Association\" \n INCL \"Conversation Link\" \n INCL \"Sets variable\" \n INCL \"Sets\" \n INCL \"Owns\" \n INCL \"has Note\" \n MODE \"Business Process Diagram\" from:all \n EXCL \"Variable\" \n EXCL \"Random generator\" \n EXCL \"Performance indicator\" \n EXCL \"Performance indicator overview\" \n EXCL \"Sets variable\" \n EXCL \"Sets\" \n EXCL \"Owns\" \n EXCL \"Conversation Link\" \n MODE \"BPMN 2.0 All modelling objects\" from:all \n EXCL \"Variable\" \n EXCL \"Random generator\" \n EXCL \"Performance indicator\" \n EXCL \"Performance indicator overview\" \n EXCL \"Sets variable\" \n EXCL \"Sets\" \n EXCL \"Owns\" \n MODE \"Advanced simulation\" from:\"BPMN 2.0 All modelling objects\" \n INCL \"Variable\" \n INCL \"Random generator\" \n INCL \"Sets variable\" \n INCL \"Sets\" \n MODE \"With KPIs\" from:\"BPMN 2.0 All modelling objects\" \n INCL \"Performance indicator overview\" \n INCL \"Performance indicator\" \n INCL \"Owns\" \n MODE \"All modelling objects\" from:all \n MODE \"Documentation\" from:all no-modeling \n MODELTYPE \"Document model\" from:none plural:\"Document models\" pos:4 not-simulateable bitmap:\"db:\\\\doc_mod.bmp\" attrrep:\"BP Model Attributes\" graphrep:\"BP Model Graphrep\" \n INCL \"Document\" \n INCL \"Aggregation\" \n INCL \"Note\" \n INCL \"has Subdocument\" \n INCL \"has Note\" \n INCL \"Swimlane (vertical)\" \n INCL \"Swimlane (horizontal)\" \n MODE \"Standard\" from:all \n MODE \"Documentation\" from:all no-modeling \nMODELTYPE \"HEM Plugin Elements\" from:none plural:\"HEM Plugin Elements\" pos:2 \nINCL \"Emotion\"\nINCL \"Operation\"\nINCL \"Capability\"\nINCL \"ES\"\nINCL \"Capability-Operation\"\nINCL \"ES-Emotion\"\nINCL \"ES-Capability\"\nINCL \"ES-Operation\"";
    String staticModi = "";    
    mergedLib.getApplicationLibraryNew().getDynamicLibrary().setModi(dynamicModi);
    mergedLib.getApplicationLibraryNew().getStaticLibrary().setModi(staticModi);

	mergedLib.generateABLFile("D:\\lib\\weavedBPMN.abl")
			         .generateALLFile("D:\\lib\\weavedBPMN.all");
			          System.out.println(" HEML plugin has been created...");
			
		}catch(Exception ex){ex.printStackTrace();}
	}
}
