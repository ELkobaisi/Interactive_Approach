package org.adoxx.examples;

import org.adoxx.all.abstracted.ADOAllFile;
import org.adoxx.all.abstracted.factory.ADOLibFactory;

public class WeavHCML_HEM {

    public static void main(String[] args) {
        try {
            ADOAllFile hcmLib = ADOLibFactory.loadFromAllFile("D:\\lib\\HCMLModeller.all", true);
            ADOAllFile hemLib = ADOLibFactory.loadFromAllFile("D:\\lib\\New_HEML.all", true);
            ADOAllFile weavedLib = ADOLibFactory.generateADOxxTotalEmptyLibrary("Weaved");
            
//            mergedLib.getApplicationLibraryNew().getDynamicLibrary().addADOxxInternalMetaModelClassesAndRelations();
//            mergedLib.getApplicationLibraryNew().getStaticLibrary().addADOxxInternalMetaModelClassesAndRelations();
            
//            weavedLib.getApplicationLibraryNew().getDynamicLibrary();
//            weavedLib.getApplicationLibraryNew().getStaticLibrary();
// 
            
            weavedLib.getApplicationLibraryNew()
                                                //HCML MetaClasses
                                                .importSpecialClasses(hcmLib.getApplicationLibraryNew(), true)
                                                .importClass(hcmLib.getApplicationLibraryNew(), true, "Behavioral Unit")
                                                .importClass(hcmLib.getApplicationLibraryNew(), true, "Operation")
                                                .importClass(hcmLib.getApplicationLibraryNew(), true, "Goal")
                                                .importClass(hcmLib.getApplicationLibraryNew(), true, "Thing")
                                                .importClass(hcmLib.getApplicationLibraryNew(), true, "Person")
                                              
                                                
//                                               //HEM
                                                .importSpecialClasses(hemLib.getApplicationLibraryNew(), true)
                                                .importClass(hemLib.getApplicationLibraryNew(), true, "Emotion")
                                                .importClass(hemLib.getApplicationLibraryNew(), true, "Capability")
                                                .importClass(hemLib.getApplicationLibraryNew(), true, "ES")
                                                
                                                // Add required relationships
                                                .importRelation(hemLib.getApplicationLibraryNew(), true, "ES-Emotion")
			                                    .importRelation(hemLib.getApplicationLibraryNew(), true, "ES-Operation")
			                                    .importRelation(hemLib.getApplicationLibraryNew(), true, "ES-Capability")
			                                    .importRelation(hemLib.getApplicationLibraryNew(), true, "Capability-Operation")
	
                                               //Add all  files
                                                .importFiles(hemLib.getApplicationLibraryNew())
                                                .importFiles(hcmLib.getApplicationLibraryNew())
                                                //Add all  record classes
                                                .importRecordClasses(hemLib.getApplicationLibraryNew())
                                                .importRecordClasses(hcmLib.getApplicationLibraryNew())
                                                //Add all  attribute profile classes
                                                .importAttributeProfileClasses(hemLib.getApplicationLibraryNew())
                                                .importAttributeProfileClasses(hcmLib.getApplicationLibraryNew());
            
//---------------------
//            String dynamicModi = "GENERAL order-of-classes:custom\nDISPLAYED_MODELATTR \"State\" default-hidden\nenum-value1:\"In process\" bitmap1:\"db:\\\\symbol_state_s_draft.bmp\"\nenum-value2:\"Ready\" bitmap2:\"db:\\\\symbol_state_s_qa.bmp\"\nenum-value3:\"Reviewed\" bitmap3:\"db:\\\\symbol_state_s_released.bmp\"\n\n\n\nMODELTYPE \"Business process diagram (BPMN 2.0)\" from:none plural:\"Business process diagrams (BPMN 2.0)\" pos:2 bitmap:\"db:\\\\mfb_bpmn20_bpd.bmp\" attrrep:\"BPMN20 Model Attributes\" graphrep:\"BPM Model Graphrep\"\nINCL \"Pool\"\nINCL \"Pool (collapsed)\"\nINCL \"Lane\"\nINCL \"Start Event\"\nINCL \"Intermediate Event (boundary)\"\nINCL \"Intermediate Event (sequence flow)\"\nINCL \"End Event\"\nINCL \"Task\"\nINCL \"Sub-Process\"\nINCL \"Exclusive Gateway\"\nINCL \"Non-exclusive Gateway\"\nINCL \"Non-exclusive Gateway (converging)\"\nINCL \"Data Object\"\nINCL \"Message\"\nINCL \"Group\"\nINCL \"Text Annotation\"\nINCL \"Relation Node\"\nINCL \"Variable\"\nINCL \"Random generator\"\nINCL \"Performance indicator\"\nINCL \"Performance indicator overview\"\nINCL \"Note\"\nINCL \"Aggregation\"\nINCL \"Subsequent\"\nINCL \"Message Flow\"\nINCL \"Association\"\nINCL \"Data Association\"\nINCL \"Conversation Link\"\nINCL \"Sets variable\"\nINCL \"Sets\"\nINCL \"Owns\"\nINCL \"has Note\"\n\nMODE \"Business Process Diagram\" from:all\nEXCL \"Variable\"\nEXCL \"Random generator\"\nEXCL \"Performance indicator\"\nEXCL \"Performance indicator overview\"\nEXCL \"Sets variable\"\nEXCL \"Sets\"\nEXCL \"Owns\"\nEXCL \"Conversation Link\"\n\nMODE \"BPMN 2.0 All modelling objects\" from:all\nEXCL \"Variable\"\nEXCL \"Random generator\"\nEXCL \"Performance indicator\"\nEXCL \"Performance indicator overview\"\nEXCL \"Sets variable\"\nEXCL \"Sets\"\nEXCL \"Owns\"\n\nMODE \"Advanced simulation\" from:\"BPMN 2.0 All modelling objects\"\nINCL \"Variable\"\nINCL \"Random generator\"\nINCL \"Sets variable\"\nINCL \"Sets\"\n\nMODE \"With KPIs\" from:\"BPMN 2.0 All modelling objects\"\nINCL \"Performance indicator overview\"\nINCL \"Performance indicator\"\nINCL \"Owns\"\n\nMODE \"Standard\" from:all\nMODE \"Documentation\" from:all no-modeling\n    \n\nMODELTYPE \"BPCMN model\" from:none plural:\"BPCMN models\" pos:6 not-simulateable bitmap:\"db:\\\\ABCMN2.bmp\" attrrep:\"BP Model Attributes\" graphrep:\"BP Model Graphrep\"\n#INCL \"Case Plan Model\"\nINCL \"Stage\"\nINCL \"Discretionary Stage\"\nINCL \"Task\"\nINCL \"Discretionary Task\"\nINCL \"Sub-Process\"\nINCL \"Discretionary Sub-Process\"\nINCL \"Sentry\"\nINCL \"Start Event\"\nINCL \"Intermediate Event (boundary)\"\nINCL \"Intermediate Event (sequence flow)\"\nINCL \"End Event\"\nINCL \"Exclusive Gateway\"\nINCL \"Non-exclusive Gateway\"\nINCL \"Non-exclusive Gateway (converging)\"\nINCL \"Data Object\"\nINCL \"Discretionary Data Object\"\nINCL \"Pool\"\nINCL \"Pool (collapsed)\"\nINCL \"Lane\"\nINCL \"Message\"\nINCL \"Note\"\n#INCL \"Connector\"\n#INCL \"Connector (for Discretionary Tasks)\"\nINCL \"Connector (for Discretionary elements)\"\n\nINCL \"Subsequent\"\nINCL \"Message Flow\"\nINCL \"Association\"\nINCL \"Data Association\"\nINCL \"has Note\"\n\nMODE \"Standard\" from:all\nMODE \"Documentation\" from:all no-modeling\n\n\nMODELTYPE \"Control Elements\" from:none plural:\"Control Elements\" pos:8 not-simulateable bitmap:\"db:\\\\on-if.bmp\" attrrep:\"BP Model Attributes\" graphrep:\"BP Model Graphrep\"\nINCL \"Sentry\"\nINCL \"On-Part\"\nINCL \"If-Part\"\n#INCL \"Aggregation\"\nINCL \"Connector\"\nMODE \"Standard\" from:all\nMODE \"Documentation\" from:all no-modeling\n\n\n\n\nMODELTYPE \"DMN Model\" from:none plural:\"DMN Models\"\nINCL \"Business Knowledge Model\"\nINCL \"Decision (DMN)\"\nINCL \"Input Data\"\nINCL \"Knowledge Source\"\nINCL \"Boxed Expression\"\n\nINCL \"Authority Requirement\"\nINCL \"Knowledge Requirement\"\nINCL \"Information Requirement\"\nINCL \"Has Boxed Expression\"\n\n\nMODE \"Documentation\" from:all no-modeling\n\n\n\n\nMODELTYPE \"Document and Knowledge model\" from:none plural:\"Document and Knowledge models\" pos:4 not-simulateable bitmap:\"db:\\\\doc_mod.bmp\" attrrep:\"BP Model Attributes\" graphrep:\"BP Model Graphrep\"\nINCL \"Document\"\n\nINCL \"Knowledge Product\"\nINCL \"Knowledge Resource\"\nINCL \"Knowledge Source\"\nINCL \"Belongs to\"\n# INCL \"has Relation with\"\n\nINCL \"Group\"\nINCL \"Note\"\nINCL \"has Subdocument\"\nINCL \"has Note\"\nINCL \"Swimlane (vertical)\"\nINCL \"Swimlane (horizontal)\"\nINCL \"Comment Box\"\nINCL \"ObjectToComment\"\nMODE \"Standard\" from:all\nMODE \"Documentation\" from:all no-modeling\n\n# Below is for \"Method GraphRep\" (DB)\nGENERAL order-of-classes:custom\nMETHOD graphRep: \"Method GraphRep\"\n{\nGROUP \"Document and Knowledge Product\"\n{\nMODELTYPE \"Document and Knowledge model\"\n}\n}";
//            String staticModi = "MODELTYPE \"Organizational structure\" from:none plural:\"Working environment models\" pos:3 attrrep:\"WE Model Attributes\" graphrep:\"BP Model Graphrep\"\nINCL \"Swimlane (vertical)\"\nINCL \"Swimlane (horizontal)\"\nINCL \"Organizational unit\"\nINCL \"Performer\"\nINCL \"Role\"\nINCL \"Position\"\nINCL \"Resource\"\nINCL \"Cost center\"\nINCL \"Team\"\nINCL \"Text Annotation\"\nINCL \"Is subordinated\"\nINCL \"has Resource\"\nINCL \"belongs to\"\nINCL \"Is manager\"\nINCL \"Has role\"\nINCL \"has position\"\nINCL \"Uses resource\"\nINCL \"Is charged to\"\nINCL \"Is cost center manager\"\nINCL \"has Note\"\n\nMODE \"Standard\" from:all\nEXCL \"Resource\"\nEXCL \"Cost center\"\nEXCL \"Position\"\n\nMODE \"Standard - including Resources\" from:all\nEXCL \"Cost center\"\nEXCL \"Position\"\n\nMODE \"Standard - with cost center\" from:all\nEXCL \"Resource\"\nEXCL \"Position\"\n\nMODE \"Organization\" from:all\nEXCL \"Performer\"\nEXCL \"Role\"\nEXCL \"Resource\"\nEXCL \"Cost center\"\n\nMODE \"Role diagram\" from:all\nEXCL \"Organizational unit\"\nEXCL \"Performer\"\nEXCL \"Position\"\nEXCL \"Resource\"\nEXCL \"Cost center\"\n\nMODE \"Resource diagram\" from:all\nEXCL \"Role\"\nEXCL \"belongs to\"\nEXCL \"Is manager\"\nEXCL \"Position\"\nEXCL \"Cost center\"\n\nMODE \"All modelling objects\" from:all\nMODE \"Documentation\" from:all no-modeling";

    String dynamicModi = "GENERAL order-of-classes:custom \nMODELTYPE \"Task Context\" from:none plural:\"Task Context\" not-simulateable  order-of-classes:custo\n m bitmap:\"db:\\\\TC.bmp\" \nINCL \"Operation and Behavioral Unit\" \nMODELTYPE \"Sequence\" from:none plural:\"Sequence\" not-simulateable  order-of-classes:custom bitmap:\"db:\\\\S.bmp\" \nINCL \"Operation\"\nINCL \"Flow\"\nMODELTYPE \"Makro\" from:none plural:\"Makro\" not-simulateable  order-of-classes:custom  bitmap:\"db:\\\\M.bmp\"\nINCL \"Operation\"\nINCL \"Flow\"\nMODELTYPE \"Behavioral Unit Model Bum\" from:none plural:\"Behavioral Unit Model Bum\" not-simulateable  order-of-classes:custom bitmap:\"db:\\\\BUM.bmp\"\nINCL \"Operation\" \nINCL \"Operation Makro\"\nINCL \"Operation and Behavioral Unit\"\nINCL \"Behavioral Unit\"\nINCL \"Goal\"\nINCL \"Flow\"\nINCL \"has\"\nMODE \"Standard\" from:all\nMODELTYPE \"Structural Context\" from:none plural:\"Structural Context\" not-simulateable  order-of-classes:custom bitmap:\"db:\\\\StC.bmp\"\nINCL \"Person\"\nINCL \"Thing\"\nINCL \"Super Thing\"\nINCL \"Super Person\"\nINCL \"Location\"\nINCL \"Super Location\"\nINCL \"Connection\"\nINCL \"Is-A\" \nMODE \"Standard\" from:all\nMODELTYPE \"HEM Plugin Elements\" from:none plural:\"HEM Plugin Elements\" pos:2 \nINCL \"Emotion\"\nINCL \"Operation\"\nINCL \"Capability\"\nINCL \"ES\"\nINCL \"Capability-Operation\"\nINCL \"ES-Emotion\"\nINCL \"ES-Capability\"\nINCL \"ES-Operation\"";
    String staticModi = "";    
            
            
 
            
            weavedLib.getApplicationLibraryNew().getDynamicLibrary().setModi(dynamicModi);
            weavedLib.getApplicationLibraryNew().getStaticLibrary().setModi(staticModi);
//            
//  ----------------------------------------------- 
            
////            //LIBRARY FIX: delete attribute with missing referenced classes
//            mergedLib.getApplicationLibraryNew().getDynamicLibrary().getClassDefinition("Pool").removeAttribute("Referenced Planning Table");
//            mergedLib.getApplicationLibraryNew().getDynamicLibrary().getClassDefinition("Pool (collapsed)").removeAttribute("Referenced Planning Table");
     
            
            weavedLib.generateALLFile("D:\\lib\\weaved_New.all");
            ADOLibFactory.loadFromAllFile("D:\\lib\\weaved_New.all", true);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
