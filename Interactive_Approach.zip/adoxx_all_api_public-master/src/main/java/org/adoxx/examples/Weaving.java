package org.adoxx.examples;

import org.adoxx.all.abstracted.ADOAllFile;
import org.adoxx.all.abstracted.factory.ADOLibFactory;


public class Weaving {
	
	public static void main(String[] args) {
        try {
            ADOAllFile hcmLib = ADOLibFactory.loadFromAllFile("D:\\lib\\New_HCM-L V.0.3.3.all", true);
            ADOAllFile hemLib = ADOLibFactory.loadFromAllFile("D:\\lib\\New_HEML.all", true);
            ADOAllFile areLib = ADOLibFactory.loadFromAllFile("D:\\lib\\New_AREML.all", true);
            
            ADOAllFile mergedLib = ADOLibFactory.generateADOxxTotalEmptyLibrary("Merged");
            
//            mergedLib.getApplicationLibraryNew().getDynamicLibrary().addADOxxInternalMetaModelClassesAndRelations();
//            mergedLib.getApplicationLibraryNew().getStaticLibrary().addADOxxInternalMetaModelClassesAndRelations();
            
            mergedLib.getApplicationLibraryNew()
                                                //HCML 
                                                .importSpecialClasses(hcmLib.getApplicationLibraryNew(), true)
//                                                .importClass(hcmLib.getApplicationLibraryNew(), true, "Behavioral Unit")
                                                .importClass(hcmLib.getApplicationLibraryNew(), true, "Operation")
                                                .importClass(hcmLib.getApplicationLibraryNew(), true, "Goal")
                                                .importClass(hcmLib.getApplicationLibraryNew(), true, "Behavioral Unit Element")
//                                                .importRelation(hcmLib.getApplicationLibraryNew(), true, "has")
//                                                .importRelation(hcmLib.getApplicationLibraryNew(), true, "Flow")
//                                                //HEM
                                                .importSpecialClasses(hemLib.getApplicationLibraryNew(), true)
                                                .importClass(hemLib.getApplicationLibraryNew(), true, "Emotion")
//                                                .importClass(hemLib.getApplicationLibraryNew(), true, "Operation")
//                                                .importClass(hemLib.getApplicationLibraryNew(), true, "ES")
//                                                .importRelation(hemLib.getApplicationLibraryNew(), true, "ESR")
//                                                .importRelation(hemLib.getApplicationLibraryNew(), true, "ES-Emotion")
//                                                //ARE
                                                .importSpecialClasses(areLib.getApplicationLibraryNew(), true)
                                                .importClass(areLib.getApplicationLibraryNew(), true, "Action")
                                                .importClass(areLib.getApplicationLibraryNew(), true, "Thing")
//                                                .importClass(areLib.getApplicationLibraryNew(), true, "Property")
//                                                .importClass(areLib.getApplicationLibraryNew(), true, "Connection")
//                                                .importClass(areLib.getApplicationLibraryNew(), true, "Person")
//                                                .importClass(areLib.getApplicationLibraryNew(), true, "Object")
//                                                .importRelation(areLib.getApplicationLibraryNew(), true, "fromProperty")
//                                                .importRelation(areLib.getApplicationLibraryNew(), true, "toProperty")
                                                //import all the files
                                                .importFiles(hemLib.getApplicationLibraryNew())
                                                .importFiles(hcmLib.getApplicationLibraryNew())
                                                .importFiles(areLib.getApplicationLibraryNew())
                                                //import all the record classes
                                                .importRecordClasses(hemLib.getApplicationLibraryNew())
                                                .importRecordClasses(hcmLib.getApplicationLibraryNew())
                                                .importRecordClasses(areLib.getApplicationLibraryNew())
                                                //import all the attribute profile classes
                                                .importAttributeProfileClasses(hemLib.getApplicationLibraryNew())
                                                .importAttributeProfileClasses(hcmLib.getApplicationLibraryNew())
                                                .importAttributeProfileClasses(areLib.getApplicationLibraryNew());       
            
            
            mergedLib.generateALLFile("D:\\lib\\merged_New.all");
//            ADOLibFactory.loadFromAllFile("D:\\lib\\merged_New.all", true);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
