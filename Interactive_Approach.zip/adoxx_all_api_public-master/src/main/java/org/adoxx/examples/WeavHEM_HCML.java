package org.adoxx.examples;

import org.adoxx.all.abstracted.ADOAllFile;
import org.adoxx.all.abstracted.factory.ADOLibFactory;
import org.adoxx.all.abstracted.ADOLibrary;
import org.adoxx.all.abstracted.ADOClass;
import org.adoxx.all.abstracted.ADORelation;


import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ListCellRenderer;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;



public class WeavHEM_HCML {

	public static void main(String[] args) {
		try{
		
			
			  ADOAllFile mainLib = ADOLibFactory.loadFromAllFile("D:\\lib\\HCMLModeller.all", true);
	          ADOAllFile secondLib = ADOLibFactory.loadFromAllFile("D:\\lib\\New_HEML.all", true);
	          ADOAllFile mergedLib = ADOLibFactory.generateADOxxTotalEmptyLibrary("Weaved");
	                               
//	//////////////            
	             String log = "";
//	                    StringBuilder str = new StringBuilder();
        for(ADOClass adoClass : secondLib.getApplicationLibraryNew().getDynamicLibrary().getClasses()){
            try{
                if(!adoClass.isInternal())
                    //this.getDynamicLibrary().addClass(adoClass);
                    
                      System.out.println("targetMetaClass = " + adoClass.getId());
            //          str.append(adoClass.getId()+", ");

            }catch(Exception ex) {ex.printStackTrace(); log += "Skipped ADOClass "+adoClass.getId()+"\n";}
        }
       
 //      System.out.println("str.appendClasses = " + str);
        for(ADORelation adoRelation : secondLib.getApplicationLibraryNew().getDynamicLibrary().getRelations()){
            try{
                if(!adoRelation.isInternal())
              //      this.getStaticLibrary().addRelation(adoRelation);
              System.out.println("targetMetaRelation = " + adoRelation.getId());
            }catch(Exception ex){ex.printStackTrace(); log += "Skipped ADORelation "+adoRelation.getId()+"\n";}
        }
	         
	  //       System.err.println(log);

//////////////////////////	
		
		
		
		
		
		
			  mergedLib.getApplicationLibraryNew()
			  
			                                    //HCML MetaClasses
			                                    .importClassesAndRelations(mainLib.getApplicationLibraryNew())
			                                    .importAttributeProfileClasses(mainLib.getApplicationLibraryNew())
			                                    .importRecordClasses(mainLib.getApplicationLibraryNew())
			                                    .importFiles(mainLib.getApplicationLibraryNew())
//			 
//                                                //HCML Special MetaClasses
//                                                .importSpecialClasses(mainLib.getApplicationLibraryNew(), true)
//                                                .importClass(mainLib.getApplicationLibraryNew(), true, "Behavioral Unit")
//                                                .importClass(mainLib.getApplicationLibraryNew(), true, "Operation and Behavioral Unit")
//                                                .importClass(mainLib.getApplicationLibraryNew(), true, "Operation")
//                                                .importClass(mainLib.getApplicationLibraryNew(), true, "Goal")
//                                                .importClass(mainLib.getApplicationLibraryNew(), true, "Thing")
//                                                .importClass(mainLib.getApplicationLibraryNew(), true, "Person")                                                
//                                                .importRelation(mainLib.getApplicationLibraryNew(), true, "Flow")

                                                .importAttributeProfileClasses(mainLib.getApplicationLibraryNew())
			                                    .importRecordClasses(mainLib.getApplicationLibraryNew())
			                                    .importFiles(mainLib.getApplicationLibraryNew())
//	
                                                                                 
			                                    .importSpecialClasses(secondLib.getApplicationLibraryNew(), true)
			                                    .importClass(secondLib.getApplicationLibraryNew(), true, "Emotion")
			                                    
			                                    .importClass(secondLib.getApplicationLibraryNew(), true, "Capability")
			                                    .importClass(secondLib.getApplicationLibraryNew(), true, "ES")
			                                   
			                                    .importRelation(secondLib.getApplicationLibraryNew(), true, "ES-Emotion")
			                                    .importRelation(secondLib.getApplicationLibraryNew(), true, "ES-Operation")
			                                    .importRelation(secondLib.getApplicationLibraryNew(), true, "ES-Capability")
			                                    .importRelation(secondLib.getApplicationLibraryNew(), true, "Capability-Operation")
			                                    .importRecordClasses(secondLib.getApplicationLibraryNew())
		                                        .importAttributeProfileClasses(secondLib.getApplicationLibraryNew())
		                                        .importFiles(secondLib.getApplicationLibraryNew());	
    String dynamicModi = "GENERAL order-of-classes:custom \nMODELTYPE \"Task Context\" from:none plural:\"Task Context\" not-simulateable  order-of-classes:custo\n m bitmap:\"db:\\\\TC.bmp\" \nINCL \"Operation and Behavioral Unit\" \nMODELTYPE \"Sequence\" from:none plural:\"Sequence\" not-simulateable  order-of-classes:custom bitmap:\"db:\\\\S.bmp\" \nINCL \"Operation\"\nINCL \"Flow\"\nMODELTYPE \"Makro\" from:none plural:\"Makro\" not-simulateable  order-of-classes:custom  bitmap:\"db:\\\\M.bmp\"\nINCL \"Operation\"\nINCL \"Flow\"\nMODELTYPE \"Behavioral Unit Model Bum\" from:none plural:\"Behavioral Unit Model Bum\" not-simulateable  order-of-classes:custom bitmap:\"db:\\\\BUM.bmp\"\nINCL \"Operation\" \nINCL \"Operation Makro\"\nINCL \"Operation and Behavioral Unit\"\nINCL \"Behavioral Unit\"\nINCL \"Goal\"\nINCL \"Flow\"\nINCL \"has\"\nMODE \"Standard\" from:all\nMODELTYPE \"Structural Context\" from:none plural:\"Structural Context\" not-simulateable  order-of-classes:custom bitmap:\"db:\\\\StC.bmp\"\nINCL \"Person\"\nINCL \"Thing\"\nINCL \"Super Thing\"\nINCL \"Super Person\"\nINCL \"Location\"\nINCL \"Super Location\"\nINCL \"Connection\"\nINCL \"Is-A\" \nMODE \"Standard\" from:all\nMODELTYPE \"HEM Plugin Elements\" from:none plural:\"HEM Plugin Elements\" pos:2 \nINCL \"Emotion\"\nINCL \"Operation\"\nINCL \"Capability\"\nINCL \"ES\"\nINCL \"Capability-Operation\"\nINCL \"ES-Emotion\"\nINCL \"ES-Capability\"\nINCL \"ES-Operation\"";
    String staticModi = "";    
    mergedLib.getApplicationLibraryNew().getDynamicLibrary().setModi(dynamicModi);
    mergedLib.getApplicationLibraryNew().getStaticLibrary().setModi(staticModi);

	mergedLib.generateABLFile("D:\\lib\\weaved.abl")
			         .generateALLFile("D:\\lib\\weaved.all");
			          System.out.println(" HEML plugin has been created...");
			
		}catch(Exception ex){ex.printStackTrace();}
	}
}
