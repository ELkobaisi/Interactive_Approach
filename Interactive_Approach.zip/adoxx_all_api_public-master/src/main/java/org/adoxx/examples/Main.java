package org.adoxx.examples;

import org.adoxx.all.abstracted.ADOAllFile;
import org.adoxx.all.abstracted.ADOClass;
import org.adoxx.all.abstracted.ADOLibrary;
import org.adoxx.all.abstracted.factory.ADOLibFactory;

/**
 * <h1>Main</h1>
 * This class demonstrate the generation of an ALL as a string in the console representing a demo library with only two classes, A and B.
 * The purpose of this class is to be used from its source code in order to experiments with all the features.
 * This main method in particular contain the following features demonstrations:
 * - Generation of a total empty library to use as a starting point for merging libraries:
 *   System.out.println(ADOLibFactory.generateADOxxTotalEmptyLibrary("TotalEmpty").generateALL());
 * - Generation of an empty library to use as a starting point for your own new library:
 *   System.out.println(ADOLibFactory.generateADOxxEmptyLibrary("Empty").generateALL());
 * - Create a library with two classes and a relation between them:
 *   System.out.println(ADOLibFactory.generateADOxxTutorialLibrary("AB", "A", "B").generateALL());
 * - Create an empty extended library:
 *   System.out.println(ADOLibFactory.generateADOxxExtendedTestLibrary("AB").generateALL());
 * - Generate the ABL file of the Tutorial Library:
 *   ADOLibFactory.generateADOxxTutorialLibrary("AB", "A", "B").generateABLFile("C:\\...file_path...\\file_name.abl");
 * - Generate a tutorial library with A and B classes and then extend it importing all the class and relations generated in another tutorial library (C D):
 *   System.out.println(ADOLibFactory.generateADOxxTutorialLibrary("AB", "A", "B").getApplicationLibraryNew().importClassesAndRelations(ADOLibFactory.generateADOxxTutorialLibrary("CD", "C", "D").getApplicationLibraryNew()).parentAllFile.generateALL());
 * - Parse an ALL file and generate the corresponding java ADOAllFile structure. Then generate the ALL from the java class in a new file:
 *   ADOLibFactory.loadFromAllFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\StartingPoint_BPMN2-0_ADOxx1-3-UL1_v1-01.all", true).generateALLFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\StartingPoint_BPMN2-0_ADOxx1-3-UL1_v1-01_MY.all");
 * - Read a model from a JSON file and generate the ALL file:
 *   System.out.println(ADOLibFactory.loadFromJsonFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\jsonModel.json").generateALL());
 * - Parse an ALL file and generate Java code in order to define the ADOAllFile structure:
 *   ADOLibFactory.generateJavaCodeFileFromAllFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\test01.java", "D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\test01.all", true);
 * - Convert an ABL to ALL using the internal algorithm, then parse the ALL file and generate the corresponding java ADOAllFile structure. Then generate the ALL from the java class in a new file (Available only for BOC internals)
 *   ADOLibFactory.loadFromAblFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\StartingPoint_BPMN2-0_ADOxx1-3-UL1_v1-01.abl", true).generateALLFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\StartingPoint_BPMN2-0_ADOxx1-3-UL1_v1-01_GEN.abl.all");
 * - Export the generated tutorial library in a Database and lunch ADOxx in order to test if the library work:
 *   ADOLibFactory.generateADOxxTutorialLibrary("AB", "A", "B").generateDB("adoMY2", "put_your_adoxx_license_key_here");
 * - Generate a standard adoxx license key from the provided mail (Available only for BOC internals):
 *   System.out.println(org.adoxx.ado.ADOUtils.generateLicenseKey(org.adoxx.ado.ADOUtils.generateLicenseCustomerName("damiano.falcioni@boc-eu.com")));
 *
 * @author Damiano Falcioni
 * */
public class Main {

    public static void main(String[] args) {
        try {
            /* Generate a total empty library; use this as a starting point for a libraries merge*/
            //System.out.println(ADOLibFactory.generateADOxxTotalEmptyLibrary("TotalEmpty").generateALL());
            
            /* Generate an empty library; use this as a starting point for your own new library*/
            //System.out.println(ADOLibFactory.generateADOxxEmptyLibrary("Empty").generateALL());
            
            /* Create a library with two classes and a relation between them */
 //           System.out.println(ADOLibFactory.generateADOxxTutorialLibrary("AB", "A", "B").generateALL());
            //ADOLibFactory.generateADOxxTutorialLibrary("AB", "A", "B").generateABLFile("D:\\ADOXX.ORG\\ADOxx_Training\\file1.abl");
            
            /* Create an empty extended library */
            //System.out.println(ADOLibFactory.generateADOxxExtendedTestLibrary("AB").generateALL());
            
            
            /* Generate the ABL file of the Tutorial Library;
             *
            ADOLibFactory.generateADOxxTutorialLibrary("AB", "A", "B").generateABLFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\zzzz.abl");
            */
            
            /* Generate a tutorial library with A and B classes and then extend it importing all the class and relations generated in another tutorial library (C D)
             *
            System.out.println(ADOLibFactory.generateADOxxTutorialLibrary("AB", "A", "B").getApplicationLibraryNew().importClassesAndRelations(ADOLibFactory.generateADOxxTutorialLibrary("CD", "C", "D").getApplicationLibraryNew()).parentAllFile.generateALL());
            */
            
            /* Parse an ALL file and generate the corresponding java ADOAllFile structure. Then generate the ALL from the java class in a new file 
             * 
            ADOLibFactory.loadFromAllFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\StartingPoint_BPMN2-0_ADOxx1-3-UL1_v1-01.all", true)
                             .generateALLFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\StartingPoint_BPMN2-0_ADOxx1-3-UL1_v1-01_MY.all");
            */
            
            /* Read a model from a JSON file and generate the ALL file
             * 
            System.out.println(ADOLibFactory.loadFromJsonFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\jsonModel.json").generateALL());
            */
            
            /* Parse an ALL file and generate Java code in order to define the ADOAllFile structure 
             *
            ADOLibFactory.generateJavaCodeFileFromAllFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\test01.java", "D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\test01.all", true);
            */
            
            /* Convert an ABL to ALL using the internal algorithm, then parse the ALL file and generate the corresponding java ADOAllFile structure. Then generate the ALL from the java class in a new file 
             * Available only for BOC internals
             *
            ADOLibFactory.loadFromAblFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\StartingPoint_BPMN2-0_ADOxx1-3-UL1_v1-01.abl", true)
                             .generateALLFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\StartingPoint_BPMN2-0_ADOxx1-3-UL1_v1-01_GEN.abl.all");
             */
            
            /* Export the generated tutorial library in a Database and lunch ADOxx in order to test if the library work.
             * 
            ADOLibFactory.generateADOxxTutorialLibrary("AC", "A", "C").generateDB("adoMY2", "eM4-EjwV-CKbRaaOSi5mGwZuErVT6v9CAKEwvRGl", null, "D41010EE328888ACDE410ADBABCFDC3AFF1B264E0162C5C3D0F27235E65110B8", null, null, null, null);
            */
            
            /* Generate a standard adoxx license key from the provided mail 
             * Available only for BOC internals
             * 
            System.out.println(org.adoxx.ado.ADOUtils.generateLicenseKey(org.adoxx.ado.ADOUtils.generateLicenseCustomerName("damiano.falcioni@boc-eu.com")));
            */
            ADOAllFile adoAllFile = ADOLibFactory.loadFromAllFile("D:\\lib\\New_AREML.all", true);
            adoAllFile.generateALLFile("D:\\lib\\AREML_generated.all");
//
//            ADOAllFile adoAllFile = ADOLibFactory.loadFromAllFile("D:\\lib\\New_HCM-L V.0.3.3.all", true);
//            adoAllFile.generateALLFile("D:\\lib\\HCM-L V.0.3.3_generated.all");



//            ADOAllFile adoAllFile = ADOLibFactory.loadFromAllFile("D:\\lib\\New_HEML.all", true);
//            adoAllFile.generateALLFile("D:\\lib\\HEML_generated.all");

            if (args.length < 3) {
                System.out.println("Usage: java -jar adoxxall.jar target-file.all crosscutting-file.all result-file.all");
                return;
            }

            String targetMetaClassId = "Action";
            String injectedMetaClassId = "Operation";

            ADOAllFile targetALLFile = ADOLibFactory.loadFromAllFile(args[0], true);
            ADOAllFile crosscuttingALLFile = ADOLibFactory.loadFromAllFile(args[1], true);

            ADOLibrary targetLibrary = targetALLFile.getApplicationLibraryNew().getDynamicLibrary();
            ADOClass targetMetaClass = targetLibrary.getClassDefinition(targetMetaClassId);
            System.out.println("targetMetaClass = " + targetMetaClass.getId().toString());

            ADOLibrary crosscuttingLibrary = crosscuttingALLFile.getApplicationLibraryNew().getDynamicLibrary();
            ADOClass injectedMetaClass = crosscuttingLibrary.getClassDefinition(injectedMetaClassId);
            System.out.println("injectedMetaClass = " + injectedMetaClass.getId().toString());

            targetLibrary.addClass(injectedMetaClass);

            targetALLFile.generateALLFile(args[2]);
//            adoAllFile.generateALLFile(args[1]);

            /**/

            /* Parse an ALL file and generate Java code in order to define the ADOAllFile structure
             *
            System.out.println(ADOLibFactory.generateJavaCodeFromAllFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\test01.all", true));
            ADOLibFactory.generateJavaCodeFileFromAllFile("D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\test01.java", "D:\\ADOXX.ORG\\JAVA-MM-DSL\\test\\test01.all", true);
            */

            /* Export the generated tutorial library in a Database and lunch ADOxx in order to test if the library work.
             * it will use the online service in order to generate the ABL needed by the DB
             *
            ADOLibFactory.generateADOxxTutorialLibrary("AB", "C", "D").generateDB("adoMY2", "put_your_adoxx_license_here");
            */
			
			
			
			
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
